/* tslint:disable */
/* eslint-disable */
/**
 * Creates a default PostgreSQL storage configuration with sensible defaults.
 *
 * Default values (from pg.Pool):
 * - `maxPoolSize`: 10
 * - `createTimeoutSecs`: 0 (no timeout)
 * - `recycleTimeoutSecs`: 10 (10 seconds idle before disconnect)
 */
export function defaultPostgresStorageConfig(connection_string: string): PostgresStorageConfig;
export function connect(request: ConnectRequest): Promise<BreezSdk>;
export function connectWithSigner(config: Config, signer: ExternalSigner, storage_dir: string): Promise<BreezSdk>;
/**
 * Creates a default external signer from a mnemonic phrase.
 *
 * This creates a signer that can be used with `connectWithSigner` or `SdkBuilder.newWithSigner`.
 */
export function getSparkStatus(): Promise<SparkStatus>;
export function initLogging(logger: Logger, filter?: string | null): Promise<void>;
export function defaultExternalSigner(mnemonic: string, passphrase: string | null | undefined, network: Network, key_set_config?: KeySetConfig | null): DefaultSigner;
export function defaultConfig(network: Network): Config;
/**
 * Entry point invoked by JavaScript in a worker.
 */
export function task_worker_entry_point(ptr: number): void;
/**
 * The `ReadableStreamType` enum.
 *
 * *This API requires the following crate features to be activated: `ReadableStreamType`*
 */
type ReadableStreamType = "bytes";

/** Serialized tree node. Key fields used by store implementations: id, status, value. */
interface TreeNode {
    id: string;
    tree_id: string;
    value: number;
    status: string;
    [key: string]: unknown;
}

interface Leaves {
    available: TreeNode[];
    notAvailable: TreeNode[];
    availableMissingFromOperators: TreeNode[];
    reservedForPayment: TreeNode[];
    reservedForSwap: TreeNode[];
}

interface LeavesReservation {
    id: string;
    leaves: TreeNode[];
}

type TargetAmounts =
    | { type: 'amountAndFee'; amountSats: number; feeSats: number | null }
    | { type: 'exactDenominations'; denominations: number[] };

type ReserveResult =
    | { type: 'success'; reservation: LeavesReservation }
    | { type: 'insufficientFunds' }
    | { type: 'waitForPending'; needed: number; available: number; pending: number };

export interface TreeStore {
    addLeaves: (leaves: TreeNode[]) => Promise<void>;
    getLeaves: () => Promise<Leaves>;
    setLeaves: (leaves: TreeNode[], missingLeaves: TreeNode[], refreshStartedAtMs: number) => Promise<void>;
    cancelReservation: (id: string) => Promise<void>;
    finalizeReservation: (id: string, newLeaves: TreeNode[] | null) => Promise<void>;
    tryReserveLeaves: (targetAmounts: TargetAmounts | null, exactOnly: boolean, purpose: string) => Promise<ReserveResult>;
    now: () => Promise<number>;
    updateReservation: (reservationId: string, reservedLeaves: TreeNode[], changeLeaves: TreeNode[]) => Promise<LeavesReservation>;
}

/**
 * Configuration for PostgreSQL storage connection pool.
 */
export interface PostgresStorageConfig {
    /**
     * PostgreSQL connection string (URI format).
     */
    connectionString: string;
    /**
     * Maximum number of connections in the pool.
     */
    maxPoolSize: number;
    /**
     * Timeout in seconds for establishing a new connection (0 = no timeout).
     */
    createTimeoutSecs: number;
    /**
     * Timeout in seconds before recycling an idle connection.
     */
    recycleTimeoutSecs: number;
}


interface WasmTokenMetadata {
    identifier: string;
    issuerPublicKey: string;
    name: string;
    ticker: string;
    decimals: number;
    maxSupply: string;
    isFreezable: boolean;
    creationEntityPublicKey: string | null;
}

interface WasmTokenOutput {
    id: string;
    ownerPublicKey: string;
    revocationCommitment: string;
    withdrawBondSats: number;
    withdrawRelativeBlockLocktime: number;
    tokenPublicKey: string | null;
    tokenIdentifier: string;
    tokenAmount: string;
}

interface WasmTokenOutputWithPrevOut {
    output: WasmTokenOutput;
    prevTxHash: string;
    prevTxVout: number;
}

interface WasmTokenOutputs {
    metadata: WasmTokenMetadata;
    outputs: WasmTokenOutputWithPrevOut[];
}

interface WasmTokenOutputsPerStatus {
    metadata: WasmTokenMetadata;
    available: WasmTokenOutputWithPrevOut[];
    reservedForPayment: WasmTokenOutputWithPrevOut[];
    reservedForSwap: WasmTokenOutputWithPrevOut[];
}

interface WasmTokenOutputsReservation {
    id: string;
    tokenOutputs: WasmTokenOutputs;
}

type WasmGetTokenOutputsFilter =
    | { type: 'identifier'; identifier: string }
    | { type: 'issuerPublicKey'; issuerPublicKey: string };

type WasmReservationTarget =
    | { type: 'minTotalValue'; value: string }
    | { type: 'maxOutputCount'; value: number };

export interface TokenStore {
    setTokensOutputs: (tokenOutputs: WasmTokenOutputs[], refreshStartedAtMs: number) => Promise<void>;
    listTokensOutputs: () => Promise<WasmTokenOutputsPerStatus[]>;
    getTokenOutputs: (filter: WasmGetTokenOutputsFilter) => Promise<WasmTokenOutputsPerStatus>;
    insertTokenOutputs: (tokenOutputs: WasmTokenOutputs) => Promise<void>;
    reserveTokenOutputs: (
        tokenIdentifier: string,
        target: WasmReservationTarget,
        purpose: string,
        preferredOutputs: WasmTokenOutputWithPrevOut[] | null,
        selectionStrategy: string | null
    ) => Promise<WasmTokenOutputsReservation>;
    cancelReservation: (id: string) => Promise<void>;
    finalizeReservation: (id: string) => Promise<void>;
    now: () => Promise<number>;
}

export interface EventListener {
    onEvent: (e: SdkEvent) => void;
}

export interface Logger {
    log: (l: LogEntry) => void;
}

export interface RestClient {
    getRequest(url: string, headers?: Record<string, string>): Promise<RestResponse>;
    postRequest(url: string, headers?: Record<string, string>, body?: string): Promise<RestResponse>;
    deleteRequest(url: string, headers?: Record<string, string>, body?: string): Promise<RestResponse>;
}

export interface RestResponse {
    status: number;
    body: string;
}

export interface FiatService {
    fetchFiatCurrencies(): Promise<FiatCurrency[]>;
    fetchFiatRates(): Promise<Rate[]>;
}

export interface BitcoinChainService {
    getAddressUtxos(address: string): Promise<Utxo[]>;
    getTransactionStatus(txid: string): Promise<TxStatus>;
    getTransactionHex(txid: string): Promise<string>;
    broadcastTransaction(tx: string): Promise<void>;
    recommendedFees(): Promise<RecommendedFees>;
}

export interface Utxo {
    txid: string;
    vout: number;
    value: number;
    status: TxStatus;
}

export type ChainApiType = "esplora" | "mempoolSpace";

export interface RecommendedFees {
    fastestFee: number;
    halfHourFee: number;
    hourFee: number;
    economyFee: number;
    minimumFee: number;
}

export interface TxStatus {
    confirmed: boolean;
    blockHeight?: number;
    blockTime?: number;
}

export interface PaymentObserver {
    beforeSend: (payments: ProvisionalPayment[]) => Promise<void>;
}

export type ConversionProvider = "amm" | "orchestra" | "boltz";

export type PaymentRequest = { type: "input"; input: string } | { type: "crossChain"; address: string; route: CrossChainRoutePair };

export type ConversionInfo = { type: "amm"; poolId: string; conversionId: string; status: ConversionStatus; fee?: string; purpose?: ConversionPurpose; amountAdjustment?: AmountAdjustmentReason } | { type: "orchestra"; chain: string; chainId?: string; asset?: string; assetContract?: string; recipientAddress: string; estimatedOut: string; deliveredAmount?: string; status: ConversionStatus; fee?: string; assetDecimals: number; orderId: string; quoteId: string; readToken?: string } | { type: "boltz"; chain: string; chainId?: string; asset?: string; assetContract?: string; recipientAddress: string; estimatedOut: string; deliveredAmount?: string; status: ConversionStatus; fee?: string; assetDecimals: number; swapId: string; invoice: string; invoiceAmountSats: number; lzGuid?: string; maxSlippageBps: number; quoteDegraded?: boolean };

export interface OptimizationProgress {
    isRunning: boolean;
    currentRound: number;
    totalRounds: number;
}

export type DepositClaimError = { type: "maxDepositClaimFeeExceeded"; tx: string; vout: number; maxFee?: Fee; requiredFeeSats: number; requiredFeeRateSatPerVbyte: number } | { type: "missingUtxo"; tx: string; vout: number } | { type: "generic"; message: string };

export type MaxFee = { type: "fixed"; amount: number } | { type: "rate"; satPerVbyte: number } | { type: "networkRecommended"; leewaySatPerVbyte: number };

export interface SetLnurlMetadataItem {
    paymentHash: string;
    senderComment?: string;
    nostrZapRequest?: string;
    nostrZapReceipt?: string;
}

export type ServiceStatus = "operational" | "degraded" | "partial" | "unknown" | "major";

export type ConversionChain = { type: "spark" } | { type: "lightning" } | { type: "external"; name: string; chainId?: string };

export interface PaymentRequestSource {
    bip21Uri?: string;
    bip353Address?: string;
}

export interface PrepareLnurlPayResponse {
    amountSats: number;
    comment?: string;
    payRequest: LnurlPayRequestDetails;
    feeSats: number;
    invoiceDetails: Bolt11InvoiceDetails;
    successAction?: SuccessAction;
    conversionEstimate?: ConversionEstimate;
    feePolicy: FeePolicy;
}

export type ReceivePaymentMethod = { type: "sparkAddress" } | { type: "sparkInvoice"; amount?: string; tokenIdentifier?: string; expiryTime?: number; description?: string; senderPublicKey?: string } | { type: "bitcoinAddress"; newAddress?: boolean } | { type: "bolt11Invoice"; description: string; amountSats?: number; expirySecs?: number; paymentHash?: string };

export interface Payment {
    id: string;
    paymentType: PaymentType;
    status: PaymentStatus;
    amount: bigint;
    fees: bigint;
    timestamp: number;
    method: PaymentMethod;
    details?: PaymentDetails;
    conversionDetails?: ConversionDetails;
}

export interface SparkAddressDetails {
    address: string;
    identityPublicKey: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface SparkSigningOperator {
    id: number;
    identifier: string;
    address: string;
    identityPublicKey: string;
}

export type AmountAdjustmentReason = "flooredToMinLimit" | "increasedToAvoidDust";

export interface TokenBalance {
    balance: bigint;
    tokenMetadata: TokenMetadata;
}

export interface Bolt12OfferBlindedPath {
    blindedHops: string[];
}

export interface SendOnchainSpeedFeeQuote {
    userFeeSat: number;
    l1BroadcastFeeSat: number;
}

export interface SparkStatus {
    status: ServiceStatus;
    lastUpdated: number;
}

export interface CheckMessageRequest {
    message: string;
    pubkey: string;
    signature: string;
}

export interface LnurlPayRequest {
    prepareResponse: PrepareLnurlPayResponse;
    idempotencyKey?: string;
}

export interface RecordId {
    type: string;
    dataId: string;
}

export interface OptimizationConfig {
    autoEnabled: boolean;
    multiplicity: number;
}

export interface Bip21Details {
    amountSat?: number;
    assetId?: string;
    uri: string;
    extras: Bip21Extra[];
    label?: string;
    message?: string;
    paymentMethods: InputType[];
}

export interface PaymentMetadata {
    parentPaymentId?: string;
    lnurlPayInfo?: LnurlPayInfo;
    lnurlWithdrawInfo?: LnurlWithdrawInfo;
    lnurlDescription?: string;
    conversionInfo?: ConversionInfo;
    conversionStatus?: ConversionStatus;
}

export interface Conversion {
    provider: ConversionProvider;
    status: ConversionStatus;
    from: ConversionSide;
    to: ConversionSide;
    amountAdjustment?: AmountAdjustmentReason;
}

export interface LogEntry {
    line: string;
    level: string;
}

export interface Webhook {
    id: string;
    url: string;
    eventTypes: WebhookEventType[];
}

export interface ConversionDetails {
    status: ConversionStatus;
    conversions?: Conversion[];
}

export interface LnurlPayInfo {
    lnAddress?: string;
    comment?: string;
    domain?: string;
    metadata?: string;
    processedSuccessAction?: SuccessActionProcessed;
    rawSuccessAction?: SuccessAction;
}

export type BuyBitcoinRequest = { type: "moonpay"; lockedAmountSat?: number; redirectUrl?: string } | { type: "cashApp"; amountSats?: number };

export type ConversionType = { type: "fromBitcoin" } | { type: "toBitcoin"; fromTokenIdentifier: string };

export type ConversionPurpose = { type: "ongoingPayment"; paymentRequest: string } | { type: "selfTransfer" } | { type: "autoConversion" };

export interface UnversionedRecordChange {
    id: RecordId;
    schemaVersion: string;
    updatedFields: Map<string, string>;
}

export interface SendOnchainFeeQuote {
    id: string;
    expiresAt: number;
    speedFast: SendOnchainSpeedFeeQuote;
    speedMedium: SendOnchainSpeedFeeQuote;
    speedSlow: SendOnchainSpeedFeeQuote;
}

export interface RefundDepositResponse {
    txId: string;
    txHex: string;
}

export interface RefundDepositRequest {
    txid: string;
    vout: number;
    destinationAddress: string;
    fee: Fee;
}

export interface SparkHtlcDetails {
    paymentHash: string;
    preimage?: string;
    expiryTime: number;
    status: SparkHtlcStatus;
}

export interface RegisterWebhookResponse {
    webhookId: string;
}

export interface AesSuccessActionDataDecrypted {
    description: string;
    plaintext: string;
}

export interface SparkInvoicePaymentDetails {
    description?: string;
    invoice: string;
}

export interface Bolt12InvoiceDetails {
    amountMsat: number;
    invoice: Bolt12Invoice;
}

export interface LnurlWithdrawRequestDetails {
    callback: string;
    k1: string;
    defaultDescription: string;
    minWithdrawable: number;
    maxWithdrawable: number;
}

export interface ProvisionalPayment {
    paymentId: string;
    amount: bigint;
    details: ProvisionalPaymentDetails;
}

export type PaymentMethod = "lightning" | "spark" | "token" | "deposit" | "withdraw" | "unknown";

export interface BuyBitcoinResponse {
    url: string;
}

export interface LnurlErrorDetails {
    reason: string;
}

export interface LnurlWithdrawResponse {
    paymentRequest: string;
    payment?: Payment;
}

export interface FetchConversionLimitsResponse {
    minFromAmount?: bigint;
    minToAmount?: bigint;
}

export type PaymentDetailsFilter = { type: "spark"; htlcStatus?: SparkHtlcStatus[]; conversionRefundNeeded?: boolean } | { type: "token"; conversionRefundNeeded?: boolean; txHash?: string; txType?: TokenTransactionType } | { type: "lightning"; htlcStatus?: SparkHtlcStatus[] };

export interface ConversionEstimate {
    options: ConversionOptions;
    amountIn: bigint;
    amountOut: bigint;
    fee: bigint;
    amountAdjustment?: AmountAdjustmentReason;
}

export interface Bolt11Invoice {
    bolt11: string;
    source: PaymentRequestSource;
}

export interface ClaimDepositResponse {
    payment: Payment;
}

export interface UpdateContactRequest {
    id: string;
    name: string;
    paymentIdentifier: string;
}

export interface LnurlInfo {
    url: string;
    bech32: string;
}

export interface GetTokensMetadataResponse {
    tokensMetadata: TokenMetadata[];
}

export type SuccessAction = { type: "aes"; data: AesSuccessActionData } | { type: "message"; data: MessageSuccessActionData } | { type: "url"; data: UrlSuccessActionData };

export type CrossChainProvider = "orchestra" | "boltz";

export type ConversionStatus = "pending" | "completed" | "failed" | "refundNeeded" | "refunded";

export interface Bolt12OfferDetails {
    absoluteExpiry?: number;
    chains: string[];
    description?: string;
    issuer?: string;
    minAmount?: Amount;
    offer: Bolt12Offer;
    paths: Bolt12OfferBlindedPath[];
    signingPubkey?: string;
}

export interface SparkHtlcOptions {
    paymentHash: string;
    expiryDurationSecs: number;
}

export interface LnurlReceiveMetadata {
    nostrZapRequest?: string;
    nostrZapReceipt?: string;
    senderComment?: string;
}

export type UpdateDepositPayload = { type: "claimError"; error: DepositClaimError } | { type: "refund"; refundTxid: string; refundTx: string };

export interface GetPaymentResponse {
    payment: Payment;
}

export interface Record {
    id: RecordId;
    revision: number;
    schemaVersion: string;
    data: Map<string, string>;
}

export interface Rate {
    coin: string;
    value: number;
}

export interface LnurlPayRequestDetails {
    callback: string;
    minSendable: number;
    maxSendable: number;
    metadataStr: string;
    commentAllowed: number;
    domain: string;
    url: string;
    address?: string;
    allowsNostr?: boolean;
    nostrPubkey?: string;
}

export interface OutgoingChange {
    change: RecordChange;
    parent?: Record;
}

export interface PrepareLnurlPayRequest {
    amount: bigint;
    comment?: string;
    payRequest: LnurlPayRequestDetails;
    validateSuccessActionUrl?: boolean;
    tokenIdentifier?: string;
    conversionOptions?: ConversionOptions;
    feePolicy?: FeePolicy;
}

export type SuccessActionProcessed = { type: "aes"; result: AesSuccessActionDataResult } | { type: "message"; data: MessageSuccessActionData } | { type: "url"; data: UrlSuccessActionData };

export type KeySetType = "default" | "taproot" | "nativeSegwit" | "wrappedSegwit" | "legacy";

export interface ListFiatCurrenciesResponse {
    currencies: FiatCurrency[];
}

export type SdkEvent = { type: "synced" } | { type: "unclaimedDeposits"; unclaimedDeposits: DepositInfo[] } | { type: "claimedDeposits"; claimedDeposits: DepositInfo[] } | { type: "paymentSucceeded"; payment: Payment } | { type: "paymentPending"; payment: Payment } | { type: "paymentFailed"; payment: Payment } | { type: "optimization"; optimizationEvent: OptimizationEvent } | { type: "lightningAddressChanged"; lightningAddress?: LightningAddressInfo } | { type: "newDeposits"; newDeposits: DepositInfo[] };

export type OnchainConfirmationSpeed = "fast" | "medium" | "slow";

export interface Bolt12Offer {
    offer: string;
    source: PaymentRequestSource;
}

export interface SparkSspConfig {
    baseUrl: string;
    identityPublicKey: string;
    schemaEndpoint?: string;
}

export type InputType = ({ type: "bitcoinAddress" } & BitcoinAddressDetails) | ({ type: "bolt11Invoice" } & Bolt11InvoiceDetails) | ({ type: "bolt12Invoice" } & Bolt12InvoiceDetails) | ({ type: "bolt12Offer" } & Bolt12OfferDetails) | ({ type: "lightningAddress" } & LightningAddressDetails) | ({ type: "lnurlPay" } & LnurlPayRequestDetails) | ({ type: "silentPaymentAddress" } & SilentPaymentAddressDetails) | ({ type: "lnurlAuth" } & LnurlAuthRequestDetails) | ({ type: "url" } & string) | ({ type: "bip21" } & Bip21Details) | ({ type: "bolt12InvoiceRequest" } & Bolt12InvoiceRequestDetails) | ({ type: "lnurlWithdraw" } & LnurlWithdrawRequestDetails) | ({ type: "sparkAddress" } & SparkAddressDetails) | ({ type: "sparkInvoice" } & SparkInvoiceDetails) | ({ type: "crossChainAddress" } & CrossChainAddressDetails);

export interface BitcoinAddressDetails {
    address: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface Bip21Extra {
    key: string;
    value: string;
}

export interface PrepareSendPaymentRequest {
    paymentRequest: PaymentRequest;
    amount?: bigint;
    tokenIdentifier?: string;
    conversionOptions?: ConversionOptions;
    feePolicy?: FeePolicy;
}

export type ConversionFilter = "ammRefundNeeded" | "orchestraPending";

export type SparkHtlcStatus = "waitingForPreimage" | "preimageShared" | "returned";

export interface AesSuccessActionData {
    description: string;
    ciphertext: string;
    iv: string;
}

export interface ListFiatRatesResponse {
    rates: Rate[];
}

export type StoragePaymentDetailsFilter = { type: "spark"; htlcStatus?: SparkHtlcStatus[]; conversionFilter?: ConversionFilter } | { type: "token"; conversionFilter?: ConversionFilter; txHash?: string; txType?: TokenTransactionType } | { type: "lightning"; htlcStatus?: SparkHtlcStatus[] };

export interface SyncWalletRequest {}

export type AssetFilter = { type: "bitcoin" } | { type: "token"; tokenIdentifier?: string };

export interface CheckLightningAddressRequest {
    username: string;
}

export interface Bolt11RouteHint {
    hops: Bolt11RouteHintHop[];
}

export interface LnurlWithdrawRequest {
    amountSats: number;
    withdrawRequest: LnurlWithdrawRequestDetails;
    completionTimeoutSecs?: number;
}

export interface UserSettings {
    sparkPrivateModeEnabled: boolean;
    stableBalanceActiveLabel?: string;
}

export interface DepositInfo {
    txid: string;
    vout: number;
    amountSats: number;
    isMature: boolean;
    refundTx?: string;
    refundTxId?: string;
    claimError?: DepositClaimError;
}

export interface TokenMetadata {
    identifier: string;
    issuerPublicKey: string;
    name: string;
    ticker: string;
    decimals: number;
    maxSupply: string;
    isFreezable: boolean;
}

export interface GetTokensMetadataRequest {
    tokenIdentifiers: string[];
}

export interface SendPaymentRequest {
    prepareResponse: PrepareSendPaymentResponse;
    options?: SendPaymentOptions;
    idempotencyKey?: string;
}

export interface CurrencyInfo {
    name: string;
    fractionSize: number;
    spacing?: number;
    symbol?: Symbol;
    uniqSymbol?: Symbol;
    localizedName: LocalizedName[];
    localeOverrides: LocaleOverrides[];
}

export type TokenTransactionType = "transfer" | "mint" | "burn";

export interface FiatCurrency {
    id: string;
    info: CurrencyInfo;
}

export interface GetPaymentRequest {
    paymentId: string;
}

export interface FetchConversionLimitsRequest {
    conversionType: ConversionType;
    tokenIdentifier?: string;
}

export interface SilentPaymentAddressDetails {
    address: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface ReceivePaymentRequest {
    paymentMethod: ReceivePaymentMethod;
}

export type CrossChainProviderContext = { type: "orchestra"; quoteId: string; depositAddress: string } | { type: "boltz"; swapId: string; invoice: string; lnFeeSats: number; maxSlippageBps: number };

export interface LnurlWithdrawInfo {
    withdrawUrl: string;
}

export interface ClaimDepositRequest {
    txid: string;
    vout: number;
    maxFee?: MaxFee;
}

export interface SyncWalletResponse {}

export interface ClaimHtlcPaymentRequest {
    preimage: string;
}

export type ProvisionalPaymentDetails = { type: "bitcoin"; withdrawalAddress: string } | { type: "lightning"; invoice: string } | { type: "spark"; payRequest: string } | { type: "token"; tokenId: string; payRequest: string };

export interface CrossChainAddressDetails {
    address: string;
    addressFamily: CrossChainAddressFamily;
    contractAddress?: string;
    chainId?: number;
    amount?: bigint;
}

export interface Credentials {
    username: string;
    password: string;
}

export type CrossChainRouteFilter = { type: "send"; addressDetails: CrossChainAddressDetails } | { type: "receive"; contractAddress?: string };

export interface RegisterWebhookRequest {
    url: string;
    secret: string;
    eventTypes: WebhookEventType[];
}

export interface KeySetConfig {
    keySetType: KeySetType;
    useAddressIndex: boolean;
    accountNumber?: number;
}

export interface LnurlAuthRequestDetails {
    k1: string;
    action?: string;
    domain: string;
    url: string;
}

export interface GetInfoRequest {
    ensureSynced?: boolean;
}

export interface RecordChange {
    id: RecordId;
    schemaVersion: string;
    updatedFields: Map<string, string>;
    localRevision: number;
}

export interface SparkInvoiceDetails {
    invoice: string;
    identityPublicKey: string;
    network: BitcoinNetwork;
    amount?: string;
    tokenIdentifier?: string;
    expiryTime?: number;
    description?: string;
    senderPublicKey?: string;
}

export interface AddContactRequest {
    name: string;
    paymentIdentifier: string;
}

export interface SparkConfig {
    coordinatorIdentifier: string;
    threshold: number;
    signingOperators: SparkSigningOperator[];
    sspConfig: SparkSspConfig;
    expectedWithdrawBondSats: number;
    expectedWithdrawRelativeBlockLocktime: number;
}

export type FeePolicy = "feesExcluded" | "feesIncluded";

export interface IncomingChange {
    newState: Record;
    oldState?: Record;
}

export interface SignMessageRequest {
    message: string;
    compact: boolean;
}

export interface Config {
    apiKey?: string;
    network: Network;
    syncIntervalSecs: number;
    maxDepositClaimFee?: MaxFee;
    lnurlDomain?: string;
    preferSparkOverLightning: boolean;
    externalInputParsers?: ExternalInputParser[];
    useDefaultExternalInputParsers: boolean;
    realTimeSyncServerUrl?: string;
    privateEnabledDefault: boolean;
    optimizationConfig: OptimizationConfig;
    stableBalanceConfig?: StableBalanceConfig;
    /**
     * Maximum number of concurrent transfer claims.
     *
     * Controls how many pending Spark transfers can be claimed in parallel.
     * Default is 4. Increase for server environments with high incoming
     * payment volume to improve throughput.
     */
    maxConcurrentClaims: number;
    sparkConfig?: SparkConfig;
    crossChainEnabled: boolean;
}

export type LnurlCallbackStatus = { type: "ok" } | { type: "errorStatus"; errorDetails: LnurlErrorDetails };

export interface StorageListPaymentsRequest {
    typeFilter?: PaymentType[];
    statusFilter?: PaymentStatus[];
    assetFilter?: AssetFilter;
    paymentDetailsFilter?: StoragePaymentDetailsFilter[];
    fromTimestamp?: number;
    toTimestamp?: number;
    offset?: number;
    limit?: number;
    sortAscending?: boolean;
}

export interface ListPaymentsRequest {
    typeFilter?: PaymentType[];
    statusFilter?: PaymentStatus[];
    assetFilter?: AssetFilter;
    paymentDetailsFilter?: PaymentDetailsFilter[];
    fromTimestamp?: number;
    toTimestamp?: number;
    offset?: number;
    limit?: number;
    sortAscending?: boolean;
}

export interface ConversionAsset {
    ticker: string;
    identifier?: string;
    decimals: number;
}

export interface LocalizedName {
    locale: string;
    name: string;
}

export interface ListUnclaimedDepositsResponse {
    deposits: DepositInfo[];
}

export interface LocaleOverrides {
    locale: string;
    spacing?: number;
    symbol: Symbol;
}

export type Fee = { type: "fixed"; amount: number } | { type: "rate"; satPerVbyte: number };

export interface ClaimHtlcPaymentResponse {
    payment: Payment;
}

export type SendPaymentOptions = { type: "bitcoinAddress"; confirmationSpeed: OnchainConfirmationSpeed } | { type: "bolt11Invoice"; preferSpark: boolean; completionTimeoutSecs?: number } | { type: "sparkAddress"; htlcOptions?: SparkHtlcOptions };

export interface SignMessageResponse {
    pubkey: string;
    signature: string;
}

export type StableBalanceActiveLabel = { type: "set"; label: string } | { type: "unset" };

export interface Contact {
    id: string;
    name: string;
    paymentIdentifier: string;
    createdAt: number;
    updatedAt: number;
}

export type PaymentStatus = "completed" | "pending" | "failed";

export interface MessageSuccessActionData {
    message: string;
}

export interface LightningAddressInfo {
    description: string;
    lightningAddress: string;
    lnurl: LnurlInfo;
    username: string;
}

export type SendPaymentMethod = { type: "bitcoinAddress"; address: BitcoinAddressDetails; feeQuote: SendOnchainFeeQuote } | { type: "bolt11Invoice"; invoiceDetails: Bolt11InvoiceDetails; sparkTransferFeeSats?: number; lightningFeeSats: number } | { type: "sparkAddress"; address: string; fee: string; tokenIdentifier?: string } | { type: "sparkInvoice"; sparkInvoiceDetails: SparkInvoiceDetails; fee: string; tokenIdentifier?: string } | { type: "crossChainAddress"; route: CrossChainRoutePair; recipientAddress: string; amountIn: string; estimatedOut: string; feeAmount: string; feeAsset?: string; expiresAt: string; providerContext: CrossChainProviderContext };

export interface ListContactsRequest {
    offset?: number;
    limit?: number;
}

export type Seed = { type: "mnemonic"; mnemonic: string; passphrase?: string } | ({ type: "entropy" } & number[]);

export type Amount = { type: "bitcoin"; amountMsat: number } | { type: "currency"; iso4217Code: string; fractionalAmount: number };

export interface ExternalInputParser {
    providerId: string;
    inputRegex: string;
    parserUrl: string;
}

export interface Symbol {
    grapheme?: string;
    template?: string;
    rtl?: boolean;
    position?: number;
}

export interface ConversionSide {
    chain: ConversionChain;
    asset: ConversionAsset;
    amount: string;
    fee: string;
}

export interface Bolt12InvoiceRequestDetails {}

export type Network = "mainnet" | "regtest";

export interface CheckMessageResponse {
    isValid: boolean;
}

export interface UnregisterWebhookRequest {
    webhookId: string;
}

export interface LightningAddressDetails {
    address: string;
    payRequest: LnurlPayRequestDetails;
}

export interface ConnectRequest {
    config: Config;
    seed: Seed;
    storageDir: string;
}

export interface ReceivePaymentResponse {
    paymentRequest: string;
    fee: bigint;
}

export interface StableBalanceConfig {
    tokens: StableBalanceToken[];
    defaultActiveLabel?: string;
    thresholdSats?: number;
    maxSlippageBps?: number;
}

export interface Bolt11InvoiceDetails {
    amountMsat?: number;
    description?: string;
    descriptionHash?: string;
    expiry: number;
    invoice: Bolt11Invoice;
    minFinalCltvExpiryDelta: number;
    network: BitcoinNetwork;
    payeePubkey: string;
    paymentHash: string;
    paymentSecret: string;
    routingHints: Bolt11RouteHint[];
    timestamp: number;
}

export interface ListPaymentsResponse {
    payments: Payment[];
}

export type WebhookEventType = { type: "lightningReceiveFinished" } | { type: "lightningSendFinished" } | { type: "coopExitFinished" } | { type: "staticDepositFinished" } | ({ type: "unknown" } & string);

export type BitcoinNetwork = "bitcoin" | "testnet3" | "testnet4" | "signet" | "regtest";

export interface GetInfoResponse {
    identityPubkey: string;
    balanceSats: number;
    tokenBalances: Map<string, TokenBalance>;
}

export interface SendPaymentResponse {
    payment: Payment;
}

export interface Bolt12Invoice {
    invoice: string;
    source: PaymentRequestSource;
}

export type AesSuccessActionDataResult = { type: "decrypted"; data: AesSuccessActionDataDecrypted } | { type: "errorStatus"; reason: string };

export type PaymentType = "send" | "receive";

export type CrossChainAddressFamily = "evm" | "solana" | "tron";

export interface Bolt11RouteHintHop {
    srcNodeId: string;
    shortChannelId: string;
    feesBaseMsat: number;
    feesProportionalMillionths: number;
    cltvExpiryDelta: number;
    htlcMinimumMsat?: number;
    htlcMaximumMsat?: number;
}

export interface UrlSuccessActionData {
    description: string;
    url: string;
    matchesCallbackDomain: boolean;
}

export interface ListUnclaimedDepositsRequest {}

export interface StableBalanceToken {
    label: string;
    tokenIdentifier: string;
}

export interface UpdateUserSettingsRequest {
    sparkPrivateModeEnabled?: boolean;
    stableBalanceActiveLabel?: StableBalanceActiveLabel;
}

export interface PrepareSendPaymentResponse {
    paymentMethod: SendPaymentMethod;
    amount: bigint;
    tokenIdentifier?: string;
    conversionEstimate?: ConversionEstimate;
    feePolicy: FeePolicy;
}

export interface LnurlPayResponse {
    payment: Payment;
    successAction?: SuccessActionProcessed;
}

export interface ConversionOptions {
    conversionType: ConversionType;
    maxSlippageBps?: number;
    completionTimeoutSecs?: number;
}

export interface RegisterLightningAddressRequest {
    username: string;
    description?: string;
}

export type OptimizationEvent = { type: "started"; totalRounds: number } | { type: "roundCompleted"; currentRound: number; totalRounds: number } | { type: "completed" } | { type: "cancelled" } | { type: "failed"; error: string } | { type: "skipped" };

export type PaymentDetails = { type: "spark"; invoiceDetails?: SparkInvoicePaymentDetails; htlcDetails?: SparkHtlcDetails; conversionInfo?: ConversionInfo } | { type: "token"; metadata: TokenMetadata; txHash: string; txType: TokenTransactionType; invoiceDetails?: SparkInvoicePaymentDetails; conversionInfo?: ConversionInfo } | { type: "lightning"; description?: string; invoice: string; destinationPubkey: string; htlcDetails: SparkHtlcDetails; lnurlPayInfo?: LnurlPayInfo; lnurlWithdrawInfo?: LnurlWithdrawInfo; lnurlReceiveMetadata?: LnurlReceiveMetadata; conversionInfo?: ConversionInfo } | { type: "withdraw"; txId: string } | { type: "deposit"; txId: string };

export interface CrossChainRoutePair {
    provider: CrossChainProvider;
    chain: string;
    chainId?: string;
    asset: string;
    contractAddress?: string;
    decimals: number;
    exactOutEligible: boolean;
}

/**
 * Interface for passkey PRF (Pseudo-Random Function) operations.
 *
 * Implement this interface to provide passkey PRF functionality for seedless wallet restore.
 *
 * @example
 * ```typescript
 * class BrowserPasskeyPrfProvider implements PasskeyPrfProvider {
 *     async derivePrfSeed(salt: string): Promise<Uint8Array> {
 *         const credential = await navigator.credentials.get({
 *             publicKey: {
 *                 challenge: new Uint8Array(32),
 *                 rpId: window.location.hostname,
 *                 allowCredentials: [], // or specific credential IDs
 *                 extensions: {
 *                     prf: { eval: { first: new TextEncoder().encode(salt) } }
 *                 }
 *             }
 *         });
 *         const results = credential.getClientExtensionResults();
 *         return new Uint8Array(results.prf.results.first);
 *     }
 *
 *     async isPrfAvailable(): Promise<boolean> {
 *         return window.PublicKeyCredential?.isUserVerifyingPlatformAuthenticatorAvailable?.() ?? false;
 *     }
 * }
 * ```
 */
export interface PasskeyPrfProvider {
    /**
     * Derive a 32-byte seed from passkey PRF with the given salt.
     *
     * The platform authenticates the user via passkey and evaluates the PRF extension.
     * The salt is used as input to the PRF to derive a deterministic output.
     *
     * @param salt - The salt string to use for PRF evaluation
     * @returns A Promise resolving to the 32-byte PRF output
     * @throws If authentication fails or PRF is not supported
     */
    derivePrfSeed(salt: string): Promise<Uint8Array>;

    /**
     * Check if a PRF-capable passkey is available on this device.
     *
     * This allows applications to gracefully degrade if passkey PRF is not supported.
     *
     * @returns A Promise resolving to true if PRF-capable passkey is available
     */
    isPrfAvailable(): Promise<boolean>;
}

export interface MintIssuerTokenRequest {
    amount: bigint;
}

export interface BurnIssuerTokenRequest {
    amount: bigint;
}

export interface CreateIssuerTokenRequest {
    name: string;
    ticker: string;
    decimals: number;
    isFreezable: boolean;
    maxSupply: bigint;
}

export interface FreezeIssuerTokenRequest {
    address: string;
}

export interface UnfreezeIssuerTokenRequest {
    address: string;
}

export interface UnfreezeIssuerTokenResponse {
    impactedOutputIds: string[];
    impactedTokenAmount: bigint;
}

export interface FreezeIssuerTokenResponse {
    impactedOutputIds: string[];
    impactedTokenAmount: bigint;
}

export interface ExternalSigner {
    identityPublicKey(): PublicKeyBytes;
    derivePublicKey(path: string): Promise<PublicKeyBytes>;
    signEcdsa(message: MessageBytes, path: string): Promise<EcdsaSignatureBytes>;
    signEcdsaRecoverable(message: MessageBytes, path: string): Promise<RecoverableEcdsaSignatureBytes>;
    encryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    decryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    signHashSchnorr(hash: Uint8Array, path: string): Promise<SchnorrSignatureBytes>;
    generateRandomSigningCommitment(): Promise<ExternalFrostCommitments>;
    getPublicKeyForNode(id: ExternalTreeNodeId): Promise<PublicKeyBytes>;
    generateRandomSecret(): Promise<ExternalEncryptedSecret>;
    staticDepositSecretEncrypted(index: number): Promise<ExternalSecretSource>;
    staticDepositSecret(index: number): Promise<SecretBytes>;
    staticDepositSigningKey(index: number): Promise<PublicKeyBytes>;
    subtractSecrets(signingKey: ExternalSecretSource, newSigningKey: ExternalSecretSource): Promise<ExternalSecretSource>;
    splitSecretWithProofs(secret: ExternalSecretToSplit, threshold: number, numShares: number): Promise<ExternalVerifiableSecretShare[]>;
    encryptPrivateKeyForReceiver(privateKey: ExternalEncryptedSecret, receiverPublicKey: PublicKeyBytes): Promise<Uint8Array>;
    publicKeyFromSecret(privateKey: ExternalSecretSource): Promise<PublicKeyBytes>;
    signFrost(request: ExternalSignFrostRequest): Promise<ExternalFrostSignatureShare>;
    aggregateFrost(request: ExternalAggregateFrostRequest): Promise<ExternalFrostSignature>;
    hmacSha256(message: Uint8Array, path: string): Promise<HashedMessageBytes>;
}

export interface ExternalTreeNodeId {
    id: string;
}

export interface IdentifierPublicKeyPair {
    identifier: ExternalIdentifier;
    publicKey: number[];
}

export interface IdentifierCommitmentPair {
    identifier: ExternalIdentifier;
    commitment: ExternalSigningCommitments;
}

export interface ExternalFrostCommitments {
    hidingCommitment: number[];
    bindingCommitment: number[];
    noncesCiphertext: number[];
}

export interface ExternalSignFrostRequest {
    message: number[];
    publicKey: number[];
    secret: ExternalSecretSource;
    verifyingKey: number[];
    selfNonceCommitment: ExternalFrostCommitments;
    statechainCommitments: IdentifierCommitmentPair[];
    adaptorPublicKey?: number[];
}

export interface ExternalVerifiableSecretShare {
    secretShare: ExternalSecretShare;
    proofs: number[][];
}

export interface ExternalScalar {
    bytes: number[];
}

export interface SchnorrSignatureBytes {
    bytes: number[];
}

export interface ExternalFrostSignatureShare {
    bytes: number[];
}

export interface ExternalEncryptedSecret {
    ciphertext: number[];
}

export interface SecretBytes {
    bytes: number[];
}

export interface EcdsaSignatureBytes {
    bytes: number[];
}

export interface ExternalSecretShare {
    threshold: number;
    index: ExternalScalar;
    share: ExternalScalar;
}

export interface MessageBytes {
    bytes: number[];
}

export interface ExternalAggregateFrostRequest {
    message: number[];
    statechainSignatures: IdentifierSignaturePair[];
    statechainPublicKeys: IdentifierPublicKeyPair[];
    verifyingKey: number[];
    statechainCommitments: IdentifierCommitmentPair[];
    selfCommitment: ExternalSigningCommitments;
    publicKey: number[];
    selfSignature: ExternalFrostSignatureShare;
    adaptorPublicKey?: number[];
}

export type ExternalSecretSource = { type: "derived"; nodeId: ExternalTreeNodeId } | { type: "encrypted"; key: ExternalEncryptedSecret };

export interface PublicKeyBytes {
    bytes: number[];
}

export interface RecoverableEcdsaSignatureBytes {
    bytes: number[];
}

export interface IdentifierSignaturePair {
    identifier: ExternalIdentifier;
    signature: ExternalFrostSignatureShare;
}

export type ExternalSecretToSplit = { type: "secretSource"; source: ExternalSecretSource } | { type: "preimage"; data: number[] };

export interface ExternalFrostSignature {
    bytes: number[];
}

export interface HashedMessageBytes {
    bytes: number[];
}

export interface ExternalIdentifier {
    bytes: number[];
}

export interface ExternalSigningCommitments {
    hiding: number[];
    binding: number[];
}

/**
 * A wallet derived from a passkey.
 */
export interface Wallet {
    /**
     * The derived seed.
     */
    seed: Seed;
    /**
     * The label used for derivation.
     */
    label: string;
}

/**
 * Nostr relay configuration for passkey label operations.
 *
 * Used by `Passkey.listLabels` and `Passkey.storeLabel`.
 */
export interface NostrRelayConfig {
    /**
     * Optional Breez API key for authenticated access to the Breez relay.
     * When provided, the Breez relay is added and NIP-42 authentication is enabled.
     */
    breezApiKey?: string;
    /**
     * Connection timeout in seconds. Defaults to 30 when `None`.
     */
    timeoutSecs?: number;
}

export interface Storage {
    getCachedItem: (key: string) => Promise<string | null>;
    setCachedItem: (key: string, value: string) => Promise<void>;
    deleteCachedItem: (key: string) => Promise<void>;
    listPayments: (request: StorageListPaymentsRequest) => Promise<Payment[]>;
    insertPayment: (payment: Payment) => Promise<void>;
    insertPaymentMetadata: (paymentId: string, metadata: PaymentMetadata) => Promise<void>;
    getPaymentById: (id: string) => Promise<Payment>;
    getPaymentByInvoice: (invoice: string) => Promise<Payment>;
    addDeposit: (txid: string, vout: number, amount_sats: number, isMature: boolean) => Promise<void>;
    deleteDeposit: (txid: string, vout: number) => Promise<void>;
    listDeposits: () => Promise<DepositInfo[]>;
    updateDeposit: (txid: string, vout: number, payload: UpdateDepositPayload) => Promise<void>;
    setLnurlMetadata: (metadata: SetLnurlMetadataItem[]) => Promise<void>;
    getPaymentsByParentIds: (parentPaymentIds: string[]) => Promise<{ [parentId: string]: RelatedPayment[] }>;
    listContacts: (request: ListContactsRequest) => Promise<Contact[]>;
    getContact: (id: string) => Promise<Contact>;
    insertContact: (contact: Contact) => Promise<void>;
    deleteContact: (id: string) => Promise<void>;
    syncAddOutgoingChange: (record: UnversionedRecordChange) => Promise<number>;
    syncCompleteOutgoingSync: (record: Record) => Promise<void>;
    syncGetPendingOutgoingChanges: (limit: number) => Promise<OutgoingChange[]>;
    syncGetLastRevision: () => Promise<number>;
    syncInsertIncomingRecords: (records: Record[]) => Promise<void>;
    syncDeleteIncomingRecord: (record: Record) => Promise<void>;
    syncGetIncomingRecords: (limit: number) => Promise<IncomingChange[]>;
    syncGetLatestOutgoingChange: () => Promise<OutgoingChange | null>;
    syncUpdateRecordFromIncoming: (record: Record) => Promise<void>;
}

export class BreezSdk {
  private constructor();
  free(): void;
  disconnect(): Promise<void>;
  lnurlAuth(request_data: LnurlAuthRequestDetails): Promise<LnurlCallbackStatus>;
  addContact(request: AddContactRequest): Promise<Contact>;
  buyBitcoin(request: BuyBitcoinRequest): Promise<BuyBitcoinResponse>;
  getPayment(request: GetPaymentRequest): Promise<GetPaymentResponse>;
  syncWallet(request: SyncWalletRequest): Promise<SyncWalletResponse>;
  sendPayment(request: SendPaymentRequest): Promise<SendPaymentResponse>;
  signMessage(request: SignMessageRequest): Promise<SignMessageResponse>;
  checkMessage(request: CheckMessageRequest): Promise<CheckMessageResponse>;
  claimDeposit(request: ClaimDepositRequest): Promise<ClaimDepositResponse>;
  listContacts(request: ListContactsRequest): Promise<Contact[]>;
  listPayments(request: ListPaymentsRequest): Promise<ListPaymentsResponse>;
  listWebhooks(): Promise<Webhook[]>;
  deleteContact(id: string): Promise<void>;
  lnurlWithdraw(request: LnurlWithdrawRequest): Promise<LnurlWithdrawResponse>;
  refundDeposit(request: RefundDepositRequest): Promise<RefundDepositResponse>;
  updateContact(request: UpdateContactRequest): Promise<Contact>;
  listFiatRates(): Promise<ListFiatRatesResponse>;
  receivePayment(request: ReceivePaymentRequest): Promise<ReceivePaymentResponse>;
  getTokenIssuer(): TokenIssuer;
  recommendedFees(): Promise<RecommendedFees>;
  registerWebhook(request: RegisterWebhookRequest): Promise<RegisterWebhookResponse>;
  getUserSettings(): Promise<UserSettings>;
  prepareLnurlPay(request: PrepareLnurlPayRequest): Promise<PrepareLnurlPayResponse>;
  addEventListener(listener: EventListener): Promise<string>;
  claimHtlcPayment(request: ClaimHtlcPaymentRequest): Promise<ClaimHtlcPaymentResponse>;
  unregisterWebhook(request: UnregisterWebhookRequest): Promise<void>;
  getTokensMetadata(request: GetTokensMetadataRequest): Promise<GetTokensMetadataResponse>;
  listFiatCurrencies(): Promise<ListFiatCurrenciesResponse>;
  prepareSendPayment(request: PrepareSendPaymentRequest): Promise<PrepareSendPaymentResponse>;
  updateUserSettings(request: UpdateUserSettingsRequest): Promise<void>;
  getLightningAddress(): Promise<LightningAddressInfo | undefined>;
  removeEventListener(id: string): Promise<boolean>;
  getCrossChainRoutes(filter: CrossChainRouteFilter): Promise<CrossChainRoutePair[]>;
  fetchConversionLimits(request: FetchConversionLimitsRequest): Promise<FetchConversionLimitsResponse>;
  listUnclaimedDeposits(request: ListUnclaimedDepositsRequest): Promise<ListUnclaimedDepositsResponse>;
  startLeafOptimization(): Promise<void>;
  cancelLeafOptimization(): Promise<void>;
  deleteLightningAddress(): Promise<void>;
  registerLightningAddress(request: RegisterLightningAddressRequest): Promise<LightningAddressInfo>;
  getLeafOptimizationProgress(): OptimizationProgress;
  checkLightningAddressAvailable(request: CheckLightningAddressRequest): Promise<boolean>;
  parse(input: string): Promise<InputType>;
  getInfo(request: GetInfoRequest): Promise<GetInfoResponse>;
  lnurlPay(request: LnurlPayRequest): Promise<LnurlPayResponse>;
}
/**
 * A default signer implementation that wraps the core SDK's ExternalSigner.
 * This is returned by `defaultExternalSigner` and can be passed to `connectWithSigner`.
 */
export class DefaultSigner {
  private constructor();
  free(): void;
  signEcdsa(message: MessageBytes, path: string): Promise<EcdsaSignatureBytes>;
  signFrost(request: ExternalSignFrostRequest): Promise<ExternalFrostSignatureShare>;
  hmacSha256(message: Uint8Array, path: string): Promise<HashedMessageBytes>;
  decryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
  encryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
  aggregateFrost(request: ExternalAggregateFrostRequest): Promise<ExternalFrostSignature>;
  subtractSecrets(signing_key: ExternalSecretSource, new_signing_key: ExternalSecretSource): Promise<ExternalSecretSource>;
  derivePublicKey(path: string): Promise<PublicKeyBytes>;
  signHashSchnorr(hash: Uint8Array, path: string): Promise<SchnorrSignatureBytes>;
  identityPublicKey(): PublicKeyBytes;
  staticDepositSecret(index: number): Promise<SecretBytes>;
  generateRandomSecret(): Promise<ExternalEncryptedSecret>;
  publicKeyFromSecret(private_key: ExternalSecretSource): Promise<PublicKeyBytes>;
  signEcdsaRecoverable(message: MessageBytes, path: string): Promise<RecoverableEcdsaSignatureBytes>;
  getPublicKeyForNode(id: ExternalTreeNodeId): Promise<PublicKeyBytes>;
  splitSecretWithProofs(secret: ExternalSecretToSplit, threshold: number, num_shares: number): Promise<ExternalVerifiableSecretShare[]>;
  staticDepositSigningKey(index: number): Promise<PublicKeyBytes>;
  encryptPrivateKeyForReceiver(private_key: ExternalEncryptedSecret, receiver_public_key: PublicKeyBytes): Promise<Uint8Array>;
  staticDepositSecretEncrypted(index: number): Promise<ExternalSecretSource>;
  generateRandomSigningCommitment(): Promise<ExternalFrostCommitments>;
}
export class IntoUnderlyingByteSource {
  private constructor();
  free(): void;
  pull(controller: ReadableByteStreamController): Promise<any>;
  start(controller: ReadableByteStreamController): void;
  cancel(): void;
  readonly autoAllocateChunkSize: number;
  readonly type: ReadableStreamType;
}
export class IntoUnderlyingSink {
  private constructor();
  free(): void;
  abort(reason: any): Promise<any>;
  close(): Promise<any>;
  write(chunk: any): Promise<any>;
}
export class IntoUnderlyingSource {
  private constructor();
  free(): void;
  pull(controller: ReadableStreamDefaultController): Promise<any>;
  cancel(): void;
}
/**
 * Passkey-based wallet operations using WebAuthn PRF extension.
 *
 * Wraps a `PasskeyPrfProvider` and optional relay configuration to provide
 * wallet derivation and label management via Nostr relays.
 */
export class Passkey {
  free(): void;
  /**
   * Derive a wallet for a given label.
   *
   * Uses the passkey PRF to derive a `Wallet` containing the seed and resolved label.
   *
   * @param label - Optional label string (defaults to "Default")
   */
  getWallet(label?: string | null): Promise<Wallet>;
  /**
   * List all labels published to Nostr for this passkey's identity.
   *
   * Requires 1 PRF call (for Nostr identity derivation).
   */
  listLabels(): Promise<string[]>;
  /**
   * Publish a label to Nostr relays for this passkey's identity.
   *
   * Idempotent: if the label already exists, it is not published again.
   * Requires 1 PRF call.
   */
  storeLabel(label: string): Promise<void>;
  /**
   * Check if passkey PRF is available on this device.
   */
  isAvailable(): Promise<boolean>;
  /**
   * Create a new `Passkey` instance.
   *
   * @param prfProvider - Platform implementation of passkey PRF operations
   * @param relayConfig - Optional configuration for Nostr relay connections
   */
  constructor(prf_provider: PasskeyPrfProvider, relay_config?: NostrRelayConfig | null);
}
export class SdkBuilder {
  private constructor();
  free(): void;
  withKeySet(config: KeySetConfig): SdkBuilder;
  withStorage(storage: Storage): SdkBuilder;
  static newWithSigner(config: Config, signer: ExternalSigner): SdkBuilder;
  withFiatService(fiat_service: FiatService): SdkBuilder;
  withLnurlClient(lnurl_client: RestClient): SdkBuilder;
  withChainService(chain_service: BitcoinChainService): SdkBuilder;
  withDefaultStorage(storage_dir: string): Promise<SdkBuilder>;
  withPaymentObserver(payment_observer: PaymentObserver): SdkBuilder;
  withPostgresBackend(config: PostgresStorageConfig): SdkBuilder;
  withRestChainService(url: string, api_type: ChainApiType, credentials?: Credentials | null): SdkBuilder;
  static new(config: Config, seed: Seed): SdkBuilder;
  build(): Promise<BreezSdk>;
}
export class TokenIssuer {
  private constructor();
  free(): void;
  burnIssuerToken(request: BurnIssuerTokenRequest): Promise<Payment>;
  mintIssuerToken(request: MintIssuerTokenRequest): Promise<Payment>;
  createIssuerToken(request: CreateIssuerTokenRequest): Promise<TokenMetadata>;
  freezeIssuerToken(request: FreezeIssuerTokenRequest): Promise<FreezeIssuerTokenResponse>;
  unfreezeIssuerToken(request: UnfreezeIssuerTokenRequest): Promise<UnfreezeIssuerTokenResponse>;
  getIssuerTokenBalance(): Promise<TokenBalance>;
  getIssuerTokenMetadata(): Promise<TokenMetadata>;
}
