// Node.js entry point for Breez SDK with automatic storage support
const wasmModule = require('./breez_sdk_spark_wasm.js');

// Automatically import and set up the storage for Node.js
try {
    const { createDefaultStorage } = require('./storage/index.cjs');
    
    // Make createDefaultStorage available globally for WASM to find
    global.createDefaultStorage = createDefaultStorage;
    
    console.log('Breez SDK: Node.js storage automatically enabled');
} catch (error) {
    console.warn('Breez SDK: Failed to load Node.js storage:', error.message);
    console.warn('Breez SDK: Storage operations may not work properly. Ignore this warning if you are not using the default storage.');
}

// Export all WASM functions
module.exports = wasmModule;
