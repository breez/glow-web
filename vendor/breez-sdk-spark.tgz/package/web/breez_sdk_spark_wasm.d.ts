/* tslint:disable */
/* eslint-disable */
/**
 * Creates a default external signer from a mnemonic phrase.
 *
 * This creates a signer that can be used with `connectWithSigner` or `SdkBuilder.newWithSigner`.
 */
export function getSparkStatus(): Promise<SparkStatus>;
export function connect(request: ConnectRequest): Promise<BreezSdk>;
export function initLogging(logger: Logger, filter?: string | null): Promise<void>;
export function defaultExternalSigner(mnemonic: string, passphrase: string | null | undefined, network: Network, key_set_config?: KeySetConfig | null): DefaultSigner;
export function defaultConfig(network: Network): Config;
export function connectWithSigner(config: Config, signer: ExternalSigner, storage_dir: string): Promise<BreezSdk>;
/**
 * Entry point invoked by JavaScript in a worker.
 */
export function task_worker_entry_point(ptr: number): void;
/**
 * The `ReadableStreamType` enum.
 *
 * *This API requires the following crate features to be activated: `ReadableStreamType`*
 */
type ReadableStreamType = "bytes";
export interface EventListener {
    onEvent: (e: SdkEvent) => void;
}

export interface Logger {
    log: (l: LogEntry) => void;
}

export interface RestClient {
    getRequest(url: string, headers?: Record<string, string>): Promise<RestResponse>;
    postRequest(url: string, headers?: Record<string, string>, body?: string): Promise<RestResponse>;
    deleteRequest(url: string, headers?: Record<string, string>, body?: string): Promise<RestResponse>;
}

export interface RestResponse {
    status: number;
    body: string;
}

export interface FiatService {
    fetchFiatCurrencies(): Promise<FiatCurrency[]>;
    fetchFiatRates(): Promise<Rate[]>;
}

export interface BitcoinChainService {
    getAddressUtxos(address: string): Promise<Utxo[]>;
    getTransactionStatus(txid: string): Promise<TxStatus>;
    getTransactionHex(txid: string): Promise<string>;
    broadcastTransaction(tx: string): Promise<void>;
    recommendedFees(): Promise<RecommendedFees>;
}

export type ChainApiType = "esplora" | "mempoolSpace";

export interface TxStatus {
    confirmed: boolean;
    blockHeight?: number;
    blockTime?: number;
}

export interface Utxo {
    txid: string;
    vout: number;
    value: number;
    status: TxStatus;
}

export interface RecommendedFees {
    fastestFee: number;
    halfHourFee: number;
    hourFee: number;
    economyFee: number;
    minimumFee: number;
}

export interface PaymentObserver {
    beforeSend: (payments: ProvisionalPayment[]) => Promise<void>;
}

export interface BuyBitcoinRequest {
    lockedAmountSat?: number;
    redirectUrl?: string;
}

export interface ListPaymentsResponse {
    payments: Payment[];
}

export interface ClaimDepositResponse {
    payment: Payment;
}

export interface TokenMetadata {
    identifier: string;
    issuerPublicKey: string;
    name: string;
    ticker: string;
    decimals: number;
    maxSupply: string;
    isFreezable: boolean;
}

export interface Bolt12Offer {
    offer: string;
    source: PaymentRequestSource;
}

export interface GetTokensMetadataRequest {
    tokenIdentifiers: string[];
}

export type ConversionStatus = "completed" | "refundNeeded" | "refunded";

export type Amount = { type: "bitcoin"; amountMsat: number } | { type: "currency"; iso4217Code: string; fractionalAmount: number };

export interface Bip21Extra {
    key: string;
    value: string;
}

export interface Payment {
    id: string;
    paymentType: PaymentType;
    status: PaymentStatus;
    amount: bigint;
    fees: bigint;
    timestamp: number;
    method: PaymentMethod;
    details?: PaymentDetails;
    conversionDetails?: ConversionDetails;
}

export interface CheckMessageResponse {
    isValid: boolean;
}

export type LnurlCallbackStatus = { type: "ok" } | { type: "errorStatus"; errorDetails: LnurlErrorDetails };

export interface LnurlWithdrawRequestDetails {
    callback: string;
    k1: string;
    defaultDescription: string;
    minWithdrawable: number;
    maxWithdrawable: number;
}

export interface OptimizationConfig {
    autoEnabled: boolean;
    multiplicity: number;
}

export type Seed = { type: "mnemonic"; mnemonic: string; passphrase?: string } | ({ type: "entropy" } & number[]);

export type OnchainConfirmationSpeed = "fast" | "medium" | "slow";

export interface ListUnclaimedDepositsResponse {
    deposits: DepositInfo[];
}

export interface SendOnchainSpeedFeeQuote {
    userFeeSat: number;
    l1BroadcastFeeSat: number;
}

export interface SparkStatus {
    status: ServiceStatus;
    lastUpdated: number;
}

export interface SendOnchainFeeQuote {
    id: string;
    expiresAt: number;
    speedFast: SendOnchainSpeedFeeQuote;
    speedMedium: SendOnchainSpeedFeeQuote;
    speedSlow: SendOnchainSpeedFeeQuote;
}

export interface Config {
    apiKey?: string;
    network: Network;
    syncIntervalSecs: number;
    maxDepositClaimFee?: MaxFee;
    lnurlDomain?: string;
    preferSparkOverLightning: boolean;
    externalInputParsers?: ExternalInputParser[];
    useDefaultExternalInputParsers: boolean;
    realTimeSyncServerUrl?: string;
    privateEnabledDefault: boolean;
    optimizationConfig: OptimizationConfig;
}

export type KeySetType = "default" | "taproot" | "nativeSegwit" | "wrappedSegwit" | "legacy";

export interface PaymentRequestSource {
    bip21Uri?: string;
    bip353Address?: string;
}

export interface UnversionedRecordChange {
    id: RecordId;
    schemaVersion: string;
    updatedFields: Map<string, string>;
}

export interface RecordId {
    type: string;
    dataId: string;
}

export type Fee = { type: "fixed"; amount: number } | { type: "rate"; satPerVbyte: number };

export interface LocalizedName {
    locale: string;
    name: string;
}

export interface SparkHtlcOptions {
    paymentHash: string;
    expiryDurationSecs: number;
}

export interface SyncWalletRequest {}

export type MaxFee = { type: "fixed"; amount: number } | { type: "rate"; satPerVbyte: number } | { type: "networkRecommended"; leewaySatPerVbyte: number };

export interface Bip21Details {
    amountSat?: number;
    assetId?: string;
    uri: string;
    extras: Bip21Extra[];
    label?: string;
    message?: string;
    paymentMethods: InputType[];
}

export interface UpdateUserSettingsRequest {
    sparkPrivateModeEnabled?: boolean;
}

export interface Bolt11RouteHint {
    hops: Bolt11RouteHintHop[];
}

export interface SparkInvoiceDetails {
    invoice: string;
    identityPublicKey: string;
    network: BitcoinNetwork;
    amount?: string;
    tokenIdentifier?: string;
    expiryTime?: number;
    description?: string;
    senderPublicKey?: string;
}

export interface CheckMessageRequest {
    message: string;
    pubkey: string;
    signature: string;
}

export interface LnurlErrorDetails {
    reason: string;
}

export interface OutgoingChange {
    change: RecordChange;
    parent?: Record;
}

export interface GetInfoResponse {
    identityPubkey: string;
    balanceSats: number;
    tokenBalances: Map<string, TokenBalance>;
}

export type InputType = ({ type: "bitcoinAddress" } & BitcoinAddressDetails) | ({ type: "bolt11Invoice" } & Bolt11InvoiceDetails) | ({ type: "bolt12Invoice" } & Bolt12InvoiceDetails) | ({ type: "bolt12Offer" } & Bolt12OfferDetails) | ({ type: "lightningAddress" } & LightningAddressDetails) | ({ type: "lnurlPay" } & LnurlPayRequestDetails) | ({ type: "silentPaymentAddress" } & SilentPaymentAddressDetails) | ({ type: "lnurlAuth" } & LnurlAuthRequestDetails) | ({ type: "url" } & string) | ({ type: "bip21" } & Bip21Details) | ({ type: "bolt12InvoiceRequest" } & Bolt12InvoiceRequestDetails) | ({ type: "lnurlWithdraw" } & LnurlWithdrawRequestDetails) | ({ type: "sparkAddress" } & SparkAddressDetails) | ({ type: "sparkInvoice" } & SparkInvoiceDetails);

export interface DepositInfo {
    txid: string;
    vout: number;
    amountSats: number;
    refundTx?: string;
    refundTxId?: string;
    claimError?: DepositClaimError;
}

export interface LocaleOverrides {
    locale: string;
    spacing?: number;
    symbol: Symbol;
}

export interface Bolt12InvoiceRequestDetails {}

export interface ClaimHtlcPaymentResponse {
    payment: Payment;
}

export interface UrlSuccessActionData {
    description: string;
    url: string;
    matchesCallbackDomain: boolean;
}

export interface BitcoinAddressDetails {
    address: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface UserSettings {
    sparkPrivateModeEnabled: boolean;
}

export interface LnurlPayResponse {
    payment: Payment;
    successAction?: SuccessActionProcessed;
}

export type SuccessAction = { type: "aes"; data: AesSuccessActionData } | { type: "message"; data: MessageSuccessActionData } | { type: "url"; data: UrlSuccessActionData };

export type AssetFilter = { type: "bitcoin" } | { type: "token"; tokenIdentifier?: string };

export interface ConversionStep {
    paymentId: string;
    amount: bigint;
    fee: bigint;
    method: PaymentMethod;
    tokenMetadata?: TokenMetadata;
}

export type BitcoinNetwork = "bitcoin" | "testnet3" | "testnet4" | "signet" | "regtest";

export interface FiatCurrency {
    id: string;
    info: CurrencyInfo;
}

export interface GetPaymentResponse {
    payment: Payment;
}

export interface LogEntry {
    line: string;
    level: string;
}

export type ConversionType = { type: "fromBitcoin" } | { type: "toBitcoin"; fromTokenIdentifier: string };

export type PaymentDetailsFilter = { type: "spark"; htlcStatus?: SparkHtlcStatus[]; conversionRefundNeeded?: boolean } | { type: "token"; conversionRefundNeeded?: boolean; txHash?: string; txType?: TokenTransactionType };

export type UpdateDepositPayload = { type: "claimError"; error: DepositClaimError } | { type: "refund"; refundTxid: string; refundTx: string };

export interface ConversionInfo {
    poolId: string;
    conversionId: string;
    status: ConversionStatus;
    fee?: string;
    purpose?: ConversionPurpose;
}

export interface ReceivePaymentResponse {
    paymentRequest: string;
    fee: bigint;
}

export interface ListPaymentsRequest {
    typeFilter?: PaymentType[];
    statusFilter?: PaymentStatus[];
    assetFilter?: AssetFilter;
    paymentDetailsFilter?: PaymentDetailsFilter[];
    fromTimestamp?: number;
    toTimestamp?: number;
    offset?: number;
    limit?: number;
    sortAscending?: boolean;
}

export interface ListFiatCurrenciesResponse {
    currencies: FiatCurrency[];
}

export interface SendPaymentResponse {
    payment: Payment;
}

export interface SparkInvoicePaymentDetails {
    description?: string;
    invoice: string;
}

export interface ProvisionalPayment {
    paymentId: string;
    amount: bigint;
    details: ProvisionalPaymentDetails;
}

export interface LnurlWithdrawInfo {
    withdrawUrl: string;
}

export interface LnurlPayInfo {
    lnAddress?: string;
    comment?: string;
    domain?: string;
    metadata?: string;
    processedSuccessAction?: SuccessActionProcessed;
    rawSuccessAction?: SuccessAction;
}

export type ServiceStatus = "operational" | "degraded" | "partial" | "unknown" | "major";

export interface Symbol {
    grapheme?: string;
    template?: string;
    rtl?: boolean;
    position?: number;
}

export interface SignMessageRequest {
    message: string;
    compact: boolean;
}

export type SendPaymentMethod = { type: "bitcoinAddress"; address: BitcoinAddressDetails; feeQuote: SendOnchainFeeQuote } | { type: "bolt11Invoice"; invoiceDetails: Bolt11InvoiceDetails; sparkTransferFeeSats?: number; lightningFeeSats: number } | { type: "sparkAddress"; address: string; fee: string; tokenIdentifier?: string } | { type: "sparkInvoice"; sparkInvoiceDetails: SparkInvoiceDetails; fee: string; tokenIdentifier?: string };

export type AesSuccessActionDataResult = { type: "decrypted"; data: AesSuccessActionDataDecrypted } | { type: "errorStatus"; reason: string };

export interface RefundDepositRequest {
    txid: string;
    vout: number;
    destinationAddress: string;
    fee: Fee;
}

export type OptimizationEvent = { type: "started"; totalRounds: number } | { type: "roundCompleted"; currentRound: number; totalRounds: number } | { type: "completed" } | { type: "cancelled" } | { type: "failed"; error: string } | { type: "skipped" };

export interface SilentPaymentAddressDetails {
    address: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface Bolt12OfferBlindedPath {
    blindedHops: string[];
}

export type SendPaymentOptions = { type: "bitcoinAddress"; confirmationSpeed: OnchainConfirmationSpeed } | { type: "bolt11Invoice"; preferSpark: boolean; completionTimeoutSecs?: number } | { type: "sparkAddress"; htlcOptions?: SparkHtlcOptions };

export type PaymentStatus = "completed" | "pending" | "failed";

export type FeePolicy = "feesExcluded" | "feesIncluded";

export interface LightningAddressDetails {
    address: string;
    payRequest: LnurlPayRequestDetails;
}

export interface LnurlWithdrawResponse {
    paymentRequest: string;
    payment?: Payment;
}

export interface LnurlPayRequest {
    prepareResponse: PrepareLnurlPayResponse;
    idempotencyKey?: string;
}

export interface ConversionOptions {
    conversionType: ConversionType;
    maxSlippageBps?: number;
    completionTimeoutSecs?: number;
}

export interface KeySetConfig {
    keySetType: KeySetType;
    useAddressIndex: boolean;
    accountNumber?: number;
}

export interface ConnectRequest {
    config: Config;
    seed: Seed;
    storageDir: string;
}

export interface RegisterLightningAddressRequest {
    username: string;
    description?: string;
}

export type PaymentType = "send" | "receive";

export interface ReceivePaymentRequest {
    paymentMethod: ReceivePaymentMethod;
}

export interface TokenBalance {
    balance: bigint;
    tokenMetadata: TokenMetadata;
}

export interface Rate {
    coin: string;
    value: number;
}

export interface CheckLightningAddressRequest {
    username: string;
}

export interface AesSuccessActionData {
    description: string;
    ciphertext: string;
    iv: string;
}

export interface PaymentMetadata {
    parentPaymentId?: string;
    lnurlPayInfo?: LnurlPayInfo;
    lnurlWithdrawInfo?: LnurlWithdrawInfo;
    lnurlDescription?: string;
    conversionInfo?: ConversionInfo;
}

export interface ClaimDepositRequest {
    txid: string;
    vout: number;
    maxFee?: MaxFee;
}

export interface GetInfoRequest {
    ensureSynced?: boolean;
}

export interface MessageSuccessActionData {
    message: string;
}

export interface LnurlInfo {
    url: string;
    bech32: string;
}

export type SuccessActionProcessed = { type: "aes"; result: AesSuccessActionDataResult } | { type: "message"; data: MessageSuccessActionData } | { type: "url"; data: UrlSuccessActionData };

export type Network = "mainnet" | "regtest";

export type ReceivePaymentMethod = { type: "sparkAddress" } | { type: "sparkInvoice"; amount?: string; tokenIdentifier?: string; expiryTime?: number; description?: string; senderPublicKey?: string } | { type: "bitcoinAddress" } | { type: "bolt11Invoice"; description: string; amountSats?: number; expirySecs?: number };

export interface SetLnurlMetadataItem {
    paymentHash: string;
    senderComment?: string;
    nostrZapRequest?: string;
    nostrZapReceipt?: string;
}

export interface SignMessageResponse {
    pubkey: string;
    signature: string;
}

export interface ConversionEstimate {
    options: ConversionOptions;
    amount: bigint;
    fee: bigint;
}

export interface RecordChange {
    id: RecordId;
    schemaVersion: string;
    updatedFields: Map<string, string>;
    revision: number;
}

export type ProvisionalPaymentDetails = { type: "bitcoin"; withdrawalAddress: string } | { type: "lightning"; invoice: string } | { type: "spark"; payRequest: string } | { type: "token"; tokenId: string; payRequest: string };

export type PaymentDetails = { type: "spark"; invoiceDetails?: SparkInvoicePaymentDetails; htlcDetails?: SparkHtlcDetails; conversionInfo?: ConversionInfo } | { type: "token"; metadata: TokenMetadata; txHash: string; txType: TokenTransactionType; invoiceDetails?: SparkInvoicePaymentDetails; conversionInfo?: ConversionInfo } | { type: "lightning"; description?: string; preimage?: string; invoice: string; paymentHash: string; destinationPubkey: string; lnurlPayInfo?: LnurlPayInfo; lnurlWithdrawInfo?: LnurlWithdrawInfo; lnurlReceiveMetadata?: LnurlReceiveMetadata } | { type: "withdraw"; txId: string } | { type: "deposit"; txId: string };

export interface LnurlPayRequestDetails {
    callback: string;
    minSendable: number;
    maxSendable: number;
    metadataStr: string;
    commentAllowed: number;
    domain: string;
    url: string;
    address?: string;
    allowsNostr?: boolean;
    nostrPubkey?: string;
}

export interface GetPaymentRequest {
    paymentId: string;
}

export type DepositClaimError = { type: "maxDepositClaimFeeExceeded"; tx: string; vout: number; maxFee?: Fee; requiredFeeSats: number; requiredFeeRateSatPerVbyte: number } | { type: "missingUtxo"; tx: string; vout: number } | { type: "generic"; message: string };

export interface ClaimHtlcPaymentRequest {
    preimage: string;
}

export interface RefundDepositResponse {
    txId: string;
    txHex: string;
}

export interface FetchConversionLimitsResponse {
    minFromAmount?: bigint;
    minToAmount?: bigint;
}

export type SparkHtlcStatus = "waitingForPreimage" | "preimageShared" | "returned";

export interface Record {
    id: RecordId;
    revision: number;
    schemaVersion: string;
    data: Map<string, string>;
}

export interface GetTokensMetadataResponse {
    tokensMetadata: TokenMetadata[];
}

export interface ListUnclaimedDepositsRequest {}

export interface SparkHtlcDetails {
    paymentHash: string;
    preimage?: string;
    expiryTime: number;
    status: SparkHtlcStatus;
}

export interface SyncWalletResponse {}

export interface LightningAddressInfo {
    description: string;
    lightningAddress: string;
    lnurl: LnurlInfo;
    username: string;
}

export interface SparkAddressDetails {
    address: string;
    identityPublicKey: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface ListFiatRatesResponse {
    rates: Rate[];
}

export type PaymentMethod = "lightning" | "spark" | "token" | "deposit" | "withdraw" | "unknown";

export interface PrepareLnurlPayResponse {
    amountSats: number;
    comment?: string;
    payRequest: LnurlPayRequestDetails;
    feeSats: number;
    invoiceDetails: Bolt11InvoiceDetails;
    successAction?: SuccessAction;
    conversionEstimate?: ConversionEstimate;
    feePolicy: FeePolicy;
}

export interface AesSuccessActionDataDecrypted {
    description: string;
    plaintext: string;
}

export interface ExternalInputParser {
    providerId: string;
    inputRegex: string;
    parserUrl: string;
}

export interface IncomingChange {
    newState: Record;
    oldState?: Record;
}

export interface ConversionDetails {
    from: ConversionStep;
    to: ConversionStep;
}

export interface FetchConversionLimitsRequest {
    conversionType: ConversionType;
    tokenIdentifier?: string;
}

export interface SendPaymentRequest {
    prepareResponse: PrepareSendPaymentResponse;
    options?: SendPaymentOptions;
    idempotencyKey?: string;
}

export interface LnurlAuthRequestDetails {
    k1: string;
    action?: string;
    domain: string;
    url: string;
}

export interface LnurlWithdrawRequest {
    amountSats: number;
    withdrawRequest: LnurlWithdrawRequestDetails;
    completionTimeoutSecs?: number;
}

export interface BuyBitcoinResponse {
    url: string;
}

export interface PrepareLnurlPayRequest {
    amountSats: number;
    comment?: string;
    payRequest: LnurlPayRequestDetails;
    validateSuccessActionUrl?: boolean;
    conversionOptions?: ConversionOptions;
    feePolicy?: FeePolicy;
}

export interface Bolt11RouteHintHop {
    srcNodeId: string;
    shortChannelId: string;
    feesBaseMsat: number;
    feesProportionalMillionths: number;
    cltvExpiryDelta: number;
    htlcMinimumMsat?: number;
    htlcMaximumMsat?: number;
}

export interface Bolt11Invoice {
    bolt11: string;
    source: PaymentRequestSource;
}

export interface PrepareSendPaymentRequest {
    paymentRequest: string;
    amount?: bigint;
    tokenIdentifier?: string;
    conversionOptions?: ConversionOptions;
    feePolicy?: FeePolicy;
}

export type SdkEvent = { type: "synced" } | { type: "unclaimedDeposits"; unclaimedDeposits: DepositInfo[] } | { type: "claimedDeposits"; claimedDeposits: DepositInfo[] } | { type: "paymentSucceeded"; payment: Payment } | { type: "paymentPending"; payment: Payment } | { type: "paymentFailed"; payment: Payment } | { type: "optimization"; optimizationEvent: OptimizationEvent };

export interface PrepareSendPaymentResponse {
    paymentMethod: SendPaymentMethod;
    amount: bigint;
    tokenIdentifier?: string;
    conversionEstimate?: ConversionEstimate;
    feePolicy: FeePolicy;
}

export type TokenTransactionType = "transfer" | "mint" | "burn";

export interface Bolt12InvoiceDetails {
    amountMsat: number;
    invoice: Bolt12Invoice;
}

export interface OptimizationProgress {
    isRunning: boolean;
    currentRound: number;
    totalRounds: number;
}

export type ConversionPurpose = { type: "ongoingPayment"; paymentRequest: string } | { type: "selfTransfer" };

export interface Credentials {
    username: string;
    password: string;
}

export interface Bolt11InvoiceDetails {
    amountMsat?: number;
    description?: string;
    descriptionHash?: string;
    expiry: number;
    invoice: Bolt11Invoice;
    minFinalCltvExpiryDelta: number;
    network: BitcoinNetwork;
    payeePubkey: string;
    paymentHash: string;
    paymentSecret: string;
    routingHints: Bolt11RouteHint[];
    timestamp: number;
}

export interface Bolt12OfferDetails {
    absoluteExpiry?: number;
    chains: string[];
    description?: string;
    issuer?: string;
    minAmount?: Amount;
    offer: Bolt12Offer;
    paths: Bolt12OfferBlindedPath[];
    signingPubkey?: string;
}

export interface CurrencyInfo {
    name: string;
    fractionSize: number;
    spacing?: number;
    symbol?: Symbol;
    uniqSymbol?: Symbol;
    localizedName: LocalizedName[];
    localeOverrides: LocaleOverrides[];
}

export interface Bolt12Invoice {
    invoice: string;
    source: PaymentRequestSource;
}

export interface LnurlReceiveMetadata {
    nostrZapRequest?: string;
    nostrZapReceipt?: string;
    senderComment?: string;
}

export interface FreezeIssuerTokenResponse {
    impactedOutputIds: string[];
    impactedTokenAmount: bigint;
}

export interface FreezeIssuerTokenRequest {
    address: string;
}

export interface UnfreezeIssuerTokenResponse {
    impactedOutputIds: string[];
    impactedTokenAmount: bigint;
}

export interface MintIssuerTokenRequest {
    amount: bigint;
}

export interface UnfreezeIssuerTokenRequest {
    address: string;
}

export interface BurnIssuerTokenRequest {
    amount: bigint;
}

export interface CreateIssuerTokenRequest {
    name: string;
    ticker: string;
    decimals: number;
    isFreezable: boolean;
    maxSupply: bigint;
}

export interface ExternalSigner {
    identityPublicKey(): PublicKeyBytes;
    derivePublicKey(path: string): Promise<PublicKeyBytes>;
    signEcdsa(message: MessageBytes, path: string): Promise<EcdsaSignatureBytes>;
    signEcdsaRecoverable(message: MessageBytes, path: string): Promise<RecoverableEcdsaSignatureBytes>;
    encryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    decryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    signHashSchnorr(hash: Uint8Array, path: string): Promise<SchnorrSignatureBytes>;
    generateRandomSigningCommitment(): Promise<ExternalFrostCommitments>;
    getPublicKeyForNode(id: ExternalTreeNodeId): Promise<PublicKeyBytes>;
    generateRandomSecret(): Promise<ExternalEncryptedSecret>;
    staticDepositSecretEncrypted(index: number): Promise<ExternalSecretSource>;
    staticDepositSecret(index: number): Promise<SecretBytes>;
    staticDepositSigningKey(index: number): Promise<PublicKeyBytes>;
    subtractSecrets(signingKey: ExternalSecretSource, newSigningKey: ExternalSecretSource): Promise<ExternalSecretSource>;
    splitSecretWithProofs(secret: ExternalSecretToSplit, threshold: number, numShares: number): Promise<ExternalVerifiableSecretShare[]>;
    encryptPrivateKeyForReceiver(privateKey: ExternalEncryptedSecret, receiverPublicKey: PublicKeyBytes): Promise<Uint8Array>;
    publicKeyFromSecret(privateKey: ExternalSecretSource): Promise<PublicKeyBytes>;
    signFrost(request: ExternalSignFrostRequest): Promise<ExternalFrostSignatureShare>;
    aggregateFrost(request: ExternalAggregateFrostRequest): Promise<ExternalFrostSignature>;
    hmacSha256(message: Uint8Array, path: string): Promise<HashedMessageBytes>;
}

export interface ExternalSecretShare {
    threshold: number;
    index: ExternalScalar;
    share: ExternalScalar;
}

export interface ExternalVerifiableSecretShare {
    secretShare: ExternalSecretShare;
    proofs: number[][];
}

export interface RecoverableEcdsaSignatureBytes {
    bytes: number[];
}

export interface ExternalFrostSignature {
    bytes: number[];
}

export interface ExternalTreeNodeId {
    id: string;
}

export interface ExternalFrostSignatureShare {
    bytes: number[];
}

export interface MessageBytes {
    bytes: number[];
}

export interface IdentifierSignaturePair {
    identifier: ExternalIdentifier;
    signature: ExternalFrostSignatureShare;
}

export interface ExternalSignFrostRequest {
    message: number[];
    publicKey: number[];
    secret: ExternalSecretSource;
    verifyingKey: number[];
    selfNonceCommitment: ExternalFrostCommitments;
    statechainCommitments: IdentifierCommitmentPair[];
    adaptorPublicKey?: number[];
}

export interface ExternalSigningCommitments {
    hiding: number[];
    binding: number[];
}

export type ExternalSecretToSplit = { type: "secretSource"; source: ExternalSecretSource } | { type: "preimage"; data: number[] };

export interface SchnorrSignatureBytes {
    bytes: number[];
}

export interface ExternalIdentifier {
    bytes: number[];
}

export interface HashedMessageBytes {
    bytes: number[];
}

export interface EcdsaSignatureBytes {
    bytes: number[];
}

export interface ExternalEncryptedSecret {
    ciphertext: number[];
}

export interface IdentifierCommitmentPair {
    identifier: ExternalIdentifier;
    commitment: ExternalSigningCommitments;
}

export interface ExternalAggregateFrostRequest {
    message: number[];
    statechainSignatures: IdentifierSignaturePair[];
    statechainPublicKeys: IdentifierPublicKeyPair[];
    verifyingKey: number[];
    statechainCommitments: IdentifierCommitmentPair[];
    selfCommitment: ExternalSigningCommitments;
    publicKey: number[];
    selfSignature: ExternalFrostSignatureShare;
    adaptorPublicKey?: number[];
}

export interface PublicKeyBytes {
    bytes: number[];
}

export interface IdentifierPublicKeyPair {
    identifier: ExternalIdentifier;
    publicKey: number[];
}

export type ExternalSecretSource = { type: "derived"; nodeId: ExternalTreeNodeId } | { type: "encrypted"; key: ExternalEncryptedSecret };

export interface ExternalScalar {
    bytes: number[];
}

export interface ExternalFrostCommitments {
    hidingCommitment: number[];
    bindingCommitment: number[];
    noncesCiphertext: number[];
}

export interface SecretBytes {
    bytes: number[];
}

export interface Storage {
    getCachedItem: (key: string) => Promise<string | null>;
    setCachedItem: (key: string, value: string) => Promise<void>;
    deleteCachedItem: (key: string) => Promise<void>;
    listPayments: (request: ListPaymentsRequest) => Promise<Payment[]>;
    insertPayment: (payment: Payment) => Promise<void>;
    insertPaymentMetadata: (paymentId: string, metadata: PaymentMetadata) => Promise<void>;
    getPaymentById: (id: string) => Promise<Payment>;
    getPaymentByInvoice: (invoice: string) => Promise<Payment>;
    addDeposit: (txid: string, vout: number, amount_sats: number) => Promise<void>;
    deleteDeposit: (txid: string, vout: number) => Promise<void>;
    listDeposits: () => Promise<DepositInfo[]>;
    updateDeposit: (txid: string, vout: number, payload: UpdateDepositPayload) => Promise<void>;
    setLnurlMetadata: (metadata: SetLnurlMetadataItem[]) => Promise<void>;
    getPaymentsByParentIds: (parentPaymentIds: string[]) => Promise<{ [parentId: string]: RelatedPayment[] }>;
    syncAddOutgoingChange: (record: UnversionedRecordChange) => Promise<number>;
    syncCompleteOutgoingSync: (record: Record) => Promise<void>;
    syncGetPendingOutgoingChanges: (limit: number) => Promise<OutgoingChange[]>;
    syncGetLastRevision: () => Promise<number>;
    syncInsertIncomingRecords: (records: Record[]) => Promise<void>;
    syncDeleteIncomingRecord: (record: Record) => Promise<void>;
    syncRebasePendingOutgoingRecords: (revision: number) => Promise<void>;
    syncGetIncomingRecords: (limit: number) => Promise<IncomingChange[]>;
    syncGetLatestOutgoingChange: () => Promise<OutgoingChange | null>;
    syncUpdateRecordFromIncoming: (record: Record) => Promise<void>;
}

export class BreezSdk {
  private constructor();
  free(): void;
  disconnect(): Promise<void>;
  lnurlAuth(request_data: LnurlAuthRequestDetails): Promise<LnurlCallbackStatus>;
  buyBitcoin(request: BuyBitcoinRequest): Promise<BuyBitcoinResponse>;
  getPayment(request: GetPaymentRequest): Promise<GetPaymentResponse>;
  syncWallet(request: SyncWalletRequest): Promise<SyncWalletResponse>;
  sendPayment(request: SendPaymentRequest): Promise<SendPaymentResponse>;
  signMessage(request: SignMessageRequest): Promise<SignMessageResponse>;
  checkMessage(request: CheckMessageRequest): Promise<CheckMessageResponse>;
  claimDeposit(request: ClaimDepositRequest): Promise<ClaimDepositResponse>;
  listPayments(request: ListPaymentsRequest): Promise<ListPaymentsResponse>;
  lnurlWithdraw(request: LnurlWithdrawRequest): Promise<LnurlWithdrawResponse>;
  refundDeposit(request: RefundDepositRequest): Promise<RefundDepositResponse>;
  listFiatRates(): Promise<ListFiatRatesResponse>;
  receivePayment(request: ReceivePaymentRequest): Promise<ReceivePaymentResponse>;
  getTokenIssuer(): TokenIssuer;
  recommendedFees(): Promise<RecommendedFees>;
  getUserSettings(): Promise<UserSettings>;
  prepareLnurlPay(request: PrepareLnurlPayRequest): Promise<PrepareLnurlPayResponse>;
  addEventListener(listener: EventListener): Promise<string>;
  claimHtlcPayment(request: ClaimHtlcPaymentRequest): Promise<ClaimHtlcPaymentResponse>;
  getTokensMetadata(request: GetTokensMetadataRequest): Promise<GetTokensMetadataResponse>;
  listFiatCurrencies(): Promise<ListFiatCurrenciesResponse>;
  prepareSendPayment(request: PrepareSendPaymentRequest): Promise<PrepareSendPaymentResponse>;
  updateUserSettings(request: UpdateUserSettingsRequest): Promise<void>;
  getLightningAddress(): Promise<LightningAddressInfo | undefined>;
  removeEventListener(id: string): Promise<boolean>;
  fetchConversionLimits(request: FetchConversionLimitsRequest): Promise<FetchConversionLimitsResponse>;
  listUnclaimedDeposits(request: ListUnclaimedDepositsRequest): Promise<ListUnclaimedDepositsResponse>;
  startLeafOptimization(): void;
  cancelLeafOptimization(): Promise<void>;
  deleteLightningAddress(): Promise<void>;
  registerLightningAddress(request: RegisterLightningAddressRequest): Promise<LightningAddressInfo>;
  getLeafOptimizationProgress(): OptimizationProgress;
  checkLightningAddressAvailable(request: CheckLightningAddressRequest): Promise<boolean>;
  parse(input: string): Promise<InputType>;
  getInfo(request: GetInfoRequest): Promise<GetInfoResponse>;
  lnurlPay(request: LnurlPayRequest): Promise<LnurlPayResponse>;
}
/**
 * A default signer implementation that wraps the core SDK's ExternalSigner.
 * This is returned by `defaultExternalSigner` and can be passed to `connectWithSigner`.
 */
export class DefaultSigner {
  private constructor();
  free(): void;
  signEcdsa(message: MessageBytes, path: string): Promise<EcdsaSignatureBytes>;
  signFrost(request: ExternalSignFrostRequest): Promise<ExternalFrostSignatureShare>;
  hmacSha256(message: Uint8Array, path: string): Promise<HashedMessageBytes>;
  decryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
  encryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
  aggregateFrost(request: ExternalAggregateFrostRequest): Promise<ExternalFrostSignature>;
  subtractSecrets(signing_key: ExternalSecretSource, new_signing_key: ExternalSecretSource): Promise<ExternalSecretSource>;
  derivePublicKey(path: string): Promise<PublicKeyBytes>;
  signHashSchnorr(hash: Uint8Array, path: string): Promise<SchnorrSignatureBytes>;
  identityPublicKey(): PublicKeyBytes;
  staticDepositSecret(index: number): Promise<SecretBytes>;
  generateRandomSecret(): Promise<ExternalEncryptedSecret>;
  publicKeyFromSecret(private_key: ExternalSecretSource): Promise<PublicKeyBytes>;
  signEcdsaRecoverable(message: MessageBytes, path: string): Promise<RecoverableEcdsaSignatureBytes>;
  getPublicKeyForNode(id: ExternalTreeNodeId): Promise<PublicKeyBytes>;
  splitSecretWithProofs(secret: ExternalSecretToSplit, threshold: number, num_shares: number): Promise<ExternalVerifiableSecretShare[]>;
  staticDepositSigningKey(index: number): Promise<PublicKeyBytes>;
  encryptPrivateKeyForReceiver(private_key: ExternalEncryptedSecret, receiver_public_key: PublicKeyBytes): Promise<Uint8Array>;
  staticDepositSecretEncrypted(index: number): Promise<ExternalSecretSource>;
  generateRandomSigningCommitment(): Promise<ExternalFrostCommitments>;
}
export class IntoUnderlyingByteSource {
  private constructor();
  free(): void;
  pull(controller: ReadableByteStreamController): Promise<any>;
  start(controller: ReadableByteStreamController): void;
  cancel(): void;
  readonly autoAllocateChunkSize: number;
  readonly type: ReadableStreamType;
}
export class IntoUnderlyingSink {
  private constructor();
  free(): void;
  abort(reason: any): Promise<any>;
  close(): Promise<any>;
  write(chunk: any): Promise<any>;
}
export class IntoUnderlyingSource {
  private constructor();
  free(): void;
  pull(controller: ReadableStreamDefaultController): Promise<any>;
  cancel(): void;
}
export class SdkBuilder {
  private constructor();
  free(): void;
  withKeySet(config: KeySetConfig): SdkBuilder;
  withStorage(storage: Storage): SdkBuilder;
  static newWithSigner(config: Config, signer: ExternalSigner): SdkBuilder;
  withFiatService(fiat_service: FiatService): SdkBuilder;
  withLnurlClient(lnurl_client: RestClient): SdkBuilder;
  withChainService(chain_service: BitcoinChainService): SdkBuilder;
  withDefaultStorage(storage_dir: string): Promise<SdkBuilder>;
  withPaymentObserver(payment_observer: PaymentObserver): SdkBuilder;
  withRestChainService(url: string, api_type: ChainApiType, credentials?: Credentials | null): SdkBuilder;
  static new(config: Config, seed: Seed): SdkBuilder;
  build(): Promise<BreezSdk>;
}
export class TokenIssuer {
  private constructor();
  free(): void;
  burnIssuerToken(request: BurnIssuerTokenRequest): Promise<Payment>;
  mintIssuerToken(request: MintIssuerTokenRequest): Promise<Payment>;
  createIssuerToken(request: CreateIssuerTokenRequest): Promise<TokenMetadata>;
  freezeIssuerToken(request: FreezeIssuerTokenRequest): Promise<FreezeIssuerTokenResponse>;
  unfreezeIssuerToken(request: UnfreezeIssuerTokenRequest): Promise<UnfreezeIssuerTokenResponse>;
  getIssuerTokenBalance(): Promise<TokenBalance>;
  getIssuerTokenMetadata(): Promise<TokenMetadata>;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_breezsdk_free: (a: number, b: number) => void;
  readonly __wbg_defaultsigner_free: (a: number, b: number) => void;
  readonly __wbg_sdkbuilder_free: (a: number, b: number) => void;
  readonly __wbg_tokenissuer_free: (a: number, b: number) => void;
  readonly breezsdk_addEventListener: (a: number, b: any) => any;
  readonly breezsdk_buyBitcoin: (a: number, b: any) => any;
  readonly breezsdk_cancelLeafOptimization: (a: number) => any;
  readonly breezsdk_checkLightningAddressAvailable: (a: number, b: any) => any;
  readonly breezsdk_checkMessage: (a: number, b: any) => any;
  readonly breezsdk_claimDeposit: (a: number, b: any) => any;
  readonly breezsdk_claimHtlcPayment: (a: number, b: any) => any;
  readonly breezsdk_deleteLightningAddress: (a: number) => any;
  readonly breezsdk_disconnect: (a: number) => any;
  readonly breezsdk_fetchConversionLimits: (a: number, b: any) => any;
  readonly breezsdk_getInfo: (a: number, b: any) => any;
  readonly breezsdk_getLeafOptimizationProgress: (a: number) => any;
  readonly breezsdk_getLightningAddress: (a: number) => any;
  readonly breezsdk_getPayment: (a: number, b: any) => any;
  readonly breezsdk_getTokenIssuer: (a: number) => number;
  readonly breezsdk_getTokensMetadata: (a: number, b: any) => any;
  readonly breezsdk_getUserSettings: (a: number) => any;
  readonly breezsdk_listFiatCurrencies: (a: number) => any;
  readonly breezsdk_listFiatRates: (a: number) => any;
  readonly breezsdk_listPayments: (a: number, b: any) => any;
  readonly breezsdk_listUnclaimedDeposits: (a: number, b: any) => any;
  readonly breezsdk_lnurlAuth: (a: number, b: any) => any;
  readonly breezsdk_lnurlPay: (a: number, b: any) => any;
  readonly breezsdk_lnurlWithdraw: (a: number, b: any) => any;
  readonly breezsdk_parse: (a: number, b: number, c: number) => any;
  readonly breezsdk_prepareLnurlPay: (a: number, b: any) => any;
  readonly breezsdk_prepareSendPayment: (a: number, b: any) => any;
  readonly breezsdk_receivePayment: (a: number, b: any) => any;
  readonly breezsdk_recommendedFees: (a: number) => any;
  readonly breezsdk_refundDeposit: (a: number, b: any) => any;
  readonly breezsdk_registerLightningAddress: (a: number, b: any) => any;
  readonly breezsdk_removeEventListener: (a: number, b: number, c: number) => any;
  readonly breezsdk_sendPayment: (a: number, b: any) => any;
  readonly breezsdk_signMessage: (a: number, b: any) => any;
  readonly breezsdk_startLeafOptimization: (a: number) => void;
  readonly breezsdk_syncWallet: (a: number, b: any) => any;
  readonly breezsdk_updateUserSettings: (a: number, b: any) => any;
  readonly connect: (a: any) => any;
  readonly connectWithSigner: (a: any, b: any, c: number, d: number) => any;
  readonly defaultConfig: (a: any) => any;
  readonly defaultExternalSigner: (a: number, b: number, c: number, d: number, e: any, f: number) => [number, number, number];
  readonly defaultsigner_aggregateFrost: (a: number, b: any) => any;
  readonly defaultsigner_decryptEcies: (a: number, b: number, c: number, d: number, e: number) => any;
  readonly defaultsigner_derivePublicKey: (a: number, b: number, c: number) => any;
  readonly defaultsigner_encryptEcies: (a: number, b: number, c: number, d: number, e: number) => any;
  readonly defaultsigner_encryptPrivateKeyForReceiver: (a: number, b: any, c: any) => any;
  readonly defaultsigner_generateRandomSecret: (a: number) => any;
  readonly defaultsigner_generateRandomSigningCommitment: (a: number) => any;
  readonly defaultsigner_getPublicKeyForNode: (a: number, b: any) => any;
  readonly defaultsigner_hmacSha256: (a: number, b: number, c: number, d: number, e: number) => any;
  readonly defaultsigner_identityPublicKey: (a: number) => [number, number, number];
  readonly defaultsigner_publicKeyFromSecret: (a: number, b: any) => any;
  readonly defaultsigner_signEcdsa: (a: number, b: any, c: number, d: number) => any;
  readonly defaultsigner_signEcdsaRecoverable: (a: number, b: any, c: number, d: number) => any;
  readonly defaultsigner_signFrost: (a: number, b: any) => any;
  readonly defaultsigner_signHashSchnorr: (a: number, b: number, c: number, d: number, e: number) => any;
  readonly defaultsigner_splitSecretWithProofs: (a: number, b: any, c: number, d: number) => any;
  readonly defaultsigner_staticDepositSecret: (a: number, b: number) => any;
  readonly defaultsigner_staticDepositSecretEncrypted: (a: number, b: number) => any;
  readonly defaultsigner_staticDepositSigningKey: (a: number, b: number) => any;
  readonly defaultsigner_subtractSecrets: (a: number, b: any, c: any) => any;
  readonly getSparkStatus: () => any;
  readonly initLogging: (a: any, b: number, c: number) => any;
  readonly sdkbuilder_build: (a: number) => any;
  readonly sdkbuilder_new: (a: any, b: any) => number;
  readonly sdkbuilder_newWithSigner: (a: any, b: any) => number;
  readonly sdkbuilder_withChainService: (a: number, b: any) => number;
  readonly sdkbuilder_withDefaultStorage: (a: number, b: number, c: number) => any;
  readonly sdkbuilder_withFiatService: (a: number, b: any) => number;
  readonly sdkbuilder_withKeySet: (a: number, b: any) => number;
  readonly sdkbuilder_withLnurlClient: (a: number, b: any) => number;
  readonly sdkbuilder_withPaymentObserver: (a: number, b: any) => number;
  readonly sdkbuilder_withRestChainService: (a: number, b: number, c: number, d: any, e: number) => number;
  readonly sdkbuilder_withStorage: (a: number, b: any) => number;
  readonly tokenissuer_burnIssuerToken: (a: number, b: any) => any;
  readonly tokenissuer_createIssuerToken: (a: number, b: any) => any;
  readonly tokenissuer_freezeIssuerToken: (a: number, b: any) => any;
  readonly tokenissuer_getIssuerTokenBalance: (a: number) => any;
  readonly tokenissuer_getIssuerTokenMetadata: (a: number) => any;
  readonly tokenissuer_mintIssuerToken: (a: number, b: any) => any;
  readonly tokenissuer_unfreezeIssuerToken: (a: number, b: any) => any;
  readonly rustsecp256k1_v0_10_0_context_create: (a: number) => number;
  readonly rustsecp256k1_v0_10_0_context_destroy: (a: number) => void;
  readonly rustsecp256k1_v0_10_0_default_error_callback_fn: (a: number, b: number) => void;
  readonly rustsecp256k1_v0_10_0_default_illegal_callback_fn: (a: number, b: number) => void;
  readonly task_worker_entry_point: (a: number) => [number, number];
  readonly __wbg_intounderlyingbytesource_free: (a: number, b: number) => void;
  readonly __wbg_intounderlyingsink_free: (a: number, b: number) => void;
  readonly __wbg_intounderlyingsource_free: (a: number, b: number) => void;
  readonly intounderlyingbytesource_autoAllocateChunkSize: (a: number) => number;
  readonly intounderlyingbytesource_cancel: (a: number) => void;
  readonly intounderlyingbytesource_pull: (a: number, b: any) => any;
  readonly intounderlyingbytesource_start: (a: number, b: any) => void;
  readonly intounderlyingbytesource_type: (a: number) => number;
  readonly intounderlyingsink_abort: (a: number, b: any) => any;
  readonly intounderlyingsink_close: (a: number) => any;
  readonly intounderlyingsink_write: (a: number, b: any) => any;
  readonly intounderlyingsource_cancel: (a: number) => void;
  readonly intounderlyingsource_pull: (a: number, b: any) => any;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_5: WebAssembly.Table;
  readonly __externref_drop_slice: (a: number, b: number) => void;
  readonly __wbindgen_export_7: WebAssembly.Table;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly _dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__hc5dbd2050f24341b: (a: number, b: number) => void;
  readonly closure1089_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure678_externref_shim: (a: number, b: number, c: any, d: any) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
