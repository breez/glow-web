let wasm;

let WASM_VECTOR_LEN = 0;

let cachedUint8ArrayMemory0 = null;

function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

const cachedTextEncoder = (typeof TextEncoder !== 'undefined' ? new TextEncoder('utf-8') : { encode: () => { throw Error('TextEncoder not available') } } );

const encodeString = (typeof cachedTextEncoder.encodeInto === 'function'
    ? function (arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
}
    : function (arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
        read: arg.length,
        written: buf.length
    };
});

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

let cachedDataViewMemory0 = null;

function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

const cachedTextDecoder = (typeof TextDecoder !== 'undefined' ? new TextDecoder('utf-8', { ignoreBOM: true, fatal: true }) : { decode: () => { throw Error('TextDecoder not available') } } );

if (typeof TextDecoder !== 'undefined') { cachedTextDecoder.decode(); };

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_export_5.set(idx, obj);
    return idx;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_export_5.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(state => {
    wasm.__wbindgen_export_7.get(state.dtor)(state.a, state.b)
});

function makeMutClosure(arg0, arg1, dtor, f) {
    const state = { a: arg0, b: arg1, cnt: 1, dtor };
    const real = (...args) => {
        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            if (--state.cnt === 0) {
                wasm.__wbindgen_export_7.get(state.dtor)(a, state.b);
                CLOSURE_DTORS.unregister(state);
            } else {
                state.a = a;
            }
        }
    };
    real.original = state;
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}
/**
 * Creates a default PostgreSQL storage configuration with sensible defaults.
 *
 * Default values (from pg.Pool):
 * - `maxPoolSize`: 10
 * - `createTimeoutSecs`: 0 (no timeout)
 * - `recycleTimeoutSecs`: 10 (10 seconds idle before disconnect)
 * @param {string} connection_string
 * @returns {PostgresStorageConfig}
 */
export function defaultPostgresStorageConfig(connection_string) {
    const ptr0 = passStringToWasm0(connection_string, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.defaultPostgresStorageConfig(ptr0, len0);
    return ret;
}

/**
 * @param {ConnectRequest} request
 * @returns {Promise<BreezSdk>}
 */
export function connect(request) {
    const ret = wasm.connect(request);
    return ret;
}

/**
 * @param {Config} config
 * @param {ExternalSigner} signer
 * @param {string} storage_dir
 * @returns {Promise<BreezSdk>}
 */
export function connectWithSigner(config, signer, storage_dir) {
    const ptr0 = passStringToWasm0(storage_dir, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.connectWithSigner(config, signer, ptr0, len0);
    return ret;
}

/**
 * Creates a default external signer from a mnemonic phrase.
 *
 * This creates a signer that can be used with `connectWithSigner` or `SdkBuilder.newWithSigner`.
 * @returns {Promise<SparkStatus>}
 */
export function getSparkStatus() {
    const ret = wasm.getSparkStatus();
    return ret;
}

/**
 * @param {Logger} logger
 * @param {string | null} [filter]
 * @returns {Promise<void>}
 */
export function initLogging(logger, filter) {
    var ptr0 = isLikeNone(filter) ? 0 : passStringToWasm0(filter, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len0 = WASM_VECTOR_LEN;
    const ret = wasm.initLogging(logger, ptr0, len0);
    return ret;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_export_5.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}
/**
 * @param {string} mnemonic
 * @param {string | null | undefined} passphrase
 * @param {Network} network
 * @param {KeySetConfig | null} [key_set_config]
 * @returns {DefaultSigner}
 */
export function defaultExternalSigner(mnemonic, passphrase, network, key_set_config) {
    const ptr0 = passStringToWasm0(mnemonic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    var ptr1 = isLikeNone(passphrase) ? 0 : passStringToWasm0(passphrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len1 = WASM_VECTOR_LEN;
    const ret = wasm.defaultExternalSigner(ptr0, len0, ptr1, len1, network, isLikeNone(key_set_config) ? 0 : addToExternrefTable0(key_set_config));
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return DefaultSigner.__wrap(ret[0]);
}

/**
 * @param {Network} network
 * @returns {Config}
 */
export function defaultConfig(network) {
    const ret = wasm.defaultConfig(network);
    return ret;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}
/**
 * Entry point invoked by JavaScript in a worker.
 * @param {number} ptr
 */
export function task_worker_entry_point(ptr) {
    const ret = wasm.task_worker_entry_point(ptr);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function __wbg_adapter_64(arg0, arg1, arg2) {
    wasm.closure424_externref_shim(arg0, arg1, arg2);
}

function __wbg_adapter_77(arg0, arg1) {
    wasm._dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h16109dfb86131e87(arg0, arg1);
}

function __wbg_adapter_442(arg0, arg1, arg2, arg3) {
    wasm.closure725_externref_shim(arg0, arg1, arg2, arg3);
}

const __wbindgen_enum_BinaryType = ["blob", "arraybuffer"];

const __wbindgen_enum_ReadableStreamType = ["bytes"];

const __wbindgen_enum_ReferrerPolicy = ["", "no-referrer", "no-referrer-when-downgrade", "origin", "origin-when-cross-origin", "unsafe-url", "same-origin", "strict-origin", "strict-origin-when-cross-origin"];

const __wbindgen_enum_RequestCache = ["default", "no-store", "reload", "no-cache", "force-cache", "only-if-cached"];

const __wbindgen_enum_RequestCredentials = ["omit", "same-origin", "include"];

const __wbindgen_enum_RequestMode = ["same-origin", "no-cors", "cors", "navigate"];

const __wbindgen_enum_RequestRedirect = ["follow", "error", "manual"];

const BreezSdkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_breezsdk_free(ptr >>> 0, 1));

export class BreezSdk {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(BreezSdk.prototype);
        obj.__wbg_ptr = ptr;
        BreezSdkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BreezSdkFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_breezsdk_free(ptr, 0);
    }
    /**
     * @returns {Promise<void>}
     */
    disconnect() {
        const ret = wasm.breezsdk_disconnect(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {LnurlAuthRequestDetails} request_data
     * @returns {Promise<LnurlCallbackStatus>}
     */
    lnurlAuth(request_data) {
        const ret = wasm.breezsdk_lnurlAuth(this.__wbg_ptr, request_data);
        return ret;
    }
    /**
     * @param {AddContactRequest} request
     * @returns {Promise<Contact>}
     */
    addContact(request) {
        const ret = wasm.breezsdk_addContact(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {BuyBitcoinRequest} request
     * @returns {Promise<BuyBitcoinResponse>}
     */
    buyBitcoin(request) {
        const ret = wasm.breezsdk_buyBitcoin(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {GetPaymentRequest} request
     * @returns {Promise<GetPaymentResponse>}
     */
    getPayment(request) {
        const ret = wasm.breezsdk_getPayment(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {SyncWalletRequest} request
     * @returns {Promise<SyncWalletResponse>}
     */
    syncWallet(request) {
        const ret = wasm.breezsdk_syncWallet(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {SendPaymentRequest} request
     * @returns {Promise<SendPaymentResponse>}
     */
    sendPayment(request) {
        const ret = wasm.breezsdk_sendPayment(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {SignMessageRequest} request
     * @returns {Promise<SignMessageResponse>}
     */
    signMessage(request) {
        const ret = wasm.breezsdk_signMessage(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {CheckMessageRequest} request
     * @returns {Promise<CheckMessageResponse>}
     */
    checkMessage(request) {
        const ret = wasm.breezsdk_checkMessage(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {ClaimDepositRequest} request
     * @returns {Promise<ClaimDepositResponse>}
     */
    claimDeposit(request) {
        const ret = wasm.breezsdk_claimDeposit(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {ListContactsRequest} request
     * @returns {Promise<Contact[]>}
     */
    listContacts(request) {
        const ret = wasm.breezsdk_listContacts(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {ListPaymentsRequest} request
     * @returns {Promise<ListPaymentsResponse>}
     */
    listPayments(request) {
        const ret = wasm.breezsdk_listPayments(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @returns {Promise<Webhook[]>}
     */
    listWebhooks() {
        const ret = wasm.breezsdk_listWebhooks(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {string} id
     * @returns {Promise<void>}
     */
    deleteContact(id) {
        const ptr0 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.breezsdk_deleteContact(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * @param {LnurlWithdrawRequest} request
     * @returns {Promise<LnurlWithdrawResponse>}
     */
    lnurlWithdraw(request) {
        const ret = wasm.breezsdk_lnurlWithdraw(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {RefundDepositRequest} request
     * @returns {Promise<RefundDepositResponse>}
     */
    refundDeposit(request) {
        const ret = wasm.breezsdk_refundDeposit(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {UpdateContactRequest} request
     * @returns {Promise<Contact>}
     */
    updateContact(request) {
        const ret = wasm.breezsdk_updateContact(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @returns {Promise<ListFiatRatesResponse>}
     */
    listFiatRates() {
        const ret = wasm.breezsdk_listFiatRates(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {ReceivePaymentRequest} request
     * @returns {Promise<ReceivePaymentResponse>}
     */
    receivePayment(request) {
        const ret = wasm.breezsdk_receivePayment(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @returns {TokenIssuer}
     */
    getTokenIssuer() {
        const ret = wasm.breezsdk_getTokenIssuer(this.__wbg_ptr);
        return TokenIssuer.__wrap(ret);
    }
    /**
     * @returns {Promise<RecommendedFees>}
     */
    recommendedFees() {
        const ret = wasm.breezsdk_recommendedFees(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {RegisterWebhookRequest} request
     * @returns {Promise<RegisterWebhookResponse>}
     */
    registerWebhook(request) {
        const ret = wasm.breezsdk_registerWebhook(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @returns {Promise<UserSettings>}
     */
    getUserSettings() {
        const ret = wasm.breezsdk_getUserSettings(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {PrepareLnurlPayRequest} request
     * @returns {Promise<PrepareLnurlPayResponse>}
     */
    prepareLnurlPay(request) {
        const ret = wasm.breezsdk_prepareLnurlPay(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {EventListener} listener
     * @returns {Promise<string>}
     */
    addEventListener(listener) {
        const ret = wasm.breezsdk_addEventListener(this.__wbg_ptr, listener);
        return ret;
    }
    /**
     * @param {ClaimHtlcPaymentRequest} request
     * @returns {Promise<ClaimHtlcPaymentResponse>}
     */
    claimHtlcPayment(request) {
        const ret = wasm.breezsdk_claimHtlcPayment(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {UnregisterWebhookRequest} request
     * @returns {Promise<void>}
     */
    unregisterWebhook(request) {
        const ret = wasm.breezsdk_unregisterWebhook(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {GetTokensMetadataRequest} request
     * @returns {Promise<GetTokensMetadataResponse>}
     */
    getTokensMetadata(request) {
        const ret = wasm.breezsdk_getTokensMetadata(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @returns {Promise<ListFiatCurrenciesResponse>}
     */
    listFiatCurrencies() {
        const ret = wasm.breezsdk_listFiatCurrencies(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {PrepareSendPaymentRequest} request
     * @returns {Promise<PrepareSendPaymentResponse>}
     */
    prepareSendPayment(request) {
        const ret = wasm.breezsdk_prepareSendPayment(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {UpdateUserSettingsRequest} request
     * @returns {Promise<void>}
     */
    updateUserSettings(request) {
        const ret = wasm.breezsdk_updateUserSettings(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @returns {Promise<LightningAddressInfo | undefined>}
     */
    getLightningAddress() {
        const ret = wasm.breezsdk_getLightningAddress(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {string} id
     * @returns {Promise<boolean>}
     */
    removeEventListener(id) {
        const ptr0 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.breezsdk_removeEventListener(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * @param {CrossChainRouteFilter} filter
     * @returns {Promise<CrossChainRoutePair[]>}
     */
    getCrossChainRoutes(filter) {
        const ret = wasm.breezsdk_getCrossChainRoutes(this.__wbg_ptr, filter);
        return ret;
    }
    /**
     * @param {FetchConversionLimitsRequest} request
     * @returns {Promise<FetchConversionLimitsResponse>}
     */
    fetchConversionLimits(request) {
        const ret = wasm.breezsdk_fetchConversionLimits(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {ListUnclaimedDepositsRequest} request
     * @returns {Promise<ListUnclaimedDepositsResponse>}
     */
    listUnclaimedDeposits(request) {
        const ret = wasm.breezsdk_listUnclaimedDeposits(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @returns {Promise<void>}
     */
    startLeafOptimization() {
        const ret = wasm.breezsdk_startLeafOptimization(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Promise<void>}
     */
    cancelLeafOptimization() {
        const ret = wasm.breezsdk_cancelLeafOptimization(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Promise<void>}
     */
    deleteLightningAddress() {
        const ret = wasm.breezsdk_deleteLightningAddress(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {RegisterLightningAddressRequest} request
     * @returns {Promise<LightningAddressInfo>}
     */
    registerLightningAddress(request) {
        const ret = wasm.breezsdk_registerLightningAddress(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @returns {OptimizationProgress}
     */
    getLeafOptimizationProgress() {
        const ret = wasm.breezsdk_getLeafOptimizationProgress(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {CheckLightningAddressRequest} request
     * @returns {Promise<boolean>}
     */
    checkLightningAddressAvailable(request) {
        const ret = wasm.breezsdk_checkLightningAddressAvailable(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {string} input
     * @returns {Promise<InputType>}
     */
    parse(input) {
        const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.breezsdk_parse(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * @param {GetInfoRequest} request
     * @returns {Promise<GetInfoResponse>}
     */
    getInfo(request) {
        const ret = wasm.breezsdk_getInfo(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {LnurlPayRequest} request
     * @returns {Promise<LnurlPayResponse>}
     */
    lnurlPay(request) {
        const ret = wasm.breezsdk_lnurlPay(this.__wbg_ptr, request);
        return ret;
    }
}

const DefaultSignerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_defaultsigner_free(ptr >>> 0, 1));
/**
 * A default signer implementation that wraps the core SDK's ExternalSigner.
 * This is returned by `defaultExternalSigner` and can be passed to `connectWithSigner`.
 */
export class DefaultSigner {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(DefaultSigner.prototype);
        obj.__wbg_ptr = ptr;
        DefaultSignerFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        DefaultSignerFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_defaultsigner_free(ptr, 0);
    }
    /**
     * @param {MessageBytes} message
     * @param {string} path
     * @returns {Promise<EcdsaSignatureBytes>}
     */
    signEcdsa(message, path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.defaultsigner_signEcdsa(this.__wbg_ptr, message, ptr0, len0);
        return ret;
    }
    /**
     * @param {ExternalSignFrostRequest} request
     * @returns {Promise<ExternalFrostSignatureShare>}
     */
    signFrost(request) {
        const ret = wasm.defaultsigner_signFrost(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {Uint8Array} message
     * @param {string} path
     * @returns {Promise<HashedMessageBytes>}
     */
    hmacSha256(message, path) {
        const ptr0 = passArray8ToWasm0(message, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.defaultsigner_hmacSha256(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * @param {Uint8Array} message
     * @param {string} path
     * @returns {Promise<Uint8Array>}
     */
    decryptEcies(message, path) {
        const ptr0 = passArray8ToWasm0(message, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.defaultsigner_decryptEcies(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * @param {Uint8Array} message
     * @param {string} path
     * @returns {Promise<Uint8Array>}
     */
    encryptEcies(message, path) {
        const ptr0 = passArray8ToWasm0(message, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.defaultsigner_encryptEcies(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * @param {ExternalAggregateFrostRequest} request
     * @returns {Promise<ExternalFrostSignature>}
     */
    aggregateFrost(request) {
        const ret = wasm.defaultsigner_aggregateFrost(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {ExternalSecretSource} signing_key
     * @param {ExternalSecretSource} new_signing_key
     * @returns {Promise<ExternalSecretSource>}
     */
    subtractSecrets(signing_key, new_signing_key) {
        const ret = wasm.defaultsigner_subtractSecrets(this.__wbg_ptr, signing_key, new_signing_key);
        return ret;
    }
    /**
     * @param {string} path
     * @returns {Promise<PublicKeyBytes>}
     */
    derivePublicKey(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.defaultsigner_derivePublicKey(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * @param {Uint8Array} hash
     * @param {string} path
     * @returns {Promise<SchnorrSignatureBytes>}
     */
    signHashSchnorr(hash, path) {
        const ptr0 = passArray8ToWasm0(hash, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.defaultsigner_signHashSchnorr(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * @returns {PublicKeyBytes}
     */
    identityPublicKey() {
        const ret = wasm.defaultsigner_identityPublicKey(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} index
     * @returns {Promise<SecretBytes>}
     */
    staticDepositSecret(index) {
        const ret = wasm.defaultsigner_staticDepositSecret(this.__wbg_ptr, index);
        return ret;
    }
    /**
     * @returns {Promise<ExternalEncryptedSecret>}
     */
    generateRandomSecret() {
        const ret = wasm.defaultsigner_generateRandomSecret(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {ExternalSecretSource} private_key
     * @returns {Promise<PublicKeyBytes>}
     */
    publicKeyFromSecret(private_key) {
        const ret = wasm.defaultsigner_publicKeyFromSecret(this.__wbg_ptr, private_key);
        return ret;
    }
    /**
     * @param {MessageBytes} message
     * @param {string} path
     * @returns {Promise<RecoverableEcdsaSignatureBytes>}
     */
    signEcdsaRecoverable(message, path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.defaultsigner_signEcdsaRecoverable(this.__wbg_ptr, message, ptr0, len0);
        return ret;
    }
    /**
     * @param {ExternalTreeNodeId} id
     * @returns {Promise<PublicKeyBytes>}
     */
    getPublicKeyForNode(id) {
        const ret = wasm.defaultsigner_getPublicKeyForNode(this.__wbg_ptr, id);
        return ret;
    }
    /**
     * @param {ExternalSecretToSplit} secret
     * @param {number} threshold
     * @param {number} num_shares
     * @returns {Promise<ExternalVerifiableSecretShare[]>}
     */
    splitSecretWithProofs(secret, threshold, num_shares) {
        const ret = wasm.defaultsigner_splitSecretWithProofs(this.__wbg_ptr, secret, threshold, num_shares);
        return ret;
    }
    /**
     * @param {number} index
     * @returns {Promise<PublicKeyBytes>}
     */
    staticDepositSigningKey(index) {
        const ret = wasm.defaultsigner_staticDepositSigningKey(this.__wbg_ptr, index);
        return ret;
    }
    /**
     * @param {ExternalEncryptedSecret} private_key
     * @param {PublicKeyBytes} receiver_public_key
     * @returns {Promise<Uint8Array>}
     */
    encryptPrivateKeyForReceiver(private_key, receiver_public_key) {
        const ret = wasm.defaultsigner_encryptPrivateKeyForReceiver(this.__wbg_ptr, private_key, receiver_public_key);
        return ret;
    }
    /**
     * @param {number} index
     * @returns {Promise<ExternalSecretSource>}
     */
    staticDepositSecretEncrypted(index) {
        const ret = wasm.defaultsigner_staticDepositSecretEncrypted(this.__wbg_ptr, index);
        return ret;
    }
    /**
     * @returns {Promise<ExternalFrostCommitments>}
     */
    generateRandomSigningCommitment() {
        const ret = wasm.defaultsigner_generateRandomSigningCommitment(this.__wbg_ptr);
        return ret;
    }
}

const IntoUnderlyingByteSourceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingbytesource_free(ptr >>> 0, 1));

export class IntoUnderlyingByteSource {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingByteSourceFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingbytesource_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get autoAllocateChunkSize() {
        const ret = wasm.intounderlyingbytesource_autoAllocateChunkSize(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {ReadableByteStreamController} controller
     * @returns {Promise<any>}
     */
    pull(controller) {
        const ret = wasm.intounderlyingbytesource_pull(this.__wbg_ptr, controller);
        return ret;
    }
    /**
     * @param {ReadableByteStreamController} controller
     */
    start(controller) {
        wasm.intounderlyingbytesource_start(this.__wbg_ptr, controller);
    }
    /**
     * @returns {ReadableStreamType}
     */
    get type() {
        const ret = wasm.intounderlyingbytesource_type(this.__wbg_ptr);
        return __wbindgen_enum_ReadableStreamType[ret];
    }
    cancel() {
        const ptr = this.__destroy_into_raw();
        wasm.intounderlyingbytesource_cancel(ptr);
    }
}

const IntoUnderlyingSinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingsink_free(ptr >>> 0, 1));

export class IntoUnderlyingSink {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingSinkFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingsink_free(ptr, 0);
    }
    /**
     * @param {any} reason
     * @returns {Promise<any>}
     */
    abort(reason) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.intounderlyingsink_abort(ptr, reason);
        return ret;
    }
    /**
     * @returns {Promise<any>}
     */
    close() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.intounderlyingsink_close(ptr);
        return ret;
    }
    /**
     * @param {any} chunk
     * @returns {Promise<any>}
     */
    write(chunk) {
        const ret = wasm.intounderlyingsink_write(this.__wbg_ptr, chunk);
        return ret;
    }
}

const IntoUnderlyingSourceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingsource_free(ptr >>> 0, 1));

export class IntoUnderlyingSource {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingSourceFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingsource_free(ptr, 0);
    }
    /**
     * @param {ReadableStreamDefaultController} controller
     * @returns {Promise<any>}
     */
    pull(controller) {
        const ret = wasm.intounderlyingsource_pull(this.__wbg_ptr, controller);
        return ret;
    }
    cancel() {
        const ptr = this.__destroy_into_raw();
        wasm.intounderlyingsource_cancel(ptr);
    }
}

const PasskeyFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_passkey_free(ptr >>> 0, 1));
/**
 * Passkey-based wallet operations using WebAuthn PRF extension.
 *
 * Wraps a `PasskeyPrfProvider` and optional relay configuration to provide
 * wallet derivation and label management via Nostr relays.
 */
export class Passkey {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PasskeyFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_passkey_free(ptr, 0);
    }
    /**
     * Derive a wallet for a given label.
     *
     * Uses the passkey PRF to derive a `Wallet` containing the seed and resolved label.
     *
     * @param label - Optional label string (defaults to "Default")
     * @param {string | null} [label]
     * @returns {Promise<Wallet>}
     */
    getWallet(label) {
        var ptr0 = isLikeNone(label) ? 0 : passStringToWasm0(label, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.passkey_getWallet(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * List all labels published to Nostr for this passkey's identity.
     *
     * Requires 1 PRF call (for Nostr identity derivation).
     * @returns {Promise<string[]>}
     */
    listLabels() {
        const ret = wasm.passkey_listLabels(this.__wbg_ptr);
        return ret;
    }
    /**
     * Publish a label to Nostr relays for this passkey's identity.
     *
     * Idempotent: if the label already exists, it is not published again.
     * Requires 1 PRF call.
     * @param {string} label
     * @returns {Promise<void>}
     */
    storeLabel(label) {
        const ptr0 = passStringToWasm0(label, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.passkey_storeLabel(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Check if passkey PRF is available on this device.
     * @returns {Promise<boolean>}
     */
    isAvailable() {
        const ret = wasm.passkey_isAvailable(this.__wbg_ptr);
        return ret;
    }
    /**
     * Create a new `Passkey` instance.
     *
     * @param prfProvider - Platform implementation of passkey PRF operations
     * @param relayConfig - Optional configuration for Nostr relay connections
     * @param {PasskeyPrfProvider} prf_provider
     * @param {NostrRelayConfig | null} [relay_config]
     */
    constructor(prf_provider, relay_config) {
        const ret = wasm.passkey_new(prf_provider, isLikeNone(relay_config) ? 0 : addToExternrefTable0(relay_config));
        this.__wbg_ptr = ret >>> 0;
        PasskeyFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}

const SdkBuilderFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sdkbuilder_free(ptr >>> 0, 1));

export class SdkBuilder {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(SdkBuilder.prototype);
        obj.__wbg_ptr = ptr;
        SdkBuilderFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SdkBuilderFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sdkbuilder_free(ptr, 0);
    }
    /**
     * @param {KeySetConfig} config
     * @returns {SdkBuilder}
     */
    withKeySet(config) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.sdkbuilder_withKeySet(ptr, config);
        return SdkBuilder.__wrap(ret);
    }
    /**
     * @param {Storage} storage
     * @returns {SdkBuilder}
     */
    withStorage(storage) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.sdkbuilder_withStorage(ptr, storage);
        return SdkBuilder.__wrap(ret);
    }
    /**
     * @param {Config} config
     * @param {ExternalSigner} signer
     * @returns {SdkBuilder}
     */
    static newWithSigner(config, signer) {
        const ret = wasm.sdkbuilder_newWithSigner(config, signer);
        return SdkBuilder.__wrap(ret);
    }
    /**
     * @param {FiatService} fiat_service
     * @returns {SdkBuilder}
     */
    withFiatService(fiat_service) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.sdkbuilder_withFiatService(ptr, fiat_service);
        return SdkBuilder.__wrap(ret);
    }
    /**
     * @param {RestClient} lnurl_client
     * @returns {SdkBuilder}
     */
    withLnurlClient(lnurl_client) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.sdkbuilder_withLnurlClient(ptr, lnurl_client);
        return SdkBuilder.__wrap(ret);
    }
    /**
     * @param {BitcoinChainService} chain_service
     * @returns {SdkBuilder}
     */
    withChainService(chain_service) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.sdkbuilder_withChainService(ptr, chain_service);
        return SdkBuilder.__wrap(ret);
    }
    /**
     * @param {string} storage_dir
     * @returns {Promise<SdkBuilder>}
     */
    withDefaultStorage(storage_dir) {
        const ptr = this.__destroy_into_raw();
        const ptr0 = passStringToWasm0(storage_dir, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sdkbuilder_withDefaultStorage(ptr, ptr0, len0);
        return ret;
    }
    /**
     * @param {PaymentObserver} payment_observer
     * @returns {SdkBuilder}
     */
    withPaymentObserver(payment_observer) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.sdkbuilder_withPaymentObserver(ptr, payment_observer);
        return SdkBuilder.__wrap(ret);
    }
    /**
     * @param {PostgresStorageConfig} config
     * @returns {SdkBuilder}
     */
    withPostgresBackend(config) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.sdkbuilder_withPostgresBackend(ptr, config);
        return SdkBuilder.__wrap(ret);
    }
    /**
     * @param {string} url
     * @param {ChainApiType} api_type
     * @param {Credentials | null} [credentials]
     * @returns {SdkBuilder}
     */
    withRestChainService(url, api_type, credentials) {
        const ptr = this.__destroy_into_raw();
        const ptr0 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sdkbuilder_withRestChainService(ptr, ptr0, len0, api_type, isLikeNone(credentials) ? 0 : addToExternrefTable0(credentials));
        return SdkBuilder.__wrap(ret);
    }
    /**
     * @param {Config} config
     * @param {Seed} seed
     * @returns {SdkBuilder}
     */
    static new(config, seed) {
        const ret = wasm.sdkbuilder_new(config, seed);
        return SdkBuilder.__wrap(ret);
    }
    /**
     * @returns {Promise<BreezSdk>}
     */
    build() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.sdkbuilder_build(ptr);
        return ret;
    }
}

const TokenIssuerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_tokenissuer_free(ptr >>> 0, 1));

export class TokenIssuer {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(TokenIssuer.prototype);
        obj.__wbg_ptr = ptr;
        TokenIssuerFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TokenIssuerFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_tokenissuer_free(ptr, 0);
    }
    /**
     * @param {BurnIssuerTokenRequest} request
     * @returns {Promise<Payment>}
     */
    burnIssuerToken(request) {
        const ret = wasm.tokenissuer_burnIssuerToken(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {MintIssuerTokenRequest} request
     * @returns {Promise<Payment>}
     */
    mintIssuerToken(request) {
        const ret = wasm.tokenissuer_mintIssuerToken(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {CreateIssuerTokenRequest} request
     * @returns {Promise<TokenMetadata>}
     */
    createIssuerToken(request) {
        const ret = wasm.tokenissuer_createIssuerToken(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {FreezeIssuerTokenRequest} request
     * @returns {Promise<FreezeIssuerTokenResponse>}
     */
    freezeIssuerToken(request) {
        const ret = wasm.tokenissuer_freezeIssuerToken(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @param {UnfreezeIssuerTokenRequest} request
     * @returns {Promise<UnfreezeIssuerTokenResponse>}
     */
    unfreezeIssuerToken(request) {
        const ret = wasm.tokenissuer_unfreezeIssuerToken(this.__wbg_ptr, request);
        return ret;
    }
    /**
     * @returns {Promise<TokenBalance>}
     */
    getIssuerTokenBalance() {
        const ret = wasm.tokenissuer_getIssuerTokenBalance(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Promise<TokenMetadata>}
     */
    getIssuerTokenMetadata() {
        const ret = wasm.tokenissuer_getIssuerTokenMetadata(this.__wbg_ptr);
        return ret;
    }
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);

            } catch (e) {
                if (module.headers.get('Content-Type') != 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else {
                    throw e;
                }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);

    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };

        } else {
            return instance;
        }
    }
}

function __wbg_get_imports() {
    const imports = {};
    imports.wbg = {};
    imports.wbg.__wbg_String_8f0eb39a4a4c2f66 = function(arg0, arg1) {
        const ret = String(arg1);
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_abort_410ec47a64ac6117 = function(arg0, arg1) {
        arg0.abort(arg1);
    };
    imports.wbg.__wbg_abort_775ef1d17fc65868 = function(arg0) {
        arg0.abort();
    };
    imports.wbg.__wbg_addDeposit_42b1593db58de120 = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.addDeposit(getStringFromWasm0(arg1, arg2), arg3 >>> 0, BigInt.asUintN(64, arg4), arg5 !== 0);
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_addLeaves_226f98499cdaa66d = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.addLeaves(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_aggregateFrost_053f2d54394422d5 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.aggregateFrost(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_append_8c7dd8d641a5f01b = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
        arg0.append(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
    }, arguments) };
    imports.wbg.__wbg_arrayBuffer_d1b44c4390db422f = function() { return handleError(function (arg0) {
        const ret = arg0.arrayBuffer();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_beforeSend_57747b03876e1d28 = function() { return handleError(function (arg0, arg1, arg2) {
        var v0 = getArrayJsValueFromWasm0(arg1, arg2).slice();
        wasm.__wbindgen_free(arg1, arg2 * 4, 4);
        const ret = arg0.beforeSend(v0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_body_0b8fd1fe671660df = function(arg0) {
        const ret = arg0.body;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_breezsdk_new = function(arg0) {
        const ret = BreezSdk.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_broadcastTransaction_67533cdbfe67273e = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.broadcastTransaction(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_buffer_09165b52af8c5237 = function(arg0) {
        const ret = arg0.buffer;
        return ret;
    };
    imports.wbg.__wbg_buffer_609cc3eee51ed158 = function(arg0) {
        const ret = arg0.buffer;
        return ret;
    };
    imports.wbg.__wbg_byobRequest_77d9adf63337edfb = function(arg0) {
        const ret = arg0.byobRequest;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_byteLength_e674b853d9c77e1d = function(arg0) {
        const ret = arg0.byteLength;
        return ret;
    };
    imports.wbg.__wbg_byteOffset_fd862df290ef848d = function(arg0) {
        const ret = arg0.byteOffset;
        return ret;
    };
    imports.wbg.__wbg_call_672a4d21634d4a24 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.call(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_call_7cccdd69e0791ae2 = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = arg0.call(arg1, arg2);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_cancelReservation_d85a13db3e8e3c7b = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.cancelReservation(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_cancelReservation_fd3065607b457424 = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.cancelReservation(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_cancel_8a308660caa6cadf = function(arg0) {
        const ret = arg0.cancel();
        return ret;
    };
    imports.wbg.__wbg_catch_a6e601879b2610e9 = function(arg0, arg1) {
        const ret = arg0.catch(arg1);
        return ret;
    };
    imports.wbg.__wbg_clearTimeout_5a54f8841c30079a = function(arg0) {
        const ret = clearTimeout(arg0);
        return ret;
    };
    imports.wbg.__wbg_clearTimeout_6222fede17abcb1a = function(arg0) {
        const ret = clearTimeout(arg0);
        return ret;
    };
    imports.wbg.__wbg_close_2893b7d056a0627d = function() { return handleError(function (arg0) {
        arg0.close();
    }, arguments) };
    imports.wbg.__wbg_close_304cc1fef3466669 = function() { return handleError(function (arg0) {
        arg0.close();
    }, arguments) };
    imports.wbg.__wbg_close_5ce03e29be453811 = function() { return handleError(function (arg0) {
        arg0.close();
    }, arguments) };
    imports.wbg.__wbg_close_e1253d480ed93ce3 = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        arg0.close(arg1, getStringFromWasm0(arg2, arg3));
    }, arguments) };
    imports.wbg.__wbg_code_cfd8f6868bdaed9b = function(arg0) {
        const ret = arg0.code;
        return ret;
    };
    imports.wbg.__wbg_code_f4ec1e6e2e1b0417 = function(arg0) {
        const ret = arg0.code;
        return ret;
    };
    imports.wbg.__wbg_createDefaultStorage_458aa01b5eaead27 = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = createDefaultStorage(getStringFromWasm0(arg0, arg1), arg2);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_createPostgresPool_8b4003e9db8e9432 = function() { return handleError(function (arg0) {
        const ret = createPostgresPool(arg0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_createPostgresStorageWithPool_77aa64bddd7440db = function() { return handleError(function (arg0, arg1) {
        const ret = createPostgresStorageWithPool(arg0, arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_createPostgresTokenStoreWithPool_5e7b75f5975d8b94 = function() { return handleError(function (arg0, arg1) {
        const ret = createPostgresTokenStoreWithPool(arg0, arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_createPostgresTreeStoreWithPool_55e19122e69fb9e3 = function() { return handleError(function (arg0, arg1) {
        const ret = createPostgresTreeStoreWithPool(arg0, arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_crypto_574e78ad8b13b65f = function(arg0) {
        const ret = arg0.crypto;
        return ret;
    };
    imports.wbg.__wbg_data_432d9c3df2630942 = function(arg0) {
        const ret = arg0.data;
        return ret;
    };
    imports.wbg.__wbg_deleteCachedItem_ff3c84380e94360b = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.deleteCachedItem(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_deleteContact_04d635b32c469d83 = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.deleteContact(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_deleteDeposit_72ec826e7c3c3ccf = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.deleteDeposit(getStringFromWasm0(arg1, arg2), arg3 >>> 0);
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_deleteRequest_7be0a74a10deac70 = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            let v1;
            if (arg4 !== 0) {
                v1 = getStringFromWasm0(arg4, arg5).slice();
                wasm.__wbindgen_free(arg4, arg5 * 1, 1);
            }
            const ret = arg0.deleteRequest(getStringFromWasm0(arg1, arg2), arg3, v1);
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_derivePrfSeed_8584c0fcf554b593 = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.derivePrfSeed(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_derivePublicKey_736fb57b6852f201 = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.derivePublicKey(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_done_769e5ede4b31c67b = function(arg0) {
        const ret = arg0.done;
        return ret;
    };
    imports.wbg.__wbg_eciesDecrypt_f54e495a0988c2cc = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
        let deferred1_0;
        let deferred1_1;
        try {
            var v0 = getArrayU8FromWasm0(arg1, arg2).slice();
            wasm.__wbindgen_free(arg1, arg2 * 1, 1);
            deferred1_0 = arg3;
            deferred1_1 = arg4;
            const ret = arg0.eciesDecrypt(v0, getStringFromWasm0(arg3, arg4));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_eciesEncrypt_d1c5b3c6a4602a28 = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
        let deferred1_0;
        let deferred1_1;
        try {
            var v0 = getArrayU8FromWasm0(arg1, arg2).slice();
            wasm.__wbindgen_free(arg1, arg2 * 1, 1);
            deferred1_0 = arg3;
            deferred1_1 = arg4;
            const ret = arg0.eciesEncrypt(v0, getStringFromWasm0(arg3, arg4));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_encryptPrivateKeyForReceiver_346eec1080ebe04c = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = arg0.encryptPrivateKeyForReceiver(arg1, arg2);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_enqueue_bb16ba72f537dc9e = function() { return handleError(function (arg0, arg1) {
        arg0.enqueue(arg1);
    }, arguments) };
    imports.wbg.__wbg_entries_3265d4158b33e5dc = function(arg0) {
        const ret = Object.entries(arg0);
        return ret;
    };
    imports.wbg.__wbg_error_e98c298703cffa97 = function(arg0, arg1) {
        console.error(getStringFromWasm0(arg0, arg1));
    };
    imports.wbg.__wbg_fetchFiatCurrencies_d11be091c7fac943 = function() { return handleError(function (arg0) {
        const ret = arg0.fetchFiatCurrencies();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_fetchFiatRates_a5bc2d1be56de4a7 = function() { return handleError(function (arg0) {
        const ret = arg0.fetchFiatRates();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_fetch_07cd86dd296a5a63 = function(arg0, arg1, arg2) {
        const ret = arg0.fetch(arg1, arg2);
        return ret;
    };
    imports.wbg.__wbg_fetch_509096533071c657 = function(arg0, arg1) {
        const ret = arg0.fetch(arg1);
        return ret;
    };
    imports.wbg.__wbg_fetch_769f3df592e37b75 = function(arg0, arg1) {
        const ret = fetch(arg0, arg1);
        return ret;
    };
    imports.wbg.__wbg_fetch_f156d10be9a5c88a = function(arg0) {
        const ret = fetch(arg0);
        return ret;
    };
    imports.wbg.__wbg_finalizeReservation_86ee8385c17e015b = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.finalizeReservation(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_finalizeReservation_a8fad570b7fe5185 = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.finalizeReservation(getStringFromWasm0(arg1, arg2), arg3);
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_generateFrostSigningCommitments_0630bbabc5b72b42 = function() { return handleError(function (arg0) {
        const ret = arg0.generateFrostSigningCommitments();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_generateRandomSecret_3dcc7ca4a61a1d4d = function() { return handleError(function (arg0) {
        const ret = arg0.generateRandomSecret();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getAddressUtxos_328ceb8b4a63a6da = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.getAddressUtxos(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_getCachedItem_de40d6348815c7b9 = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.getCachedItem(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_getContact_b7300737e5dee01b = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.getContact(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_getLeaves_c94a1c927d239738 = function() { return handleError(function (arg0) {
        const ret = arg0.getLeaves();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getPaymentById_c23144bfc404b2fc = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.getPaymentById(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_getPaymentByInvoice_afddfcbefa5508b0 = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.getPaymentByInvoice(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_getPaymentsByParentIds_0f8f8e0097a07321 = function() { return handleError(function (arg0, arg1, arg2) {
        var v0 = getArrayJsValueFromWasm0(arg1, arg2).slice();
        wasm.__wbindgen_free(arg1, arg2 * 4, 4);
        const ret = arg0.getPaymentsByParentIds(v0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getPublicKeyForNode_5ddb3378904e4ad4 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.getPublicKeyForNode(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getPublicKeyFromSecretSource_9e324c0b205a9f99 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.getPublicKeyFromSecretSource(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getRandomValues_b8f5dbd5f3995a9e = function() { return handleError(function (arg0, arg1) {
        arg0.getRandomValues(arg1);
    }, arguments) };
    imports.wbg.__wbg_getRandomValues_e14bd3de0db61032 = function() { return handleError(function (arg0, arg1) {
        globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
    }, arguments) };
    imports.wbg.__wbg_getReader_48e00749fe3f6089 = function() { return handleError(function (arg0) {
        const ret = arg0.getReader();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getRequest_4ab87a8cbe18fa22 = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.getRequest(getStringFromWasm0(arg1, arg2), arg3);
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_getStaticDepositPrivateKey_203e6f4eb4116ce0 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.getStaticDepositPrivateKey(arg1 >>> 0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getStaticDepositPublicKey_4551dec44c20efe6 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.getStaticDepositPublicKey(arg1 >>> 0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getStaticDepositSecretSource_8e310c718339e400 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.getStaticDepositSecretSource(arg1 >>> 0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getTokenOutputs_f51d6f5d47330273 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.getTokenOutputs(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getTransactionHex_973b8d0555c60f99 = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.getTransactionHex(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_getTransactionStatus_731f0ef840c27f99 = function() { return handleError(function (arg0, arg1, arg2) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.getTransactionStatus(getStringFromWasm0(arg1, arg2));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_get_67b2ba62fc30de12 = function() { return handleError(function (arg0, arg1) {
        const ret = Reflect.get(arg0, arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_get_b9b93047fe3cf45b = function(arg0, arg1) {
        const ret = arg0[arg1 >>> 0];
        return ret;
    };
    imports.wbg.__wbg_getdone_d47073731acd3e74 = function(arg0) {
        const ret = arg0.done;
        return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
    };
    imports.wbg.__wbg_getvalue_009dcd63692bee1f = function(arg0) {
        const ret = arg0.value;
        return ret;
    };
    imports.wbg.__wbg_getwithrefkey_1dc361bd10053bfe = function(arg0, arg1) {
        const ret = arg0[arg1];
        return ret;
    };
    imports.wbg.__wbg_has_a5ea9117f258a0ec = function() { return handleError(function (arg0, arg1) {
        const ret = Reflect.has(arg0, arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_headers_9cb51cfd2ac780a4 = function(arg0) {
        const ret = arg0.headers;
        return ret;
    };
    imports.wbg.__wbg_hmacSha256_c6633de6089f686f = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
        let deferred1_0;
        let deferred1_1;
        try {
            var v0 = getArrayU8FromWasm0(arg1, arg2).slice();
            wasm.__wbindgen_free(arg1, arg2 * 1, 1);
            deferred1_0 = arg3;
            deferred1_1 = arg4;
            const ret = arg0.hmacSha256(v0, getStringFromWasm0(arg3, arg4));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_identityPublicKey_c8b35005055a3df0 = function() { return handleError(function (arg0) {
        const ret = arg0.identityPublicKey();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_insertContact_33c214012213409d = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.insertContact(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_insertPaymentMetadata_0c4ebdcde694d29b = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.insertPaymentMetadata(getStringFromWasm0(arg1, arg2), arg3);
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_insertPayment_2afe3300c5f86ccf = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.insertPayment(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_insertTokenOutputs_043ceea065ff8f65 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.insertTokenOutputs(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_instanceof_ArrayBuffer_e14585432e3737fc = function(arg0) {
        let result;
        try {
            result = arg0 instanceof ArrayBuffer;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_Blob_ca721ef3bdab15d1 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof Blob;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_DomException_ed1ccb7aaf39034c = function(arg0) {
        let result;
        try {
            result = arg0 instanceof DOMException;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_Error_4d54113b22d20306 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof Error;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_Map_f3469ce2244d2430 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof Map;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_Object_7f2dcef8f78644a4 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof Object;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_Response_f2cc20d9f7dfd644 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof Response;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_Uint8Array_17156bcf118086a9 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof Uint8Array;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_isArray_a1eab7e0d067391b = function(arg0) {
        const ret = Array.isArray(arg0);
        return ret;
    };
    imports.wbg.__wbg_isPrfAvailable_c13e727932109c6e = function() { return handleError(function (arg0) {
        const ret = arg0.isPrfAvailable();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_isSafeInteger_343e2beeeece1bb0 = function(arg0) {
        const ret = Number.isSafeInteger(arg0);
        return ret;
    };
    imports.wbg.__wbg_iterator_9a24c88df860dc65 = function() {
        const ret = Symbol.iterator;
        return ret;
    };
    imports.wbg.__wbg_length_a446193dc22c12f8 = function(arg0) {
        const ret = arg0.length;
        return ret;
    };
    imports.wbg.__wbg_length_e2d2a49132c1b256 = function(arg0) {
        const ret = arg0.length;
        return ret;
    };
    imports.wbg.__wbg_listContacts_5b4d38a57743b713 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.listContacts(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_listDeposits_7ca6e22afc06d560 = function() { return handleError(function (arg0) {
        const ret = arg0.listDeposits();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_listPayments_d8c53ab09ffc756b = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.listPayments(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_listTokensOutputs_4b4500bd5aca2c88 = function() { return handleError(function (arg0) {
        const ret = arg0.listTokensOutputs();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_log_62b3ddcc89229688 = function(arg0, arg1) {
        arg0.log(arg1);
    };
    imports.wbg.__wbg_message_5c5d919204d42400 = function(arg0, arg1) {
        const ret = arg1.message;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_message_97a2af9b89d693a3 = function(arg0) {
        const ret = arg0.message;
        return ret;
    };
    imports.wbg.__wbg_msCrypto_a61aeb35a24c1329 = function(arg0) {
        const ret = arg0.msCrypto;
        return ret;
    };
    imports.wbg.__wbg_name_0b327d569f00ebee = function(arg0) {
        const ret = arg0.name;
        return ret;
    };
    imports.wbg.__wbg_name_f2d27098bfd843e7 = function(arg0, arg1) {
        const ret = arg1.name;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_new_018dcc2d6c8c2f6a = function() { return handleError(function () {
        const ret = new Headers();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_new_23a2665fac83c611 = function(arg0, arg1) {
        try {
            var state0 = {a: arg0, b: arg1};
            var cb0 = (arg0, arg1) => {
                const a = state0.a;
                state0.a = 0;
                try {
                    return __wbg_adapter_442(a, state0.b, arg0, arg1);
                } finally {
                    state0.a = a;
                }
            };
            const ret = new Promise(cb0);
            return ret;
        } finally {
            state0.a = state0.b = 0;
        }
    };
    imports.wbg.__wbg_new_405e22f390576ce2 = function() {
        const ret = new Object();
        return ret;
    };
    imports.wbg.__wbg_new_5e0be73521bc8c17 = function() {
        const ret = new Map();
        return ret;
    };
    imports.wbg.__wbg_new_78feb108b6472713 = function() {
        const ret = new Array();
        return ret;
    };
    imports.wbg.__wbg_new_92c54fc74574ef55 = function() { return handleError(function (arg0, arg1) {
        const ret = new WebSocket(getStringFromWasm0(arg0, arg1));
        return ret;
    }, arguments) };
    imports.wbg.__wbg_new_a12002a7f91c75be = function(arg0) {
        const ret = new Uint8Array(arg0);
        return ret;
    };
    imports.wbg.__wbg_new_c68d7209be747379 = function(arg0, arg1) {
        const ret = new Error(getStringFromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbg_new_e25e5aab09ff45db = function() { return handleError(function () {
        const ret = new AbortController();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_newnoargs_105ed471475aaf50 = function(arg0, arg1) {
        const ret = new Function(getStringFromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbg_newwithbyteoffsetandlength_d97e637ebe145a9a = function(arg0, arg1, arg2) {
        const ret = new Uint8Array(arg0, arg1 >>> 0, arg2 >>> 0);
        return ret;
    };
    imports.wbg.__wbg_newwithlength_a381634e90c276d4 = function(arg0) {
        const ret = new Uint8Array(arg0 >>> 0);
        return ret;
    };
    imports.wbg.__wbg_newwithstrandinit_06c535e0a867c635 = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = new Request(getStringFromWasm0(arg0, arg1), arg2);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_next_25feadfc0913fea9 = function(arg0) {
        const ret = arg0.next;
        return ret;
    };
    imports.wbg.__wbg_next_6574e1a8a62d1055 = function() { return handleError(function (arg0) {
        const ret = arg0.next();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_node_905d3e251edff8a2 = function(arg0) {
        const ret = arg0.node;
        return ret;
    };
    imports.wbg.__wbg_now_063c1184182e178a = function() { return handleError(function (arg0) {
        const ret = arg0.now();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_now_2c95c9de01293173 = function(arg0) {
        const ret = arg0.now();
        return ret;
    };
    imports.wbg.__wbg_now_6af59e24f5a53ad4 = function() { return handleError(function () {
        const ret = Date.now();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_now_79892f24f17d010a = function() { return handleError(function (arg0) {
        const ret = arg0.now();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_now_807e54c39636c349 = function() {
        const ret = Date.now();
        return ret;
    };
    imports.wbg.__wbg_onEvent_3a18bdd7cfd911cb = function(arg0, arg1) {
        arg0.onEvent(arg1);
    };
    imports.wbg.__wbg_performance_7a3ffd0b17f663ad = function(arg0) {
        const ret = arg0.performance;
        return ret;
    };
    imports.wbg.__wbg_postMessage_83a8d58d3fcb6c13 = function() { return handleError(function (arg0, arg1) {
        arg0.postMessage(arg1);
    }, arguments) };
    imports.wbg.__wbg_postRequest_678f7531153ace01 = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            let v1;
            if (arg4 !== 0) {
                v1 = getStringFromWasm0(arg4, arg5).slice();
                wasm.__wbindgen_free(arg4, arg5 * 1, 1);
            }
            const ret = arg0.postRequest(getStringFromWasm0(arg1, arg2), arg3, v1);
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_process_dc0fbacc7c1c06f7 = function(arg0) {
        const ret = arg0.process;
        return ret;
    };
    imports.wbg.__wbg_queueMicrotask_97d92b4fcc8a61c5 = function(arg0) {
        queueMicrotask(arg0);
    };
    imports.wbg.__wbg_queueMicrotask_d3219def82552485 = function(arg0) {
        const ret = arg0.queueMicrotask;
        return ret;
    };
    imports.wbg.__wbg_randomFillSync_ac0988aba3254290 = function() { return handleError(function (arg0, arg1) {
        arg0.randomFillSync(arg1);
    }, arguments) };
    imports.wbg.__wbg_read_a2434af1186cb56c = function(arg0) {
        const ret = arg0.read();
        return ret;
    };
    imports.wbg.__wbg_readyState_7ef6e63c349899ed = function(arg0) {
        const ret = arg0.readyState;
        return ret;
    };
    imports.wbg.__wbg_reason_49f1cede8bcf23dd = function(arg0, arg1) {
        const ret = arg1.reason;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_recommendedFees_a61f331fce46523e = function() { return handleError(function (arg0) {
        const ret = arg0.recommendedFees();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_releaseLock_091899af97991d2e = function(arg0) {
        arg0.releaseLock();
    };
    imports.wbg.__wbg_require_60cc747a6bc5215a = function() { return handleError(function () {
        const ret = module.require;
        return ret;
    }, arguments) };
    imports.wbg.__wbg_reserveTokenOutputs_6a190cf797e7d196 = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7) {
        let deferred0_0;
        let deferred0_1;
        let deferred1_0;
        let deferred1_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            deferred1_0 = arg4;
            deferred1_1 = arg5;
            const ret = arg0.reserveTokenOutputs(getStringFromWasm0(arg1, arg2), arg3, getStringFromWasm0(arg4, arg5), arg6, arg7);
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_resolve_4851785c9c5f573d = function(arg0) {
        const ret = Promise.resolve(arg0);
        return ret;
    };
    imports.wbg.__wbg_respond_1f279fa9f8edcb1c = function() { return handleError(function (arg0, arg1) {
        arg0.respond(arg1 >>> 0);
    }, arguments) };
    imports.wbg.__wbg_sdkbuilder_new = function(arg0) {
        const ret = SdkBuilder.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_send_0293179ba074ffb4 = function() { return handleError(function (arg0, arg1, arg2) {
        arg0.send(getStringFromWasm0(arg1, arg2));
    }, arguments) };
    imports.wbg.__wbg_send_fc0c204e8a1757f4 = function() { return handleError(function (arg0, arg1, arg2) {
        arg0.send(getArrayU8FromWasm0(arg1, arg2));
    }, arguments) };
    imports.wbg.__wbg_setCachedItem_91b03741dfb0b4c2 = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
        let deferred0_0;
        let deferred0_1;
        let deferred1_0;
        let deferred1_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            deferred1_0 = arg3;
            deferred1_1 = arg4;
            const ret = arg0.setCachedItem(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_setLeaves_d1c338c6d7d2ef28 = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        const ret = arg0.setLeaves(arg1, arg2, arg3);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_setLnurlMetadata_0bf15cc7efb6cc11 = function() { return handleError(function (arg0, arg1, arg2) {
        var v0 = getArrayJsValueFromWasm0(arg1, arg2).slice();
        wasm.__wbindgen_free(arg1, arg2 * 4, 4);
        const ret = arg0.setLnurlMetadata(v0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_setTimeout_2b339866a2aa3789 = function(arg0, arg1) {
        const ret = setTimeout(arg0, arg1);
        return ret;
    };
    imports.wbg.__wbg_setTimeout_8f06012fba12034e = function(arg0, arg1) {
        globalThis.setTimeout(arg0, arg1);
    };
    imports.wbg.__wbg_setTimeout_db2dbaeefb6f39c7 = function() { return handleError(function (arg0, arg1) {
        const ret = setTimeout(arg0, arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_setTokensOutputs_5b8449721027f347 = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = arg0.setTokensOutputs(arg1, arg2);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_set_37837023f3d740e8 = function(arg0, arg1, arg2) {
        arg0[arg1 >>> 0] = arg2;
    };
    imports.wbg.__wbg_set_3f1d0b984ed272ed = function(arg0, arg1, arg2) {
        arg0[arg1] = arg2;
    };
    imports.wbg.__wbg_set_65595bdd868b3009 = function(arg0, arg1, arg2) {
        arg0.set(arg1, arg2 >>> 0);
    };
    imports.wbg.__wbg_set_8fc6bf8a5b1071d1 = function(arg0, arg1, arg2) {
        const ret = arg0.set(arg1, arg2);
        return ret;
    };
    imports.wbg.__wbg_set_bb8cecf6a62b9f46 = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = Reflect.set(arg0, arg1, arg2);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_setbinaryType_92fa1ffd873b327c = function(arg0, arg1) {
        arg0.binaryType = __wbindgen_enum_BinaryType[arg1];
    };
    imports.wbg.__wbg_setbody_5923b78a95eedf29 = function(arg0, arg1) {
        arg0.body = arg1;
    };
    imports.wbg.__wbg_setcache_12f17c3a980650e4 = function(arg0, arg1) {
        arg0.cache = __wbindgen_enum_RequestCache[arg1];
    };
    imports.wbg.__wbg_setcredentials_c3a22f1cd105a2c6 = function(arg0, arg1) {
        arg0.credentials = __wbindgen_enum_RequestCredentials[arg1];
    };
    imports.wbg.__wbg_setheaders_834c0bdb6a8949ad = function(arg0, arg1) {
        arg0.headers = arg1;
    };
    imports.wbg.__wbg_setintegrity_564a2397cf837760 = function(arg0, arg1, arg2) {
        arg0.integrity = getStringFromWasm0(arg1, arg2);
    };
    imports.wbg.__wbg_setmethod_3c5280fe5d890842 = function(arg0, arg1, arg2) {
        arg0.method = getStringFromWasm0(arg1, arg2);
    };
    imports.wbg.__wbg_setmode_5dc300b865044b65 = function(arg0, arg1) {
        arg0.mode = __wbindgen_enum_RequestMode[arg1];
    };
    imports.wbg.__wbg_setonclose_14fc475a49d488fc = function(arg0, arg1) {
        arg0.onclose = arg1;
    };
    imports.wbg.__wbg_setonerror_8639efe354b947cd = function(arg0, arg1) {
        arg0.onerror = arg1;
    };
    imports.wbg.__wbg_setonmessage_6eccab530a8fb4c7 = function(arg0, arg1) {
        arg0.onmessage = arg1;
    };
    imports.wbg.__wbg_setonopen_2da654e1f39745d5 = function(arg0, arg1) {
        arg0.onopen = arg1;
    };
    imports.wbg.__wbg_setredirect_40e6a7f717a2f86a = function(arg0, arg1) {
        arg0.redirect = __wbindgen_enum_RequestRedirect[arg1];
    };
    imports.wbg.__wbg_setreferrer_fea46c1230e5e29a = function(arg0, arg1, arg2) {
        arg0.referrer = getStringFromWasm0(arg1, arg2);
    };
    imports.wbg.__wbg_setreferrerpolicy_b73612479f761b6f = function(arg0, arg1) {
        arg0.referrerPolicy = __wbindgen_enum_ReferrerPolicy[arg1];
    };
    imports.wbg.__wbg_setsignal_75b21ef3a81de905 = function(arg0, arg1) {
        arg0.signal = arg1;
    };
    imports.wbg.__wbg_signEcdsaRecoverable_756dd79f08e5ed39 = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg2;
            deferred0_1 = arg3;
            const ret = arg0.signEcdsaRecoverable(arg1, getStringFromWasm0(arg2, arg3));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_signEcdsa_0ebea9dfc3b7c28f = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg2;
            deferred0_1 = arg3;
            const ret = arg0.signEcdsa(arg1, getStringFromWasm0(arg2, arg3));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_signFrost_06ac652135c4e862 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.signFrost(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_signHashSchnorr_390c51f0bbb70a7a = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
        let deferred1_0;
        let deferred1_1;
        try {
            var v0 = getArrayU8FromWasm0(arg1, arg2).slice();
            wasm.__wbindgen_free(arg1, arg2 * 1, 1);
            deferred1_0 = arg3;
            deferred1_1 = arg4;
            const ret = arg0.signHashSchnorr(v0, getStringFromWasm0(arg3, arg4));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_signal_aaf9ad74119f20a4 = function(arg0) {
        const ret = arg0.signal;
        return ret;
    };
    imports.wbg.__wbg_splitSecretWithProofs_1aba146de2c5eb0a = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        const ret = arg0.splitSecretWithProofs(arg1, arg2 >>> 0, arg3 >>> 0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_static_accessor_GLOBAL_88a902d13a557d07 = function() {
        const ret = typeof global === 'undefined' ? null : global;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_static_accessor_GLOBAL_THIS_56578be7e9f832b0 = function() {
        const ret = typeof globalThis === 'undefined' ? null : globalThis;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_static_accessor_SELF_37c5d418e4bf5819 = function() {
        const ret = typeof self === 'undefined' ? null : self;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_static_accessor_WINDOW_5de37043a91a9c40 = function() {
        const ret = typeof window === 'undefined' ? null : window;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_status_f6360336ca686bf0 = function(arg0) {
        const ret = arg0.status;
        return ret;
    };
    imports.wbg.__wbg_stringify_f7ed6987935b4a24 = function() { return handleError(function (arg0) {
        const ret = JSON.stringify(arg0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_subarray_aa9065fa9dc5df96 = function(arg0, arg1, arg2) {
        const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
        return ret;
    };
    imports.wbg.__wbg_subtractPrivateKeys_2d63747d9fa64d4f = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = arg0.subtractPrivateKeys(arg1, arg2);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_syncAddOutgoingChange_9d94d35ba215d3c9 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.syncAddOutgoingChange(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_syncCompleteOutgoingSync_959431da825d4042 = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = arg0.syncCompleteOutgoingSync(arg1, BigInt.asUintN(64, arg2));
        return ret;
    }, arguments) };
    imports.wbg.__wbg_syncDeleteIncomingRecord_ff76566691e4d7ca = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.syncDeleteIncomingRecord(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_syncGetIncomingRecords_a47bcdbce33f391b = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.syncGetIncomingRecords(arg1 >>> 0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_syncGetLastRevision_3c8cdf9b9d5acbc9 = function() { return handleError(function (arg0) {
        const ret = arg0.syncGetLastRevision();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_syncGetLatestOutgoingChange_1a359277ba2618e6 = function() { return handleError(function (arg0) {
        const ret = arg0.syncGetLatestOutgoingChange();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_syncGetPendingOutgoingChanges_d2f9a942e5bbaa06 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.syncGetPendingOutgoingChanges(arg1 >>> 0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_syncInsertIncomingRecords_dde4039dbc9cb38f = function() { return handleError(function (arg0, arg1, arg2) {
        var v0 = getArrayJsValueFromWasm0(arg1, arg2).slice();
        wasm.__wbindgen_free(arg1, arg2 * 4, 4);
        const ret = arg0.syncInsertIncomingRecords(v0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_syncUpdateRecordFromIncoming_a76ad82592bfdcb3 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.syncUpdateRecordFromIncoming(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_text_7805bea50de2af49 = function() { return handleError(function (arg0) {
        const ret = arg0.text();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_then_44b73946d2fb3e7d = function(arg0, arg1) {
        const ret = arg0.then(arg1);
        return ret;
    };
    imports.wbg.__wbg_then_48b406749878a531 = function(arg0, arg1, arg2) {
        const ret = arg0.then(arg1, arg2);
        return ret;
    };
    imports.wbg.__wbg_toString_5285597960676b7b = function(arg0) {
        const ret = arg0.toString();
        return ret;
    };
    imports.wbg.__wbg_tryReserveLeaves_9aacd30c9750a9df = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg3;
            deferred0_1 = arg4;
            const ret = arg0.tryReserveLeaves(arg1, arg2 !== 0, getStringFromWasm0(arg3, arg4));
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_updateDeposit_87746090235ed235 = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.updateDeposit(getStringFromWasm0(arg1, arg2), arg3 >>> 0, arg4);
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_updateReservation_7641cd63d1a894b8 = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
        let deferred0_0;
        let deferred0_1;
        try {
            deferred0_0 = arg1;
            deferred0_1 = arg2;
            const ret = arg0.updateReservation(getStringFromWasm0(arg1, arg2), arg3, arg4);
            return ret;
        } finally {
            wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
    }, arguments) };
    imports.wbg.__wbg_url_ae10c34ca209681d = function(arg0, arg1) {
        const ret = arg1.url;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_url_ce9ab75bf9627ae4 = function(arg0, arg1) {
        const ret = arg1.url;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_value_cd1ffa7b1ab794f1 = function(arg0) {
        const ret = arg0.value;
        return ret;
    };
    imports.wbg.__wbg_versions_c01dfd4722a88165 = function(arg0) {
        const ret = arg0.versions;
        return ret;
    };
    imports.wbg.__wbg_view_fd8a56e8983f448d = function(arg0) {
        const ret = arg0.view;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_wasClean_605b4fd66d44354a = function(arg0) {
        const ret = arg0.wasClean;
        return ret;
    };
    imports.wbg.__wbindgen_array_new = function() {
        const ret = [];
        return ret;
    };
    imports.wbg.__wbindgen_array_push = function(arg0, arg1) {
        arg0.push(arg1);
    };
    imports.wbg.__wbindgen_as_number = function(arg0) {
        const ret = +arg0;
        return ret;
    };
    imports.wbg.__wbindgen_bigint_from_i64 = function(arg0) {
        const ret = arg0;
        return ret;
    };
    imports.wbg.__wbindgen_bigint_from_u128 = function(arg0, arg1) {
        const ret = BigInt.asUintN(64, arg0) << BigInt(64) | BigInt.asUintN(64, arg1);
        return ret;
    };
    imports.wbg.__wbindgen_bigint_from_u64 = function(arg0) {
        const ret = BigInt.asUintN(64, arg0);
        return ret;
    };
    imports.wbg.__wbindgen_bigint_get_as_i64 = function(arg0, arg1) {
        const v = arg1;
        const ret = typeof(v) === 'bigint' ? v : undefined;
        getDataViewMemory0().setBigInt64(arg0 + 8 * 1, isLikeNone(ret) ? BigInt(0) : ret, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
    };
    imports.wbg.__wbindgen_boolean_get = function(arg0) {
        const v = arg0;
        const ret = typeof(v) === 'boolean' ? (v ? 1 : 0) : 2;
        return ret;
    };
    imports.wbg.__wbindgen_cb_drop = function(arg0) {
        const obj = arg0.original;
        if (obj.cnt-- == 1) {
            obj.a = 0;
            return true;
        }
        const ret = false;
        return ret;
    };
    imports.wbg.__wbindgen_closure_wrapper11576 = function(arg0, arg1, arg2) {
        const ret = makeMutClosure(arg0, arg1, 425, __wbg_adapter_77);
        return ret;
    };
    imports.wbg.__wbindgen_closure_wrapper16810 = function(arg0, arg1, arg2) {
        const ret = makeMutClosure(arg0, arg1, 425, __wbg_adapter_64);
        return ret;
    };
    imports.wbg.__wbindgen_closure_wrapper2467 = function(arg0, arg1, arg2) {
        const ret = makeMutClosure(arg0, arg1, 425, __wbg_adapter_64);
        return ret;
    };
    imports.wbg.__wbindgen_closure_wrapper2472 = function(arg0, arg1, arg2) {
        const ret = makeMutClosure(arg0, arg1, 425, __wbg_adapter_64);
        return ret;
    };
    imports.wbg.__wbindgen_closure_wrapper2480 = function(arg0, arg1, arg2) {
        const ret = makeMutClosure(arg0, arg1, 425, __wbg_adapter_64);
        return ret;
    };
    imports.wbg.__wbindgen_closure_wrapper2481 = function(arg0, arg1, arg2) {
        const ret = makeMutClosure(arg0, arg1, 1141, __wbg_adapter_64);
        return ret;
    };
    imports.wbg.__wbindgen_closure_wrapper6432 = function(arg0, arg1, arg2) {
        const ret = makeMutClosure(arg0, arg1, 425, __wbg_adapter_64);
        return ret;
    };
    imports.wbg.__wbindgen_closure_wrapper6436 = function(arg0, arg1, arg2) {
        const ret = makeMutClosure(arg0, arg1, 425, __wbg_adapter_64);
        return ret;
    };
    imports.wbg.__wbindgen_closure_wrapper8576 = function(arg0, arg1, arg2) {
        const ret = makeMutClosure(arg0, arg1, 928, __wbg_adapter_77);
        return ret;
    };
    imports.wbg.__wbindgen_debug_string = function(arg0, arg1) {
        const ret = debugString(arg1);
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbindgen_error_new = function(arg0, arg1) {
        const ret = new Error(getStringFromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbindgen_in = function(arg0, arg1) {
        const ret = arg0 in arg1;
        return ret;
    };
    imports.wbg.__wbindgen_init_externref_table = function() {
        const table = wasm.__wbindgen_export_5;
        const offset = table.grow(4);
        table.set(0, undefined);
        table.set(offset + 0, undefined);
        table.set(offset + 1, null);
        table.set(offset + 2, true);
        table.set(offset + 3, false);
        ;
    };
    imports.wbg.__wbindgen_is_bigint = function(arg0) {
        const ret = typeof(arg0) === 'bigint';
        return ret;
    };
    imports.wbg.__wbindgen_is_function = function(arg0) {
        const ret = typeof(arg0) === 'function';
        return ret;
    };
    imports.wbg.__wbindgen_is_null = function(arg0) {
        const ret = arg0 === null;
        return ret;
    };
    imports.wbg.__wbindgen_is_object = function(arg0) {
        const val = arg0;
        const ret = typeof(val) === 'object' && val !== null;
        return ret;
    };
    imports.wbg.__wbindgen_is_string = function(arg0) {
        const ret = typeof(arg0) === 'string';
        return ret;
    };
    imports.wbg.__wbindgen_is_undefined = function(arg0) {
        const ret = arg0 === undefined;
        return ret;
    };
    imports.wbg.__wbindgen_jsval_eq = function(arg0, arg1) {
        const ret = arg0 === arg1;
        return ret;
    };
    imports.wbg.__wbindgen_jsval_loose_eq = function(arg0, arg1) {
        const ret = arg0 == arg1;
        return ret;
    };
    imports.wbg.__wbindgen_memory = function() {
        const ret = wasm.memory;
        return ret;
    };
    imports.wbg.__wbindgen_number_get = function(arg0, arg1) {
        const obj = arg1;
        const ret = typeof(obj) === 'number' ? obj : undefined;
        getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
    };
    imports.wbg.__wbindgen_number_new = function(arg0) {
        const ret = arg0;
        return ret;
    };
    imports.wbg.__wbindgen_shr = function(arg0, arg1) {
        const ret = arg0 >> arg1;
        return ret;
    };
    imports.wbg.__wbindgen_string_get = function(arg0, arg1) {
        const obj = arg1;
        const ret = typeof(obj) === 'string' ? obj : undefined;
        var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbindgen_string_new = function(arg0, arg1) {
        const ret = getStringFromWasm0(arg0, arg1);
        return ret;
    };
    imports.wbg.__wbindgen_throw = function(arg0, arg1) {
        throw new Error(getStringFromWasm0(arg0, arg1));
    };
    imports.wbg.__wbindgen_uint8_array_new = function(arg0, arg1) {
        var v0 = getArrayU8FromWasm0(arg0, arg1).slice();
        wasm.__wbindgen_free(arg0, arg1 * 1, 1);
        const ret = v0;
        return ret;
    };

    return imports;
}

function __wbg_init_memory(imports, memory) {

}

function __wbg_finalize_init(instance, module) {
    wasm = instance.exports;
    __wbg_init.__wbindgen_wasm_module = module;
    cachedDataViewMemory0 = null;
    cachedUint8ArrayMemory0 = null;


    wasm.__wbindgen_start();
    return wasm;
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (typeof module !== 'undefined') {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();

    __wbg_init_memory(imports);

    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }

    const instance = new WebAssembly.Instance(module, imports);

    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (typeof module_or_path !== 'undefined') {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (typeof module_or_path === 'undefined') {
        module_or_path = new URL('breez_sdk_spark_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    __wbg_init_memory(imports);

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync };
export default __wbg_init;
