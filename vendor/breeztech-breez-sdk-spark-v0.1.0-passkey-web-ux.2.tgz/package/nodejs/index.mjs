// ESM wrapper for the CJS Node.js entry — re-exports named bindings
// so that `import { connect } from '@breeztech/breez-sdk-spark'` works
// in ESM contexts.
import pkg from './index.js';

export const {
  connect,
  connectWithSigner,
  defaultConfig,
  defaultExternalSigner,
  defaultMysqlStorageConfig,
  defaultPostgresStorageConfig,
  getSparkStatus,
  initLogging,
  task_worker_entry_point,
  BreezSdk,
  DefaultSigner,
  IntoUnderlyingByteSource,
  IntoUnderlyingSink,
  IntoUnderlyingSource,
  Passkey,
  SdkBuilder,
  TokenIssuer,
} = pkg;

export default pkg;
