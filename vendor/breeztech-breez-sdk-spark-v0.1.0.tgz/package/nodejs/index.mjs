// ESM wrapper for the CJS Node.js entry: re-exports named bindings
// so that `import { connect } from '@breeztech/breez-sdk-spark'` works
// in ESM contexts.
import pkg from './index.js';

export const {
  connect,
  connectWithSigner,
  defaultConfig,
  defaultExternalSigner,
  defaultMysqlStorageConfig,
  defaultPostgresStorageConfig,
  defaultServerConfig,
  defaultStorage,
  getSparkStatus,
  initLogging,
  mysqlStorage,
  newRestChainService,
  newSharedSdkContext,
  postgresStorage,
  task_worker_entry_point,
  BitcoinChainServiceHandle,
  BreezSdk,
  DefaultSigner,
  IntoUnderlyingByteSource,
  IntoUnderlyingSink,
  IntoUnderlyingSource,
  PasskeyClient,
  PasskeyLabels,
  SdkBuilder,
  TokenIssuer,
  WasmSdkContext,
  WasmStorageConfig,
} = pkg;

export default pkg;
