// SSR-safe entry point for Breez SDK
// Safe to import during server-side rendering — no WASM, no browser APIs, no Node.js APIs.
// Call init() on the client before using any SDK functions.

let _module = null;
let _initPromise = null;

function _notInitialized(name) {
  throw new Error(
    `@breeztech/breez-sdk-spark: "${name}" called before init(). ` +
    `Call "await init()" on the client before using SDK functions.`
  );
}

export default async function init(wasmInput) {
  if (_module) return;
  if (_initPromise) return _initPromise;
  _initPromise = (async () => {
    const mod = await import('../web/index.js');
    await mod.default(wasmInput);
    _module = mod;
  })();
  return _initPromise;
}

export function defaultPostgresStorageConfig(...args) {
  if (!_module) _notInitialized('defaultPostgresStorageConfig');
  return _module.defaultPostgresStorageConfig(...args);
}

export function connect(...args) {
  if (!_module) _notInitialized('connect');
  return _module.connect(...args);
}

export function defaultConfig(...args) {
  if (!_module) _notInitialized('defaultConfig');
  return _module.defaultConfig(...args);
}

export function initLogging(...args) {
  if (!_module) _notInitialized('initLogging');
  return _module.initLogging(...args);
}

export function connectWithSigner(...args) {
  if (!_module) _notInitialized('connectWithSigner');
  return _module.connectWithSigner(...args);
}

export function getSparkStatus(...args) {
  if (!_module) _notInitialized('getSparkStatus');
  return _module.getSparkStatus(...args);
}

export function defaultExternalSigner(...args) {
  if (!_module) _notInitialized('defaultExternalSigner');
  return _module.defaultExternalSigner(...args);
}

export function task_worker_entry_point(...args) {
  if (!_module) _notInitialized('task_worker_entry_point');
  return _module.task_worker_entry_point(...args);
}

export function initSync(...args) {
  if (!_module) _notInitialized('initSync');
  return _module.initSync(...args);
}

export class BreezSdk {
  constructor(...args) {
    if (!_module) _notInitialized('new BreezSdk');
    return new _module.BreezSdk(...args);
  }
}

export class DefaultSigner {
  constructor(...args) {
    if (!_module) _notInitialized('new DefaultSigner');
    return new _module.DefaultSigner(...args);
  }
}

export class IntoUnderlyingByteSource {
  constructor(...args) {
    if (!_module) _notInitialized('new IntoUnderlyingByteSource');
    return new _module.IntoUnderlyingByteSource(...args);
  }
}

export class IntoUnderlyingSink {
  constructor(...args) {
    if (!_module) _notInitialized('new IntoUnderlyingSink');
    return new _module.IntoUnderlyingSink(...args);
  }
}

export class IntoUnderlyingSource {
  constructor(...args) {
    if (!_module) _notInitialized('new IntoUnderlyingSource');
    return new _module.IntoUnderlyingSource(...args);
  }
}

export class Passkey {
  constructor(...args) {
    if (!_module) _notInitialized('new Passkey');
    return new _module.Passkey(...args);
  }
}

export class SdkBuilder {
  constructor(...args) {
    if (!_module) _notInitialized('new SdkBuilder');
    return new _module.SdkBuilder(...args);
  }
}

export class TokenIssuer {
  constructor(...args) {
    if (!_module) _notInitialized('new TokenIssuer');
    return new _module.TokenIssuer(...args);
  }
}

