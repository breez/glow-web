/* @ts-self-types="./breez_sdk_spark_wasm.d.ts" */
import * as wasm from "./breez_sdk_spark_wasm_bg.wasm";
import { __wbg_set_wasm } from "./breez_sdk_spark_wasm_bg.js";

__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    BitcoinChainServiceHandle, BreezSdk, DefaultSigner, IntoUnderlyingByteSource, IntoUnderlyingSink, IntoUnderlyingSource, MysqlConnectionPool, Passkey, PostgresConnectionPool, SdkBuilder, TokenIssuer, WasmSdkContext, connect, connectWithSigner, createMysqlConnectionPool, createPostgresConnectionPool, defaultConfig, defaultExternalSigner, defaultMysqlStorageConfig, defaultPostgresStorageConfig, defaultServerConfig, getSparkStatus, initLogging, newRestChainService, newSharedSdkContext, task_worker_entry_point
} from "./breez_sdk_spark_wasm_bg.js";
