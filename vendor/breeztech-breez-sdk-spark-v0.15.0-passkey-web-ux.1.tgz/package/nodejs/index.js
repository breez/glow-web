// Node.js entry point for Breez SDK with automatic storage support
const wasmModule = require('./breez_sdk_spark_wasm.js');

// Automatically import and set up the storage for Node.js
try {
    const { createDefaultStorage } = require('./storage/index.cjs');

    // Make createDefaultStorage available globally for WASM to find
    global.createDefaultStorage = createDefaultStorage;

    console.log('Breez SDK: Node.js storage automatically enabled');
} catch (error) {
    console.warn('Breez SDK: Failed to load Node.js storage:', error.message);
    console.warn('Breez SDK: Storage operations may not work properly. Ignore this warning if you are not using the default storage.');
}

// Automatically import and set up the PostgreSQL storage for Node.js
try {
    const { createPostgresStorage, createPostgresPool, createPostgresStorageWithPool } = require('./postgres-storage/index.cjs');
    global.createPostgresStorage = createPostgresStorage;
    global.createPostgresPool = createPostgresPool;
    global.createPostgresStorageWithPool = createPostgresStorageWithPool;
} catch (error) {
    if (error.code !== 'MODULE_NOT_FOUND') {
        console.warn('Breez SDK: Failed to load PostgreSQL storage:', error.message);
    }
}

// Automatically import and set up the PostgreSQL tree store for Node.js
try {
    const { createPostgresTreeStore, createPostgresTreeStoreWithPool } = require('./postgres-tree-store/index.cjs');
    global.createPostgresTreeStore = createPostgresTreeStore;
    global.createPostgresTreeStoreWithPool = createPostgresTreeStoreWithPool;
} catch (error) {
    if (error.code !== 'MODULE_NOT_FOUND') {
        console.warn('Breez SDK: Failed to load PostgreSQL tree store:', error.message);
    }
}

// Automatically import and set up the PostgreSQL token store for Node.js
try {
    const { createPostgresTokenStore, createPostgresTokenStoreWithPool } = require('./postgres-token-store/index.cjs');
    global.createPostgresTokenStore = createPostgresTokenStore;
    global.createPostgresTokenStoreWithPool = createPostgresTokenStoreWithPool;
} catch (error) {
    if (error.code !== 'MODULE_NOT_FOUND') {
        console.warn('Breez SDK: Failed to load PostgreSQL token store:', error.message);
    }
}

// Automatically import and set up the PostgreSQL session manager for Node.js
try {
    const { createPostgresSessionManager, createPostgresSessionManagerWithPool } = require('./postgres-session-manager/index.cjs');
    global.createPostgresSessionManager = createPostgresSessionManager;
    global.createPostgresSessionManagerWithPool = createPostgresSessionManagerWithPool;
} catch (error) {
    if (error.code !== 'MODULE_NOT_FOUND') {
        console.warn('Breez SDK: Failed to load PostgreSQL session manager:', error.message);
    }
}

// Automatically import and set up the MySQL storage for Node.js
try {
    const { createMysqlStorage, createMysqlPool, createMysqlStorageWithPool } = require('./mysql-storage/index.cjs');
    global.createMysqlStorage = createMysqlStorage;
    global.createMysqlPool = createMysqlPool;
    global.createMysqlStorageWithPool = createMysqlStorageWithPool;
} catch (error) {
    if (error.code !== 'MODULE_NOT_FOUND') {
        console.warn('Breez SDK: Failed to load MySQL storage:', error.message);
    }
}

// Automatically import and set up the MySQL tree store for Node.js
try {
    const { createMysqlTreeStore, createMysqlTreeStoreWithPool } = require('./mysql-tree-store/index.cjs');
    global.createMysqlTreeStore = createMysqlTreeStore;
    global.createMysqlTreeStoreWithPool = createMysqlTreeStoreWithPool;
} catch (error) {
    if (error.code !== 'MODULE_NOT_FOUND') {
        console.warn('Breez SDK: Failed to load MySQL tree store:', error.message);
    }
}

// Automatically import and set up the MySQL token store for Node.js
try {
    const { createMysqlTokenStore, createMysqlTokenStoreWithPool } = require('./mysql-token-store/index.cjs');
    global.createMysqlTokenStore = createMysqlTokenStore;
    global.createMysqlTokenStoreWithPool = createMysqlTokenStoreWithPool;
} catch (error) {
    if (error.code !== 'MODULE_NOT_FOUND') {
        console.warn('Breez SDK: Failed to load MySQL token store:', error.message);
    }
}

// Automatically import and set up the MySQL session manager for Node.js
try {
    const { createMysqlSessionManager, createMysqlSessionManagerWithPool } = require('./mysql-session-manager/index.cjs');
    global.createMysqlSessionManager = createMysqlSessionManager;
    global.createMysqlSessionManagerWithPool = createMysqlSessionManagerWithPool;
} catch (error) {
    if (error.code !== 'MODULE_NOT_FOUND') {
        console.warn('Breez SDK: Failed to load MySQL session manager:', error.message);
    }
}

// Export all WASM functions
module.exports = wasmModule;
