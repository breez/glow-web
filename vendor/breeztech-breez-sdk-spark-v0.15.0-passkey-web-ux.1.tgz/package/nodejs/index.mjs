// ESM wrapper for the CJS Node.js entry — re-exports named bindings
// so that `import { connect } from '@breeztech/breez-sdk-spark'` works
// in ESM contexts.
import pkg from './index.js';

export const {
  connect,
  connectWithSigner,
  createMysqlConnectionPool,
  createPostgresConnectionPool,
  defaultConfig,
  defaultExternalSigner,
  defaultMysqlStorageConfig,
  defaultPostgresStorageConfig,
  defaultServerConfig,
  getSparkStatus,
  initLogging,
  newRestChainService,
  newSharedSdkContext,
  task_worker_entry_point,
  BitcoinChainServiceHandle,
  BreezSdk,
  DefaultSigner,
  IntoUnderlyingByteSource,
  IntoUnderlyingSink,
  IntoUnderlyingSource,
  MysqlConnectionPool,
  Passkey,
  PostgresConnectionPool,
  SdkBuilder,
  TokenIssuer,
  WasmSdkContext,
} = pkg;

export default pkg;
