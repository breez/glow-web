/* tslint:disable */
/* eslint-disable */
/**
 * The `ReadableStreamType` enum.
 *
 * *This API requires the following crate features to be activated: `ReadableStreamType`*
 */

type ReadableStreamType = "bytes";

/** Serialized tree node. Key fields used by store implementations: id, status, value. */
interface TreeNode {
    id: string;
    tree_id: string;
    value: number;
    status: string;
    [key: string]: unknown;
}

interface Leaves {
    available: TreeNode[];
    notAvailable: TreeNode[];
    availableMissingFromOperators: TreeNode[];
    reservedForPayment: TreeNode[];
    reservedForSwap: TreeNode[];
}

interface LeavesReservation {
    id: string;
    leaves: TreeNode[];
}

type TargetAmounts =
| { type: 'amountAndFee'; amountSats: number; feeSats: number | null }
| { type: 'exactDenominations'; denominations: number[] };

type ReserveResult =
| { type: 'success'; reservation: LeavesReservation }
| { type: 'insufficientFunds' }
| { type: 'waitForPending'; needed: number; available: number; pending: number };

export interface TreeStore {
    addLeaves: (leaves: TreeNode[]) => Promise<void>;
    getLeaves: () => Promise<Leaves>;
    getAvailableBalance: () => Promise<bigint>;
    setLeaves: (leaves: TreeNode[], missingLeaves: TreeNode[], refreshStartedAtMs: number) => Promise<void>;
    cancelReservation: (id: string, leavesToKeep: TreeNode[]) => Promise<void>;
    finalizeReservation: (id: string, newLeaves: TreeNode[] | null) => Promise<void>;
    tryReserveLeaves: (targetAmounts: TargetAmounts | null, exactOnly: boolean, purpose: string) => Promise<ReserveResult>;
    now: () => Promise<number>;
    updateReservation: (reservationId: string, reservedLeaves: TreeNode[], changeLeaves: TreeNode[]) => Promise<LeavesReservation>;
}


interface WasmTokenMetadata {
    identifier: string;
    issuerPublicKey: string;
    name: string;
    ticker: string;
    decimals: number;
    maxSupply: string;
    isFreezable: boolean;
    creationEntityPublicKey: string | null;
}

interface WasmTokenOutput {
    id: string;
    ownerPublicKey: string;
    revocationCommitment: string;
    withdrawBondSats: number;
    withdrawRelativeBlockLocktime: number;
    tokenPublicKey: string | null;
    tokenIdentifier: string;
    tokenAmount: string;
}

interface WasmTokenOutputWithPrevOut {
    output: WasmTokenOutput;
    prevTxHash: string;
    prevTxVout: number;
}

interface WasmTokenOutputs {
    metadata: WasmTokenMetadata;
    outputs: WasmTokenOutputWithPrevOut[];
}

interface WasmTokenOutputsPerStatus {
    metadata: WasmTokenMetadata;
    available: WasmTokenOutputWithPrevOut[];
    reservedForPayment: WasmTokenOutputWithPrevOut[];
    reservedForSwap: WasmTokenOutputWithPrevOut[];
}

interface WasmTokenOutputsReservation {
    id: string;
    tokenOutputs: WasmTokenOutputs;
}

interface WasmTokenBalance {
    metadata: WasmTokenMetadata;
    balance: string;
}

type WasmGetTokenOutputsFilter =
| { type: 'identifier'; identifier: string }
| { type: 'issuerPublicKey'; issuerPublicKey: string };

type WasmReservationTarget =
| { type: 'minTotalValue'; value: string }
| { type: 'maxOutputCount'; value: number };

export interface TokenStore {
    setTokensOutputs: (tokenOutputs: WasmTokenOutputs[], refreshStartedAtMs: number) => Promise<void>;
    listTokensOutputs: () => Promise<WasmTokenOutputsPerStatus[]>;
    getTokenBalances: () => Promise<WasmTokenBalance[]>;
    getTokenOutputs: (filter: WasmGetTokenOutputsFilter) => Promise<WasmTokenOutputsPerStatus>;
    updateTokenOutputs: (outputsToRemove: [string, number][], outputsToAdd: WasmTokenOutputs | null) => Promise<void>;
    reserveTokenOutputs: (
    tokenIdentifier: string,
    target: WasmReservationTarget,
    purpose: string,
    preferredOutputs: WasmTokenOutputWithPrevOut[] | null,
    selectionStrategy: string | null
    ) => Promise<WasmTokenOutputsReservation>;
    cancelReservation: (id: string) => Promise<void>;
    finalizeReservation: (id: string) => Promise<void>;
    now: () => Promise<number>;
}

/**
 * A passkey credential from `register` or `signIn`. `credentialId` is
 * always set. The attestation fields (`userId`, `aaguid`,
 * `backupEligible`) are populated on registration and null on sign-in
 * (an assertion carries no attestation). AAGUID is unverified: a
 * display hint only, never a trust signal.
 */
export interface PasskeyCredential {
    credentialId: Uint8Array;
    userId?: Uint8Array;
    aaguid?: Uint8Array;
    backupEligible?: boolean;
}

/**
 * A wallet derived from a passkey.
 */
export interface Wallet {
    /**
     * The derived seed.
     */
    seed: Seed;
    /**
     * The label used for derivation.
     */
    label: string;
}

/**
 * Configuration for MySQL storage connection pool. Targets MySQL 8.0+.
 */
export interface MysqlStorageConfig {
    /**
     * MySQL connection URL (e.g. `mysql://user:pass@host:3306/dbname`).
     */
    connectionString: string;
    /**
     * Maximum number of connections in the pool.
     */
    maxPoolSize: number;
    /**
     * Timeout in seconds for establishing a new connection (0 = no timeout).
     */
    createTimeoutSecs: number;
    /**
     * Timeout in seconds before recycling an idle connection.
     */
    recycleTimeoutSecs: number;
    /**
     * Whether the SDK should run schema migrations on startup. Set to
     * `false` when the embedding service owns and migrates the database
     * schema. Defaults to `true`.
     */
    runMigration?: boolean;
    /**
     * Whether migrations should create database-enforced foreign keys.
     *
     * Use `Disabled` for environments that manage relationships in
     * application code and require schema changes without foreign-key
     * constraints.
     */
    foreignKeyMode?: MysqlForeignKeyMode;
}

/**
 * Configuration for PostgreSQL storage connection pool.
 */
export interface PostgresStorageConfig {
    /**
     * PostgreSQL connection string (URI format).
     */
    connectionString: string;
    /**
     * Maximum number of connections in the pool.
     */
    maxPoolSize: number;
    /**
     * Timeout in seconds for establishing a new connection (0 = no timeout).
     */
    createTimeoutSecs: number;
    /**
     * Timeout in seconds before recycling an idle connection.
     */
    recycleTimeoutSecs: number;
    /**
     * Whether the SDK should run schema migrations on startup. Set to
     * `false` when the embedding service owns and migrates the database
     * schema. Defaults to `true`.
     */
    runMigration?: boolean;
}

/**
 * Configuration for `PasskeyClient`. `rpId` / `rpName` configure the
 * built-in provider on the zero-config path (ignored when you inject
 * your own provider, which owns its RP).
 */
export interface PasskeyConfig {
    /**
     * Wallet label for `register` / `signIn` when no label is given.
     * Unset falls back to the internal default `\"Default\"`.
     */
    defaultLabel?: string;
    /**
     * Relying Party ID for the built-in provider. Unset uses the Breez
     * shared RP.
     */
    rpId?: string;
    /**
     * Relying Party name for the built-in provider. Unset uses the SDK
     * default (`\"Breez\"`).
     */
    rpName?: string;
}

/**
 * Controls whether MySQL migrations create database-enforced foreign keys.
 */
export type MysqlForeignKeyMode = "Enforced" | "Disabled";

/**
 * Interface for PRF (Pseudo-Random Function) operations backing seedless
 * wallet restore.
 *
 * Implemented by the built-in `PasskeyProvider` (browser passkey via the
 * WebAuthn PRF extension); also implementable directly for custom
 * deterministic sources (YubiKey HMAC challenge, FIDO2 hmac-secret, on-disk
 * key material, hardware HSMs).
 */
export interface PrfProvider {
    /**
     * Derive 32-byte PRF outputs for one or more salts, in input order.
     * Implementations with bulk capability (WebAuthn dual-salt via
     * `prf.eval.first` + `prf.eval.second`) pack two salts per ceremony
     * where supported; others loop the single-salt path. `options` carries
     * per-call ceremony shapers that built-in providers forward to the OS
     * call and custom providers may ignore.
     *
     * @param salts - Salt strings in caller order
     * @param options - Optional per-call overrides
     * @returns Promise of the 32-byte outputs in input order plus the
     *   credential ID observed in the same assertion (`null` when the
     *   provider surfaces none, e.g. sources without an OS picker)
     */
    deriveSeeds(salts: string[], options?: DeriveSeedOptions): Promise<DeriveSeedsResult>;

    /**
     * Optional explicit registration. Platform passkey providers (browser
     * WebAuthn, iOS / Android) implement this to drive the OS create
     * ceremony and return credential metadata (`credentialId`, `userId`,
     * optional `aaguid` / `backupEligible`) callers need for
     * `excludeCredentials` bookkeeping and server-side correlation. Custom
     * providers without a creation step can omit it.
     *
     * `excludeCredentials` lists already-registered IDs; a match raises
     * `PasskeyAlreadyExistsError`.
     *
     * @throws `PasskeyAlreadyExistsError` when an entry in
     *   `excludeCredentials` matches a credential already on the device.
     */
    createPasskey?(excludeCredentials: Uint8Array[]): Promise<PasskeyCredential>;

    /**
     * Whether this provider can produce PRF outputs on the current
     * device. Hosts gate UX on the result.
     */
    isSupported(): Promise<boolean>;
}

/**
 * Per-call options passed as the second argument of
 * {@link PrfProvider.deriveSeeds}.
 */
export interface DeriveSeedOptions {
    /**
     * Credential IDs the assertion is restricted to, for reauthenticating
     * a known user without an account picker. Empty or unset lets the
     * provider's default apply.
     */
    allowCredentials?: Uint8Array[];
    /**
     * Fast-fail when no local credential is available. On the web this maps
     * to WebAuthn `mediation: 'immediate'`: `true` opts in where the browser
     * advertises support, `false` uses the standard picker. Unset uses the
     * provider default.
     */
    preferImmediatelyAvailableCredentials?: boolean;
}

/**
 * Returned by {@link PrfProvider.deriveSeeds}: the derived 32-byte outputs
 * in input order plus the credential ID observed in the same assertion.
 * `credentialId` is `null` when the provider does not surface one (custom
 * deterministic sources without an OS picker).
 */
export interface DeriveSeedsResult {
    seeds: Uint8Array[];
    credentialId?: Uint8Array | null;
}

/**
 * One-shot capability + configuration probe returned by
 * `PasskeyClient.checkAvailability`. Collapses `isSupported` +
 * `checkDomainAssociation` into one tagged value hosts branch on.
 */
export type PasskeyAvailability = { type: "available" } | { type: "prfUnsupported" } | { type: "notAssociated"; source: string; reason: string } | { type: "skipped"; reason: string };

/**
 * Request shape for `PasskeyClient.register`.
 */
export interface RegisterRequest {
    label?: string;
    excludeCredentials?: Uint8Array[];
}

/**
 * Request shape for `PasskeyClient.signIn`.
 */
export interface SignInRequest {
    label?: string;
    allowCredentials?: Uint8Array[];
    preferImmediatelyAvailableCredentials?: boolean;
}

/**
 * Response shape for `PasskeyClient.register`.
 */
export interface RegisterResponse {
    wallet: Wallet;
    credential?: PasskeyCredential;
}

/**
 * Response shape for `PasskeyClient.signIn`.
 */
export interface SignInResponse {
    wallet: Wallet;
    labels: string[];
    credential?: PasskeyCredential;
}

/**
 * Settings for `newSharedSdkContext`. `network` is required; all other
 * fields are optional.
 */
export interface WasmSdkContextConfig {
    /**
     * Network the shared resources target. Used to gate the partner JWT
     * header provider — only constructed on Mainnet.
     */
    network: Network;
    /**
     * Breez API key. When set together with `network == Mainnet`, the
     * context constructs a shared partner JWT header provider that all
     * SDKs built from this context will attach to their SO requests.
     */
    apiKey?: string;
    /**
     * Number of gRPC connections per Spark operator. `None` (or `Some(1)`)
     * keeps a single connection per operator (right for most deployments);
     * `Some(n)` opens `n` channels per operator and balances requests.
     */
    connectionsPerOperator?: number;
    /**
     * PostgreSQL backend configuration. When set, SDKs constructed with
     * this context store their data in PostgreSQL via the shared pool.
     */
    postgresConfig?: PostgresStorageConfig;
    /**
     * MySQL backend configuration. When set, SDKs constructed with this
     * context store their data in MySQL via the shared pool.
     */
    mysqlConfig?: MysqlStorageConfig;
}

export interface AddContactRequest {
    name: string;
    paymentIdentifier: string;
}

export interface AesSuccessActionData {
    description: string;
    ciphertext: string;
    iv: string;
}

export interface AesSuccessActionDataDecrypted {
    description: string;
    plaintext: string;
}

export interface Bip21Details {
    amountSat?: number;
    assetId?: string;
    uri: string;
    extras: Bip21Extra[];
    label?: string;
    message?: string;
    paymentMethods: InputType[];
}

export interface Bip21Extra {
    key: string;
    value: string;
}

export interface BitcoinAddressDetails {
    address: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface BitcoinChainService {
    getAddressUtxos(address: string): Promise<Utxo[]>;
    getTransactionStatus(txid: string): Promise<TxStatus>;
    getTransactionHex(txid: string): Promise<string>;
    broadcastTransaction(tx: string): Promise<void>;
    recommendedFees(): Promise<RecommendedFees>;
}

export interface Bolt11Invoice {
    bolt11: string;
    source: PaymentRequestSource;
}

export interface Bolt11InvoiceDetails {
    amountMsat?: number;
    description?: string;
    descriptionHash?: string;
    expiry: number;
    invoice: Bolt11Invoice;
    minFinalCltvExpiryDelta: number;
    network: BitcoinNetwork;
    payeePubkey: string;
    paymentHash: string;
    paymentSecret: string;
    routingHints: Bolt11RouteHint[];
    timestamp: number;
}

export interface Bolt11RouteHint {
    hops: Bolt11RouteHintHop[];
}

export interface Bolt11RouteHintHop {
    srcNodeId: string;
    shortChannelId: string;
    feesBaseMsat: number;
    feesProportionalMillionths: number;
    cltvExpiryDelta: number;
    htlcMinimumMsat?: number;
    htlcMaximumMsat?: number;
}

export interface Bolt12Invoice {
    invoice: string;
    source: PaymentRequestSource;
}

export interface Bolt12InvoiceDetails {
    amountMsat: number;
    invoice: Bolt12Invoice;
}

export interface Bolt12InvoiceRequestDetails {}

export interface Bolt12Offer {
    offer: string;
    source: PaymentRequestSource;
}

export interface Bolt12OfferBlindedPath {
    blindedHops: string[];
}

export interface Bolt12OfferDetails {
    absoluteExpiry?: number;
    chains: string[];
    description?: string;
    issuer?: string;
    minAmount?: Amount;
    offer: Bolt12Offer;
    paths: Bolt12OfferBlindedPath[];
    signingPubkey?: string;
}

export interface BurnIssuerTokenRequest {
    amount: bigint;
}

export interface BuyBitcoinResponse {
    url: string;
}

export interface CheckLightningAddressRequest {
    username: string;
}

export interface CheckMessageRequest {
    message: string;
    pubkey: string;
    signature: string;
}

export interface CheckMessageResponse {
    isValid: boolean;
}

export interface ClaimDepositRequest {
    txid: string;
    vout: number;
    maxFee?: MaxFee;
}

export interface ClaimDepositResponse {
    payment: Payment;
}

export interface ClaimHtlcPaymentRequest {
    preimage: string;
}

export interface ClaimHtlcPaymentResponse {
    payment: Payment;
}

export interface Config {
    apiKey?: string;
    network: Network;
    syncIntervalSecs: number;
    maxDepositClaimFee?: MaxFee;
    lnurlDomain?: string;
    preferSparkOverLightning: boolean;
    externalInputParsers?: ExternalInputParser[];
    useDefaultExternalInputParsers: boolean;
    realTimeSyncServerUrl?: string;
    privateEnabledDefault: boolean;
    leafOptimizationConfig: LeafOptimizationConfig;
    tokenOptimizationConfig: TokenOptimizationConfig;
    stableBalanceConfig?: StableBalanceConfig;
    /**
     * Maximum number of concurrent transfer claims.
     *
     * Controls how many pending Spark transfers can be claimed in parallel.
     * Default is 4. Increase for server environments with high incoming
     * payment volume to improve throughput.
     */
    maxConcurrentClaims: number;
    sparkConfig?: SparkConfig;
    backgroundTasksEnabled: boolean;
}

export interface ConnectRequest {
    config: Config;
    seed: Seed;
    storageDir: string;
}

export interface Contact {
    id: string;
    name: string;
    paymentIdentifier: string;
    createdAt: number;
    updatedAt: number;
}

export interface ConversionDetails {
    status: ConversionStatus;
    from?: ConversionStep;
    to?: ConversionStep;
}

export interface ConversionEstimate {
    options: ConversionOptions;
    amountIn: bigint;
    amountOut: bigint;
    fee: bigint;
    amountAdjustment?: AmountAdjustmentReason;
}

export interface ConversionInfo {
    poolId: string;
    conversionId: string;
    status: ConversionStatus;
    fee?: string;
    purpose?: ConversionPurpose;
    amountAdjustment?: AmountAdjustmentReason;
}

export interface ConversionOptions {
    conversionType: ConversionType;
    maxSlippageBps?: number;
    completionTimeoutSecs?: number;
}

export interface ConversionStep {
    paymentId: string;
    amount: bigint;
    fee: bigint;
    method: PaymentMethod;
    tokenMetadata?: TokenMetadata;
    amountAdjustment?: AmountAdjustmentReason;
}

export interface CreateIssuerTokenRequest {
    name: string;
    ticker: string;
    decimals: number;
    isFreezable: boolean;
    maxSupply: bigint;
}

export interface Credentials {
    username: string;
    password: string;
}

export interface CurrencyInfo {
    name: string;
    fractionSize: number;
    spacing?: number;
    symbol?: Symbol;
    uniqSymbol?: Symbol;
    localizedName: LocalizedName[];
    localeOverrides: LocaleOverrides[];
}

export interface DepositInfo {
    txid: string;
    vout: number;
    amountSats: number;
    isMature: boolean;
    refundTx?: string;
    refundTxId?: string;
    claimError?: DepositClaimError;
}

export interface EcdsaSignatureBytes {
    bytes: number[];
}

export interface EventListener {
    onEvent: (e: SdkEvent) => void;
}

export interface ExternalAggregateFrostRequest {
    message: number[];
    statechainSignatures: IdentifierSignaturePair[];
    statechainPublicKeys: IdentifierPublicKeyPair[];
    verifyingKey: number[];
    statechainCommitments: IdentifierCommitmentPair[];
    selfCommitment: ExternalSigningCommitments;
    publicKey: number[];
    selfSignature: ExternalFrostSignatureShare;
    adaptorPublicKey?: number[];
}

export interface ExternalEncryptedSecret {
    ciphertext: number[];
}

export interface ExternalFrostCommitments {
    hidingCommitment: number[];
    bindingCommitment: number[];
    noncesCiphertext: number[];
}

export interface ExternalFrostSignature {
    bytes: number[];
}

export interface ExternalFrostSignatureShare {
    bytes: number[];
}

export interface ExternalIdentifier {
    bytes: number[];
}

export interface ExternalInputParser {
    providerId: string;
    inputRegex: string;
    parserUrl: string;
}

export interface ExternalScalar {
    bytes: number[];
}

export interface ExternalSecretShare {
    threshold: number;
    index: ExternalScalar;
    share: ExternalScalar;
}

export interface ExternalSignFrostRequest {
    message: number[];
    publicKey: number[];
    secret: ExternalSecretSource;
    verifyingKey: number[];
    selfNonceCommitment: ExternalFrostCommitments;
    statechainCommitments: IdentifierCommitmentPair[];
    adaptorPublicKey?: number[];
}

export interface ExternalSigner {
    identityPublicKey(): PublicKeyBytes;
    derivePublicKey(path: string): Promise<PublicKeyBytes>;
    signEcdsa(message: MessageBytes, path: string): Promise<EcdsaSignatureBytes>;
    signEcdsaRecoverable(message: MessageBytes, path: string): Promise<RecoverableEcdsaSignatureBytes>;
    encryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    decryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    signHashSchnorr(hash: Uint8Array, path: string): Promise<SchnorrSignatureBytes>;
    generateRandomSigningCommitment(): Promise<ExternalFrostCommitments>;
    getPublicKeyForNode(id: ExternalTreeNodeId): Promise<PublicKeyBytes>;
    generateRandomSecret(): Promise<ExternalEncryptedSecret>;
    staticDepositSecretEncrypted(index: number): Promise<ExternalSecretSource>;
    staticDepositSecret(index: number): Promise<SecretBytes>;
    staticDepositSigningKey(index: number): Promise<PublicKeyBytes>;
    subtractSecrets(signingKey: ExternalSecretSource, newSigningKey: ExternalSecretSource): Promise<ExternalSecretSource>;
    splitSecretWithProofs(secret: ExternalSecretToSplit, threshold: number, numShares: number): Promise<ExternalVerifiableSecretShare[]>;
    encryptPrivateKeyForReceiver(privateKey: ExternalEncryptedSecret, receiverPublicKey: PublicKeyBytes): Promise<Uint8Array>;
    publicKeyFromSecret(privateKey: ExternalSecretSource): Promise<PublicKeyBytes>;
    signFrost(request: ExternalSignFrostRequest): Promise<ExternalFrostSignatureShare>;
    aggregateFrost(request: ExternalAggregateFrostRequest): Promise<ExternalFrostSignature>;
    hmacSha256(message: Uint8Array, path: string): Promise<HashedMessageBytes>;
}

export interface ExternalSigningCommitments {
    hiding: number[];
    binding: number[];
}

export interface ExternalTreeNodeId {
    id: string;
}

export interface ExternalVerifiableSecretShare {
    secretShare: ExternalSecretShare;
    proofs: number[][];
}

export interface FetchConversionLimitsRequest {
    conversionType: ConversionType;
    tokenIdentifier?: string;
}

export interface FetchConversionLimitsResponse {
    minFromAmount?: bigint;
    minToAmount?: bigint;
}

export interface FiatCurrency {
    id: string;
    info: CurrencyInfo;
}

export interface FiatService {
    fetchFiatCurrencies(): Promise<FiatCurrency[]>;
    fetchFiatRates(): Promise<Rate[]>;
}

export interface FreezeIssuerTokenRequest {
    address: string;
}

export interface FreezeIssuerTokenResponse {
    impactedOutputIds: string[];
    impactedTokenAmount: bigint;
}

export interface GetInfoRequest {
    ensureSynced?: boolean;
}

export interface GetInfoResponse {
    identityPubkey: string;
    balanceSats: number;
    tokenBalances: Map<string, TokenBalance>;
}

export interface GetPaymentRequest {
    paymentId: string;
}

export interface GetPaymentResponse {
    payment: Payment;
}

export interface GetTokensMetadataRequest {
    tokenIdentifiers: string[];
}

export interface GetTokensMetadataResponse {
    tokensMetadata: TokenMetadata[];
}

export interface HashedMessageBytes {
    bytes: number[];
}

export interface IdentifierCommitmentPair {
    identifier: ExternalIdentifier;
    commitment: ExternalSigningCommitments;
}

export interface IdentifierPublicKeyPair {
    identifier: ExternalIdentifier;
    publicKey: number[];
}

export interface IdentifierSignaturePair {
    identifier: ExternalIdentifier;
    signature: ExternalFrostSignatureShare;
}

export interface IncomingChange {
    newState: Record;
    oldState?: Record;
}

export interface KeySetConfig {
    keySetType: KeySetType;
    useAddressIndex: boolean;
    accountNumber?: number;
}

export interface LeafOptimizationConfig {
    autoEnabled: boolean;
    multiplicity: number;
}

export interface LightningAddressDetails {
    address: string;
    payRequest: LnurlPayRequestDetails;
}

export interface LightningAddressInfo {
    description: string;
    lightningAddress: string;
    lnurl: LnurlInfo;
    username: string;
}

export interface ListContactsRequest {
    offset?: number;
    limit?: number;
}

export interface ListFiatCurrenciesResponse {
    currencies: FiatCurrency[];
}

export interface ListFiatRatesResponse {
    rates: Rate[];
}

export interface ListPaymentsRequest {
    typeFilter?: PaymentType[];
    statusFilter?: PaymentStatus[];
    assetFilter?: AssetFilter;
    paymentDetailsFilter?: PaymentDetailsFilter[];
    fromTimestamp?: number;
    toTimestamp?: number;
    offset?: number;
    limit?: number;
    sortAscending?: boolean;
}

export interface ListPaymentsResponse {
    payments: Payment[];
}

export interface ListUnclaimedDepositsRequest {}

export interface ListUnclaimedDepositsResponse {
    deposits: DepositInfo[];
}

export interface LnurlAuthRequestDetails {
    k1: string;
    action?: string;
    domain: string;
    url: string;
}

export interface LnurlErrorDetails {
    reason: string;
}

export interface LnurlInfo {
    url: string;
    bech32: string;
}

export interface LnurlPayInfo {
    lnAddress?: string;
    comment?: string;
    domain?: string;
    metadata?: string;
    processedSuccessAction?: SuccessActionProcessed;
    rawSuccessAction?: SuccessAction;
}

export interface LnurlPayRequest {
    prepareResponse: PrepareLnurlPayResponse;
    idempotencyKey?: string;
}

export interface LnurlPayRequestDetails {
    callback: string;
    minSendable: number;
    maxSendable: number;
    metadataStr: string;
    commentAllowed: number;
    domain: string;
    url: string;
    address?: string;
    allowsNostr?: boolean;
    nostrPubkey?: string;
}

export interface LnurlPayResponse {
    payment: Payment;
    successAction?: SuccessActionProcessed;
}

export interface LnurlReceiveMetadata {
    nostrZapRequest?: string;
    nostrZapReceipt?: string;
    senderComment?: string;
}

export interface LnurlWithdrawInfo {
    withdrawUrl: string;
}

export interface LnurlWithdrawRequest {
    amountSats: number;
    withdrawRequest: LnurlWithdrawRequestDetails;
    completionTimeoutSecs?: number;
}

export interface LnurlWithdrawRequestDetails {
    callback: string;
    k1: string;
    defaultDescription: string;
    minWithdrawable: number;
    maxWithdrawable: number;
}

export interface LnurlWithdrawResponse {
    paymentRequest: string;
    payment?: Payment;
}

export interface LocaleOverrides {
    locale: string;
    spacing?: number;
    symbol: Symbol;
}

export interface LocalizedName {
    locale: string;
    name: string;
}

export interface LogEntry {
    line: string;
    level: string;
}

export interface Logger {
    log: (l: LogEntry) => void;
}

export interface MessageBytes {
    bytes: number[];
}

export interface MessageSuccessActionData {
    message: string;
}

export interface MintIssuerTokenRequest {
    amount: bigint;
}

export interface OptimizeLeavesRequest {
    mode: OptimizationMode;
}

export interface OptimizeLeavesResponse {
    outcome: OptimizationOutcome;
}

export interface OutgoingChange {
    change: RecordChange;
    parent?: Record;
}

export interface Payment {
    id: string;
    paymentType: PaymentType;
    status: PaymentStatus;
    amount: bigint;
    fees: bigint;
    timestamp: number;
    method: PaymentMethod;
    details?: PaymentDetails;
    conversionDetails?: ConversionDetails;
}

export interface PaymentIdUpdate {
    provisionalPaymentId: string;
    finalPaymentId: string;
}

export interface PaymentMetadata {
    parentPaymentId?: string;
    lnurlPayInfo?: LnurlPayInfo;
    lnurlWithdrawInfo?: LnurlWithdrawInfo;
    lnurlDescription?: string;
    conversionInfo?: ConversionInfo;
    conversionStatus?: ConversionStatus;
}

export interface PaymentObserver {
    beforeSend: (payments: ProvisionalPayment[]) => Promise<void>;
    afterSend: (updates: PaymentIdUpdate[]) => Promise<void>;
}

export interface PaymentRequestSource {
    bip21Uri?: string;
    bip353Address?: string;
}

export interface PrepareLnurlPayRequest {
    amount: bigint;
    comment?: string;
    payRequest: LnurlPayRequestDetails;
    validateSuccessActionUrl?: boolean;
    tokenIdentifier?: string;
    conversionOptions?: ConversionOptions;
    feePolicy?: FeePolicy;
}

export interface PrepareLnurlPayResponse {
    amountSats: number;
    comment?: string;
    payRequest: LnurlPayRequestDetails;
    feeSats: number;
    invoiceDetails: Bolt11InvoiceDetails;
    successAction?: SuccessAction;
    conversionEstimate?: ConversionEstimate;
    feePolicy: FeePolicy;
}

export interface PrepareSendPaymentRequest {
    paymentRequest: string;
    amount?: bigint;
    tokenIdentifier?: string;
    conversionOptions?: ConversionOptions;
    feePolicy?: FeePolicy;
}

export interface PrepareSendPaymentResponse {
    paymentMethod: SendPaymentMethod;
    amount: bigint;
    tokenIdentifier?: string;
    conversionEstimate?: ConversionEstimate;
    feePolicy: FeePolicy;
}

export interface ProvisionalPayment {
    paymentId: string;
    amount: bigint;
    details: ProvisionalPaymentDetails;
}

export interface PublicKeyBytes {
    bytes: number[];
}

export interface Rate {
    coin: string;
    value: number;
}

export interface ReceivePaymentRequest {
    paymentMethod: ReceivePaymentMethod;
}

export interface ReceivePaymentResponse {
    paymentRequest: string;
    fee: bigint;
}

export interface RecommendedFees {
    fastestFee: number;
    halfHourFee: number;
    hourFee: number;
    economyFee: number;
    minimumFee: number;
}

export interface Record {
    id: RecordId;
    revision: number;
    schemaVersion: string;
    data: Map<string, string>;
}

export interface RecordChange {
    id: RecordId;
    schemaVersion: string;
    updatedFields: Map<string, string>;
    localRevision: number;
}

export interface RecordId {
    type: string;
    dataId: string;
}

export interface RecoverableEcdsaSignatureBytes {
    bytes: number[];
}

export interface RefundDepositRequest {
    txid: string;
    vout: number;
    destinationAddress: string;
    fee: Fee;
}

export interface RefundDepositResponse {
    txId: string;
    txHex: string;
}

export interface RegisterLightningAddressRequest {
    username: string;
    description?: string;
}

export interface RegisterWebhookRequest {
    url: string;
    secret: string;
    eventTypes: WebhookEventType[];
}

export interface RegisterWebhookResponse {
    webhookId: string;
}

export interface RestClient {
    getRequest(url: string, headers?: Record<string, string>): Promise<RestResponse>;
    postRequest(url: string, headers?: Record<string, string>, body?: string): Promise<RestResponse>;
    deleteRequest(url: string, headers?: Record<string, string>, body?: string): Promise<RestResponse>;
}

export interface RestResponse {
    status: number;
    body: string;
}

export interface SchnorrSignatureBytes {
    bytes: number[];
}

export interface SecretBytes {
    bytes: number[];
}

export interface SendOnchainFeeQuote {
    id: string;
    expiresAt: number;
    speedFast: SendOnchainSpeedFeeQuote;
    speedMedium: SendOnchainSpeedFeeQuote;
    speedSlow: SendOnchainSpeedFeeQuote;
}

export interface SendOnchainSpeedFeeQuote {
    userFeeSat: number;
    l1BroadcastFeeSat: number;
}

export interface SendPaymentRequest {
    prepareResponse: PrepareSendPaymentResponse;
    options?: SendPaymentOptions;
    idempotencyKey?: string;
}

export interface SendPaymentResponse {
    payment: Payment;
}

export interface Session {
    token: string;
    expiration: number;
}

export interface SessionStore {
    getSession: (serviceIdentityKey: string) => Promise<Session>;
    setSession: (serviceIdentityKey: string, session: Session) => Promise<void>;
}

export interface SetLnurlMetadataItem {
    paymentHash: string;
    senderComment?: string;
    nostrZapRequest?: string;
    nostrZapReceipt?: string;
}

export interface SignMessageRequest {
    message: string;
    compact: boolean;
}

export interface SignMessageResponse {
    pubkey: string;
    signature: string;
}

export interface SilentPaymentAddressDetails {
    address: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface SparkAddressDetails {
    address: string;
    identityPublicKey: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface SparkConfig {
    coordinatorIdentifier: string;
    threshold: number;
    signingOperators: SparkSigningOperator[];
    sspConfig: SparkSspConfig;
    expectedWithdrawBondSats: number;
    expectedWithdrawRelativeBlockLocktime: number;
}

export interface SparkHtlcDetails {
    paymentHash: string;
    preimage?: string;
    expiryTime: number;
    status: SparkHtlcStatus;
}

export interface SparkHtlcOptions {
    paymentHash: string;
    expiryDurationSecs: number;
}

export interface SparkInvoiceDetails {
    invoice: string;
    identityPublicKey: string;
    network: BitcoinNetwork;
    amount?: string;
    tokenIdentifier?: string;
    expiryTime?: number;
    description?: string;
    senderPublicKey?: string;
}

export interface SparkInvoicePaymentDetails {
    description?: string;
    invoice: string;
}

export interface SparkSigningOperator {
    id: number;
    identifier: string;
    address: string;
    identityPublicKey: string;
}

export interface SparkSspConfig {
    baseUrl: string;
    identityPublicKey: string;
    schemaEndpoint?: string;
}

export interface SparkStatus {
    status: ServiceStatus;
    lastUpdated: number;
}

export interface StableBalanceConfig {
    tokens: StableBalanceToken[];
    defaultActiveLabel?: string;
    thresholdSats?: number;
    maxSlippageBps?: number;
}

export interface StableBalanceToken {
    label: string;
    tokenIdentifier: string;
}

export interface Storage {
    getCachedItem: (key: string) => Promise<string | null>;
    setCachedItem: (key: string, value: string) => Promise<void>;
    deleteCachedItem: (key: string) => Promise<void>;
    listPayments: (request: StorageListPaymentsRequest) => Promise<Payment[]>;
    /**
     * Insert or update a payment, applying a terminal-status guard.
     *
     * Returns `true` when the caller should emit a payment event (the row was
     * newly inserted, or its status transitioned). Returns `false` for
     * redundant same-status updates and for rejected updates that would
     * replace an already-terminal status.
     */
    applyPaymentUpdate: (payment: Payment) => Promise<boolean>;
    insertPaymentMetadata: (paymentId: string, metadata: PaymentMetadata) => Promise<void>;
    getPaymentById: (id: string) => Promise<Payment>;
    getPaymentByInvoice: (invoice: string) => Promise<Payment>;
    addDeposit: (txid: string, vout: number, amount_sats: number, isMature: boolean) => Promise<void>;
    deleteDeposit: (txid: string, vout: number) => Promise<void>;
    listDeposits: () => Promise<DepositInfo[]>;
    updateDeposit: (txid: string, vout: number, payload: UpdateDepositPayload) => Promise<void>;
    setLnurlMetadata: (metadata: SetLnurlMetadataItem[]) => Promise<void>;
    getPaymentsByParentIds: (parentPaymentIds: string[]) => Promise<{ [parentId: string]: RelatedPayment[] }>;
    listContacts: (request: ListContactsRequest) => Promise<Contact[]>;
    getContact: (id: string) => Promise<Contact>;
    insertContact: (contact: Contact) => Promise<void>;
    deleteContact: (id: string) => Promise<void>;
    syncAddOutgoingChange: (record: UnversionedRecordChange) => Promise<number>;
    syncCompleteOutgoingSync: (record: Record) => Promise<void>;
    syncGetPendingOutgoingChanges: (limit: number) => Promise<OutgoingChange[]>;
    syncGetLastRevision: () => Promise<number>;
    syncInsertIncomingRecords: (records: Record[]) => Promise<void>;
    syncDeleteIncomingRecord: (record: Record) => Promise<void>;
    syncGetIncomingRecords: (limit: number) => Promise<IncomingChange[]>;
    syncGetLatestOutgoingChange: () => Promise<OutgoingChange | null>;
    syncUpdateRecordFromIncoming: (record: Record) => Promise<void>;
}

export interface StorageListPaymentsRequest {
    typeFilter?: PaymentType[];
    statusFilter?: PaymentStatus[];
    assetFilter?: AssetFilter;
    paymentDetailsFilter?: StoragePaymentDetailsFilter[];
    fromTimestamp?: number;
    toTimestamp?: number;
    offset?: number;
    limit?: number;
    sortAscending?: boolean;
}

export interface Symbol {
    grapheme?: string;
    template?: string;
    rtl?: boolean;
    position?: number;
}

export interface SyncWalletRequest {}

export interface SyncWalletResponse {}

export interface TokenBalance {
    balance: bigint;
    tokenMetadata: TokenMetadata;
}

export interface TokenMetadata {
    identifier: string;
    issuerPublicKey: string;
    name: string;
    ticker: string;
    decimals: number;
    maxSupply: string;
    isFreezable: boolean;
}

export interface TokenOptimizationConfig {
    autoEnabled: boolean;
    targetOutputCount: number;
    minOutputsThreshold: number;
}

export interface TxStatus {
    confirmed: boolean;
    blockHeight?: number;
    blockTime?: number;
}

export interface UnfreezeIssuerTokenRequest {
    address: string;
}

export interface UnfreezeIssuerTokenResponse {
    impactedOutputIds: string[];
    impactedTokenAmount: bigint;
}

export interface UnregisterWebhookRequest {
    webhookId: string;
}

export interface UnversionedRecordChange {
    id: RecordId;
    schemaVersion: string;
    updatedFields: Map<string, string>;
}

export interface UpdateContactRequest {
    id: string;
    name: string;
    paymentIdentifier: string;
}

export interface UpdateUserSettingsRequest {
    sparkPrivateModeEnabled?: boolean;
    stableBalanceActiveLabel?: StableBalanceActiveLabel;
}

export interface UrlSuccessActionData {
    description: string;
    url: string;
    matchesCallbackDomain: boolean;
}

export interface UserSettings {
    sparkPrivateModeEnabled: boolean;
    stableBalanceActiveLabel?: string;
}

export interface Utxo {
    txid: string;
    vout: number;
    value: number;
    status: TxStatus;
}

export interface Webhook {
    id: string;
    url: string;
    eventTypes: WebhookEventType[];
}

export type AesSuccessActionDataResult = { type: "decrypted"; data: AesSuccessActionDataDecrypted } | { type: "errorStatus"; reason: string };

export type Amount = { type: "bitcoin"; amountMsat: number } | { type: "currency"; iso4217Code: string; fractionalAmount: number };

export type AmountAdjustmentReason = "flooredToMinLimit" | "increasedToAvoidDust";

export type AssetFilter = { type: "bitcoin" } | { type: "token"; tokenIdentifier?: string };

export type AutoOptimizationEvent = { type: "started"; totalRounds: number } | { type: "roundCompleted"; currentRound: number; totalRounds: number } | { type: "completed" } | { type: "cancelled" } | { type: "failed"; error: string } | { type: "skipped" };

export type BitcoinNetwork = "bitcoin" | "testnet3" | "testnet4" | "signet" | "regtest";

export type BuyBitcoinRequest = { type: "moonpay"; lockedAmountSat?: number; redirectUrl?: string } | { type: "cashApp"; amountSats: number };

export type ChainApiType = "esplora" | "mempoolSpace";

export type ConversionPurpose = { type: "ongoingPayment"; paymentRequest: string } | { type: "selfTransfer" } | { type: "autoConversion" };

export type ConversionStatus = "pending" | "completed" | "failed" | "refundNeeded" | "refunded";

export type ConversionType = { type: "fromBitcoin" } | { type: "toBitcoin"; fromTokenIdentifier: string };

export type DepositClaimError = { type: "maxDepositClaimFeeExceeded"; tx: string; vout: number; maxFee?: Fee; requiredFeeSats: number; requiredFeeRateSatPerVbyte: number } | { type: "missingUtxo"; tx: string; vout: number } | { type: "generic"; message: string };

export type ExternalSecretSource = { type: "derived"; nodeId: ExternalTreeNodeId } | { type: "encrypted"; key: ExternalEncryptedSecret };

export type ExternalSecretToSplit = { type: "secretSource"; source: ExternalSecretSource } | { type: "preimage"; data: number[] };

export type Fee = { type: "fixed"; amount: number } | { type: "rate"; satPerVbyte: number };

export type FeePolicy = "feesExcluded" | "feesIncluded";

export type InputType = ({ type: "bitcoinAddress" } & BitcoinAddressDetails) | ({ type: "bolt11Invoice" } & Bolt11InvoiceDetails) | ({ type: "bolt12Invoice" } & Bolt12InvoiceDetails) | ({ type: "bolt12Offer" } & Bolt12OfferDetails) | ({ type: "lightningAddress" } & LightningAddressDetails) | ({ type: "lnurlPay" } & LnurlPayRequestDetails) | ({ type: "silentPaymentAddress" } & SilentPaymentAddressDetails) | ({ type: "lnurlAuth" } & LnurlAuthRequestDetails) | ({ type: "url" } & string) | ({ type: "bip21" } & Bip21Details) | ({ type: "bolt12InvoiceRequest" } & Bolt12InvoiceRequestDetails) | ({ type: "lnurlWithdraw" } & LnurlWithdrawRequestDetails) | ({ type: "sparkAddress" } & SparkAddressDetails) | ({ type: "sparkInvoice" } & SparkInvoiceDetails);

export type KeySetType = "default" | "taproot" | "nativeSegwit" | "wrappedSegwit" | "legacy";

export type LnurlCallbackStatus = { type: "ok" } | { type: "errorStatus"; errorDetails: LnurlErrorDetails };

export type MaxFee = { type: "fixed"; amount: number } | { type: "rate"; satPerVbyte: number } | { type: "networkRecommended"; leewaySatPerVbyte: number };

export type Network = "mainnet" | "regtest";

export type OnchainConfirmationSpeed = "fast" | "medium" | "slow";

export type OptimizationMode = "full" | "singleRound";

export type OptimizationOutcome = { type: "completed"; roundsExecuted: number } | { type: "inProgress" };

export type PaymentDetails = { type: "spark"; invoiceDetails?: SparkInvoicePaymentDetails; htlcDetails?: SparkHtlcDetails; conversionInfo?: ConversionInfo } | { type: "token"; metadata: TokenMetadata; txHash: string; txType: TokenTransactionType; invoiceDetails?: SparkInvoicePaymentDetails; conversionInfo?: ConversionInfo } | { type: "lightning"; description?: string; invoice: string; destinationPubkey: string; htlcDetails: SparkHtlcDetails; lnurlPayInfo?: LnurlPayInfo; lnurlWithdrawInfo?: LnurlWithdrawInfo; lnurlReceiveMetadata?: LnurlReceiveMetadata } | { type: "withdraw"; txId: string } | { type: "deposit"; txId: string };

export type PaymentDetailsFilter = { type: "spark"; htlcStatus?: SparkHtlcStatus[]; conversionRefundNeeded?: boolean } | { type: "token"; conversionRefundNeeded?: boolean; txHash?: string; txType?: TokenTransactionType } | { type: "lightning"; htlcStatus?: SparkHtlcStatus[] };

export type PaymentMethod = "lightning" | "spark" | "token" | "deposit" | "withdraw" | "unknown";

export type PaymentStatus = "completed" | "pending" | "failed";

export type PaymentType = "send" | "receive";

export type ProvisionalPaymentDetails = { type: "bitcoin"; withdrawalAddress: string } | { type: "lightning"; invoice: string } | { type: "spark"; payRequest: string } | { type: "token"; tokenId: string; payRequest: string };

export type ReceivePaymentMethod = { type: "sparkAddress" } | { type: "sparkInvoice"; amount?: string; tokenIdentifier?: string; expiryTime?: number; description?: string; senderPublicKey?: string } | { type: "bitcoinAddress"; newAddress?: boolean } | { type: "bolt11Invoice"; description: string; amountSats?: number; expirySecs?: number; paymentHash?: string };

export type SdkEvent = { type: "synced" } | { type: "unclaimedDeposits"; unclaimedDeposits: DepositInfo[] } | { type: "claimedDeposits"; claimedDeposits: DepositInfo[] } | { type: "paymentSucceeded"; payment: Payment } | { type: "paymentPending"; payment: Payment } | { type: "paymentFailed"; payment: Payment } | { type: "autoOptimization"; optimizationEvent: AutoOptimizationEvent } | { type: "lightningAddressChanged"; lightningAddress?: LightningAddressInfo } | { type: "newDeposits"; newDeposits: DepositInfo[] };

export type Seed = { type: "mnemonic"; mnemonic: string; passphrase?: string } | ({ type: "entropy" } & number[]);

export type SendPaymentMethod = { type: "bitcoinAddress"; address: BitcoinAddressDetails; feeQuote: SendOnchainFeeQuote } | { type: "bolt11Invoice"; invoiceDetails: Bolt11InvoiceDetails; sparkTransferFeeSats?: number; lightningFeeSats: number } | { type: "sparkAddress"; address: string; fee: string; tokenIdentifier?: string } | { type: "sparkInvoice"; sparkInvoiceDetails: SparkInvoiceDetails; fee: string; tokenIdentifier?: string };

export type SendPaymentOptions = { type: "bitcoinAddress"; confirmationSpeed: OnchainConfirmationSpeed } | { type: "bolt11Invoice"; preferSpark: boolean; completionTimeoutSecs?: number } | { type: "sparkAddress"; htlcOptions?: SparkHtlcOptions };

export type ServiceStatus = "operational" | "degraded" | "partial" | "unknown" | "major";

export type SessionStoreError = { type: "notFound" } | ({ type: "generic" } & string);

export type SparkHtlcStatus = "waitingForPreimage" | "preimageShared" | "returned";

export type StableBalanceActiveLabel = { type: "set"; label: string } | { type: "unset" };

export type StoragePaymentDetailsFilter = { type: "spark"; htlcStatus?: SparkHtlcStatus[]; conversionRefundNeeded?: boolean } | { type: "token"; conversionRefundNeeded?: boolean; txHash?: string; txType?: TokenTransactionType } | { type: "lightning"; htlcStatus?: SparkHtlcStatus[] };

export type SuccessAction = { type: "aes"; data: AesSuccessActionData } | { type: "message"; data: MessageSuccessActionData } | { type: "url"; data: UrlSuccessActionData };

export type SuccessActionProcessed = { type: "aes"; result: AesSuccessActionDataResult } | { type: "message"; data: MessageSuccessActionData } | { type: "url"; data: UrlSuccessActionData };

export type TokenTransactionType = "transfer" | "mint" | "burn";

export type UpdateDepositPayload = { type: "claimError"; error: DepositClaimError } | { type: "refund"; refundTxid: string; refundTx: string };

export type WebhookEventType = { type: "lightningReceiveFinished" } | { type: "lightningSendFinished" } | { type: "coopExitFinished" } | { type: "staticDepositFinished" } | ({ type: "unknown" } & string);


/**
 * Rust-built implementation of the JS `BitcoinChainService` interface.
 *
 * Returned by factories like [`new_rest_chain_service`]; users see it as a
 * `BitcoinChainService` and pass it to `withChainService`. Pass the same
 * instance to multiple `SdkBuilder`s to share a single underlying HTTP
 * client (and its connection pool) across SDK instances.
 */
export class BitcoinChainServiceHandle {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    broadcastTransaction(tx: string): Promise<void>;
    getAddressUtxos(address: string): Promise<any>;
    getTransactionHex(txid: string): Promise<any>;
    getTransactionStatus(txid: string): Promise<any>;
    recommendedFees(): Promise<any>;
}

export class BreezSdk {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    addContact(request: AddContactRequest): Promise<Contact>;
    addEventListener(listener: EventListener): Promise<string>;
    buyBitcoin(request: BuyBitcoinRequest): Promise<BuyBitcoinResponse>;
    checkLightningAddressAvailable(request: CheckLightningAddressRequest): Promise<boolean>;
    checkMessage(request: CheckMessageRequest): Promise<CheckMessageResponse>;
    claimDeposit(request: ClaimDepositRequest): Promise<ClaimDepositResponse>;
    claimHtlcPayment(request: ClaimHtlcPaymentRequest): Promise<ClaimHtlcPaymentResponse>;
    deleteContact(id: string): Promise<void>;
    deleteLightningAddress(): Promise<void>;
    disconnect(): Promise<void>;
    fetchConversionLimits(request: FetchConversionLimitsRequest): Promise<FetchConversionLimitsResponse>;
    getInfo(request: GetInfoRequest): Promise<GetInfoResponse>;
    getLightningAddress(): Promise<LightningAddressInfo | undefined>;
    getPayment(request: GetPaymentRequest): Promise<GetPaymentResponse>;
    getTokenIssuer(): TokenIssuer;
    getTokensMetadata(request: GetTokensMetadataRequest): Promise<GetTokensMetadataResponse>;
    getUserSettings(): Promise<UserSettings>;
    listContacts(request: ListContactsRequest): Promise<Contact[]>;
    listFiatCurrencies(): Promise<ListFiatCurrenciesResponse>;
    listFiatRates(): Promise<ListFiatRatesResponse>;
    listPayments(request: ListPaymentsRequest): Promise<ListPaymentsResponse>;
    listUnclaimedDeposits(request: ListUnclaimedDepositsRequest): Promise<ListUnclaimedDepositsResponse>;
    listWebhooks(): Promise<Webhook[]>;
    lnurlAuth(request_data: LnurlAuthRequestDetails): Promise<LnurlCallbackStatus>;
    lnurlPay(request: LnurlPayRequest): Promise<LnurlPayResponse>;
    lnurlWithdraw(request: LnurlWithdrawRequest): Promise<LnurlWithdrawResponse>;
    optimizeLeaves(request: OptimizeLeavesRequest): Promise<OptimizeLeavesResponse>;
    parse(input: string): Promise<InputType>;
    prepareLnurlPay(request: PrepareLnurlPayRequest): Promise<PrepareLnurlPayResponse>;
    prepareSendPayment(request: PrepareSendPaymentRequest): Promise<PrepareSendPaymentResponse>;
    receivePayment(request: ReceivePaymentRequest): Promise<ReceivePaymentResponse>;
    recommendedFees(): Promise<RecommendedFees>;
    refundDeposit(request: RefundDepositRequest): Promise<RefundDepositResponse>;
    refundPendingConversions(): Promise<void>;
    registerLightningAddress(request: RegisterLightningAddressRequest): Promise<LightningAddressInfo>;
    registerWebhook(request: RegisterWebhookRequest): Promise<RegisterWebhookResponse>;
    removeEventListener(id: string): Promise<boolean>;
    sendPayment(request: SendPaymentRequest): Promise<SendPaymentResponse>;
    signMessage(request: SignMessageRequest): Promise<SignMessageResponse>;
    syncWallet(request: SyncWalletRequest): Promise<SyncWalletResponse>;
    unregisterWebhook(request: UnregisterWebhookRequest): Promise<void>;
    updateContact(request: UpdateContactRequest): Promise<Contact>;
    updateUserSettings(request: UpdateUserSettingsRequest): Promise<void>;
}

/**
 * A default signer implementation that wraps the core SDK's ExternalSigner.
 * This is returned by `defaultExternalSigner` and can be passed to `connectWithSigner`.
 */
export class DefaultSigner {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    aggregateFrost(request: ExternalAggregateFrostRequest): Promise<ExternalFrostSignature>;
    decryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    derivePublicKey(path: string): Promise<PublicKeyBytes>;
    encryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    encryptPrivateKeyForReceiver(private_key: ExternalEncryptedSecret, receiver_public_key: PublicKeyBytes): Promise<Uint8Array>;
    generateRandomSecret(): Promise<ExternalEncryptedSecret>;
    generateRandomSigningCommitment(): Promise<ExternalFrostCommitments>;
    getPublicKeyForNode(id: ExternalTreeNodeId): Promise<PublicKeyBytes>;
    hmacSha256(message: Uint8Array, path: string): Promise<HashedMessageBytes>;
    identityPublicKey(): PublicKeyBytes;
    publicKeyFromSecret(private_key: ExternalSecretSource): Promise<PublicKeyBytes>;
    signEcdsa(message: MessageBytes, path: string): Promise<EcdsaSignatureBytes>;
    signEcdsaRecoverable(message: MessageBytes, path: string): Promise<RecoverableEcdsaSignatureBytes>;
    signFrost(request: ExternalSignFrostRequest): Promise<ExternalFrostSignatureShare>;
    signHashSchnorr(hash: Uint8Array, path: string): Promise<SchnorrSignatureBytes>;
    splitSecretWithProofs(secret: ExternalSecretToSplit, threshold: number, num_shares: number): Promise<ExternalVerifiableSecretShare[]>;
    staticDepositSecret(index: number): Promise<SecretBytes>;
    staticDepositSecretEncrypted(index: number): Promise<ExternalSecretSource>;
    staticDepositSigningKey(index: number): Promise<PublicKeyBytes>;
    subtractSecrets(signing_key: ExternalSecretSource, new_signing_key: ExternalSecretSource): Promise<ExternalSecretSource>;
}

export class IntoUnderlyingByteSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableByteStreamController): Promise<any>;
    start(controller: ReadableByteStreamController): void;
    readonly autoAllocateChunkSize: number;
    readonly type: ReadableStreamType;
}

export class IntoUnderlyingSink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    abort(reason: any): Promise<any>;
    close(): Promise<any>;
    write(chunk: any): Promise<any>;
}

export class IntoUnderlyingSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableStreamDefaultController): Promise<any>;
}

/**
 * High-level orchestrator that collapses register / sign-in flows
 * into single calls. See the matching Rust types for full semantics;
 * the JS surface is a thin wasm-bindgen wrapper.
 */
export class PasskeyClient {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * One-shot capability probe (PRF support + domain association)
     * hosts can gate UX on.
     */
    checkAvailability(): Promise<PasskeyAvailability>;
    /**
     * Label sub-object. List / publish labels for this passkey's identity.
     */
    labels(): PasskeyLabels;
    /**
     * Create a `PasskeyClient` backed by the supplied `PrfProvider` and
     * the default Nostr-backed label store. `breezApiKey` enables
     * authenticated (NIP-42) relay access for label storage; omit for
     * public relays only.
     */
    constructor(prf_provider: PrfProvider, breez_api_key?: string | null, config?: PasskeyConfig | null);
    /**
     * First-time setup. Drives the platform's create-passkey ceremony
     * then derives the wallet seed in the same PRF assertion ceremony
     * where the platform supports it.
     */
    register(request: RegisterRequest): Promise<RegisterResponse>;
    /**
     * Returning-user sign-in. With `label` set, uses the fast path
     * (one ceremony, no Nostr round-trip). With `label` omitted,
     * derives the default-label wallet and discovers the user's
     * label set in the same ceremony.
     */
    signIn(request: SignInRequest): Promise<SignInResponse>;
}

/**
 * Label sub-object surfaced from `PasskeyClient.labels()`.
 */
export class PasskeyLabels {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * List labels published for this passkey's identity.
     */
    list(): Promise<string[]>;
    /**
     * Idempotently publish `label` for this passkey's identity.
     */
    store(label: string): Promise<void>;
}

export class SdkBuilder {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    build(): Promise<BreezSdk>;
    static new(config: Config, seed: Seed): SdkBuilder;
    static newWithSigner(config: Config, signer: ExternalSigner): SdkBuilder;
    withChainService(chain_service: BitcoinChainService): SdkBuilder;
    withDefaultStorage(storage_dir: string): Promise<SdkBuilder>;
    withFiatService(fiat_service: FiatService): SdkBuilder;
    withKeySet(config: KeySetConfig): SdkBuilder;
    withLnurlClient(lnurl_client: RestClient): SdkBuilder;
    /**
     * **Deprecated.** Use `withStorageBackend(mysqlStorage(config))`.
     */
    withMysqlBackend(config: MysqlStorageConfig): SdkBuilder;
    withPaymentObserver(payment_observer: PaymentObserver): SdkBuilder;
    /**
     * **Deprecated.** Use `withStorageBackend(postgresStorage(config))`.
     */
    withPostgresBackend(config: PostgresStorageConfig): SdkBuilder;
    withRestChainService(url: string, api_type: ChainApiType, credentials?: Credentials | null): SdkBuilder;
    /**
     * Threads a shared [`WasmSdkContext`] into the builder.
     *
     * Construct the context once via `newSharedSdkContext` and pass the same
     * handle to every `SdkBuilder` whose SDKs should share its resources
     * (operator gRPC channels, SSP HTTP client, database pool).
     */
    withSharedContext(context: WasmSdkContext): SdkBuilder;
    withStorage(storage: Storage): SdkBuilder;
    /**
     * Sets one of the SDK's built-in storage backends.
     *
     * Construct the [`WasmStorageConfig`] via `defaultStorage`,
     * `postgresStorage` or `mysqlStorage`.
     */
    withStorageBackend(config: WasmStorageConfig): SdkBuilder;
}

export class TokenIssuer {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    burnIssuerToken(request: BurnIssuerTokenRequest): Promise<Payment>;
    createIssuerToken(request: CreateIssuerTokenRequest): Promise<TokenMetadata>;
    freezeIssuerToken(request: FreezeIssuerTokenRequest): Promise<FreezeIssuerTokenResponse>;
    getIssuerTokenBalance(): Promise<TokenBalance>;
    getIssuerTokenMetadata(): Promise<TokenMetadata>;
    mintIssuerToken(request: MintIssuerTokenRequest): Promise<Payment>;
    unfreezeIssuerToken(request: UnfreezeIssuerTokenRequest): Promise<UnfreezeIssuerTokenResponse>;
}

/**
 * Process-shared resources backing one or more `BreezSdk` instances on WASM.
 *
 * Construct once via `newSharedSdkContext` and pass the handle to every
 * `SdkBuilder` whose SDKs should share its operator gRPC channels, SSP HTTP
 * client, and (optionally) database connection pool.
 */
export class WasmSdkContext {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}

/**
 * Selects one of the SDK's built-in storage backends.
 *
 * Construct it via `defaultStorage`, `postgresStorage` or `mysqlStorage` and
 * pass it to `SdkBuilder.withStorageBackend`.
 */
export class WasmStorageConfig {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}

export function connect(request: ConnectRequest): Promise<BreezSdk>;

export function connectWithSigner(config: Config, signer: ExternalSigner, storage_dir: string): Promise<BreezSdk>;

export function defaultConfig(network: Network): Config;

export function defaultExternalSigner(mnemonic: string, passphrase: string | null | undefined, network: Network, key_set_config?: KeySetConfig | null): DefaultSigner;

/**
 * Creates a default MySQL storage configuration with sensible defaults.
 *
 * Default values:
 * - `maxPoolSize`: 10
 * - `createTimeoutSecs`: 0 (no timeout)
 * - `recycleTimeoutSecs`: 10
 * - `foreignKeyMode`: `Enforced`
 */
export function defaultMysqlStorageConfig(connection_string: string): MysqlStorageConfig;

/**
 * Creates a default PostgreSQL storage configuration with sensible defaults.
 *
 * Default values (from pg.Pool):
 * - `maxPoolSize`: 10
 * - `createTimeoutSecs`: 0 (no timeout)
 * - `recycleTimeoutSecs`: 10 (10 seconds idle before disconnect)
 */
export function defaultPostgresStorageConfig(connection_string: string): PostgresStorageConfig;

export function defaultServerConfig(network: Network): Config;

/**
 * File-based storage rooted at `storageDir` — IndexedDB in the browser,
 * SQLite under Node.js.
 */
export function defaultStorage(storage_dir: string): WasmStorageConfig;

/**
 * Creates a default external signer from a mnemonic phrase.
 *
 * This creates a signer that can be used with `connectWithSigner` or `SdkBuilder.newWithSigner`.
 */
export function getSparkStatus(): Promise<SparkStatus>;

export function initLogging(logger: Logger, filter?: string | null): Promise<void>;

/**
 * `MySQL`-backed storage built from `config`.
 */
export function mysqlStorage(config: MysqlStorageConfig): WasmStorageConfig;

/**
 * Constructs a shareable REST-based Bitcoin chain service.
 *
 * Pass the returned chain service to multiple `SdkBuilder`s via
 * `withChainService` to reuse one HTTP client across SDK instances. All
 * SDKs sharing the chain service must use the same `network`.
 *
 * For one-off, non-shared use, prefer `withRestChainService`.
 */
export function newRestChainService(url: string, network: Network, api_type: ChainApiType, credentials?: Credentials | null): Promise<BitcoinChainService>;

/**
 * Constructs a [`WasmSdkContext`] from a `WasmSdkContextConfig`.
 */
export function newSharedSdkContext(config: WasmSdkContextConfig): Promise<WasmSdkContext>;

/**
 * `PostgreSQL`-backed storage built from `config`.
 */
export function postgresStorage(config: PostgresStorageConfig): WasmStorageConfig;

/**
 * Entry point invoked by JavaScript in a worker.
 */
export function task_worker_entry_point(ptr: number): void;
