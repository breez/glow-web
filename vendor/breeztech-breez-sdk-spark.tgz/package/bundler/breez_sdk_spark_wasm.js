/* @ts-self-types="./breez_sdk_spark_wasm.d.ts" */
import * as wasm from "./breez_sdk_spark_wasm_bg.wasm";
import { __wbg_set_wasm } from "./breez_sdk_spark_wasm_bg.js";

__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    BitcoinChainServiceHandle, BreezSdk, ExternalBreezSignerHandle, ExternalSigners, ExternalSigningSignerHandle, ExternalSparkSignerHandle, IntoUnderlyingByteSource, IntoUnderlyingSink, IntoUnderlyingSource, PasskeyClient, PasskeyLabels, SdkBuilder, SigningOnlyExternalSigners, TokenIssuer, WasmSdkContext, WasmStorageConfig, connect, connectWithSigner, connectWithSigningOnlySigner, createTurnkeySigner, createTurnkeySigningOnlySigner, defaultConfig, defaultExternalSigners, defaultMysqlStorageConfig, defaultPostgresStorageConfig, defaultServerConfig, defaultStorage, getSparkStatus, initLogging, mysqlStorage, newRestChainService, newSharedSdkContext, postgresStorage, start, task_worker_entry_point
} from "./breez_sdk_spark_wasm_bg.js";
