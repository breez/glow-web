export * from "./breez_sdk_spark_wasm.js";
import * as pkg from "./breez_sdk_spark_wasm.js";
export default pkg;
