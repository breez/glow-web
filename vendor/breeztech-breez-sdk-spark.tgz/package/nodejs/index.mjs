// ESM wrapper for the CJS Node.js entry: re-exports named bindings
// so that `import { connect } from '@breeztech/breez-sdk-spark'` works
// in ESM contexts.
import pkg from './index.js';

export const {
  connect,
  connectWithSigner,
  connectWithSigningOnlySigner,
  createTurnkeySigner,
  createTurnkeySigningOnlySigner,
  defaultConfig,
  defaultExternalSigners,
  defaultMysqlStorageConfig,
  defaultPostgresStorageConfig,
  defaultServerConfig,
  defaultSessionStore,
  defaultStorage,
  getSparkStatus,
  initLogging,
  mysqlStorage,
  newRestChainService,
  newSharedSdkContext,
  postgresStorage,
  start,
  task_worker_entry_point,
  BitcoinChainServiceHandle,
  BreezSdk,
  DefaultSessionStore,
  ExternalBreezSignerHandle,
  ExternalSigners,
  ExternalSigningSignerHandle,
  ExternalSparkSignerHandle,
  IntoUnderlyingByteSource,
  IntoUnderlyingSink,
  IntoUnderlyingSource,
  PasskeyClient,
  PasskeyLabels,
  SdkBuilder,
  SigningOnlyExternalSigners,
  TokenIssuer,
  WasmSdkContext,
  WasmStorageConfig,
} = pkg;

export default pkg;
