/**
 * CommonJS implementation for Node.js PostgreSQL Storage
 */

const crypto = require("crypto");

let pg;
try {
  const mainModule = require.main;
  if (mainModule) {
    pg = mainModule.require("pg");
  } else {
    pg = require("pg");
  }
} catch (error) {
  try {
    pg = require("pg");
  } catch (fallbackError) {
    const loadError = new Error(
      `pg not found. Please install it in your project: npm install pg@^8.18.0\n` +
        `Original error: ${error.message}\nFallback error: ${fallbackError.message}`
    );
    loadError.code = fallbackError.code;
    throw loadError;
  }
}

const { StorageError } = require("./errors.cjs");
const { PostgresMigrationManager } = require("./migrations.cjs");

// JSON has no BigInt, so u128 amounts are stored as decimal strings, which the
// SDK reads back as BigInts.
function toJson(value) {
  return JSON.stringify(value, (_key, v) =>
    typeof v === "bigint" ? v.toString() : v
  );
}

/**
 * Base query for payment lookups.
 * All columns are accessed by name in _rowToPayment.
 * parent_payment_id is only used by getPaymentsByParentIds.
 */
const SELECT_PAYMENT_SQL = `
    SELECT p.id,
           p.payment_type,
           p.status,
           p.amount,
           p.fees,
           p.timestamp,
           p.method,
           p.withdraw_tx_id,
           p.withdraw_vout,
           p.withdraw_destination_address,
           pd.tx_id AS deposit_tx_id,
           pd.vout AS deposit_vout,
           p.spark,
           l.invoice AS lightning_invoice,
           l.payment_hash AS lightning_payment_hash,
           l.destination_pubkey AS lightning_destination_pubkey,
           COALESCE(l.description, pm.lnurl_description) AS lightning_description,
           l.preimage AS lightning_preimage,
           l.htlc_status AS lightning_htlc_status,
           l.htlc_expiry_time AS lightning_htlc_expiry_time,
           pm.lnurl_pay_info,
           pm.lnurl_withdraw_info,
           pm.conversion_info,
           pm.conversion_status,
           t.metadata AS token_metadata,
           t.tx_hash AS token_tx_hash,
           t.tx_type AS token_tx_type,
           t.invoice_details AS token_invoice_details,
           s.invoice_details AS spark_invoice_details,
           s.htlc_details AS spark_htlc_details,
           lrm.nostr_zap_request AS lnurl_nostr_zap_request,
           lrm.nostr_zap_receipt AS lnurl_nostr_zap_receipt,
           lrm.sender_comment AS lnurl_sender_comment,
           lrm.lightning_address AS lnurl_lightning_address,
           lrm.payment_hash AS lnurl_payment_hash,
           pm.parent_payment_id
      FROM brz_payments p
      LEFT JOIN brz_payment_details_lightning l ON p.id = l.payment_id AND p.user_id = l.user_id
      LEFT JOIN brz_payment_details_token t ON p.id = t.payment_id AND p.user_id = t.user_id
      LEFT JOIN brz_payment_details_spark s ON p.id = s.payment_id AND p.user_id = s.user_id
      LEFT JOIN brz_payment_details_deposit pd ON p.id = pd.payment_id AND p.user_id = pd.user_id
      LEFT JOIN brz_payment_metadata pm ON p.id = pm.payment_id AND p.user_id = pm.user_id
      LEFT JOIN brz_lnurl_receive_metadata lrm ON l.payment_hash = lrm.payment_hash AND l.user_id = lrm.user_id`;

class PostgresStorage {
  /**
   * @param {import('pg').Pool} pool - Connection pool (may be shared with other tenants).
   * @param {Buffer|Uint8Array} identity - 33-byte secp256k1 compressed pubkey
   *   uniquely identifying this tenant. All reads and writes are scoped to it
   *   so that multiple instances with distinct identities can share one DB.
   * @param {object} [logger]
   */
  constructor(pool, identity, logger = null, runMigration = true) {
    if (!identity) {
      throw new StorageError("PostgresStorage requires a tenant identity");
    }
    this.pool = pool;
    this.identity = Buffer.from(identity);
    this.logger = logger;
    this.runMigration = runMigration;
  }

  /**
   * Initialize the database (run migrations)
   */
  async initialize() {
    try {
      if (this.runMigration) {
        const migrationManager = new PostgresMigrationManager(this.logger);
        await migrationManager.migrate(this.pool, this.identity);
      }
      return this;
    } catch (error) {
      throw new StorageError(
        `Failed to initialize PostgreSQL database: ${error.message}`,
        error
      );
    }
  }

  /**
   * Close the pool
   */
  async close() {
    if (this.pool) {
      await this.pool.end();
      this.pool = null;
    }
  }

  /**
   * Run a function inside a transaction.
   * @param {function(import('pg').PoolClient): Promise<T>} fn
   * @returns {Promise<T>}
   * @template T
   */
  async _withTransaction(fn) {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const result = await fn(client);
      await client.query("COMMIT");
      return result;
    } catch (error) {
      await client.query("ROLLBACK").catch(() => {});
      throw error;
    } finally {
      client.release();
    }
  }

  // ===== Cache Operations =====

  async getCachedItem(key) {
    try {
      const result = await this.pool.query(
        "SELECT value FROM brz_settings WHERE user_id = $1 AND key = $2",
        [this.identity, key]
      );
      return result.rows.length > 0 ? result.rows[0].value : null;
    } catch (error) {
      throw new StorageError(
        `Failed to get cached item '${key}': ${error.message}`,
        error
      );
    }
  }

  async setCachedItem(key, value) {
    try {
      await this.pool.query(
        `INSERT INTO brz_settings (user_id, key, value) VALUES ($1, $2, $3)
         ON CONFLICT(user_id, key) DO UPDATE SET value = EXCLUDED.value`,
        [this.identity, key, value]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to set cached item '${key}': ${error.message}`,
        error
      );
    }
  }

  async deleteCachedItem(key) {
    try {
      await this.pool.query(
        "DELETE FROM brz_settings WHERE user_id = $1 AND key = $2",
        [this.identity, key]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to delete cached item '${key}': ${error.message}`,
        error
      );
    }
  }

  // ===== Payment Operations =====

  async listPayments(request) {
    try {
      const actualOffset = request.offset != null ? request.offset : 0;
      const actualLimit =
        request.limit != null ? request.limit : 4294967295;

      // Tenant scoping is always $1; dynamic filters use $2 onwards.
      const whereClauses = ["p.user_id = $1"];
      const params = [this.identity];
      let paramIdx = 2;

      // Filter by payment type
      if (request.typeFilter && request.typeFilter.length > 0) {
        const placeholders = request.typeFilter.map(
          () => `$${paramIdx++}`
        );
        whereClauses.push(
          `p.payment_type IN (${placeholders.join(", ")})`
        );
        params.push(...request.typeFilter);
      }

      // Filter by status
      if (request.statusFilter && request.statusFilter.length > 0) {
        const placeholders = request.statusFilter.map(
          () => `$${paramIdx++}`
        );
        whereClauses.push(`p.status IN (${placeholders.join(", ")})`);
        params.push(...request.statusFilter);
      }

      // Filter by timestamp range
      if (request.fromTimestamp != null) {
        whereClauses.push(`p.timestamp >= $${paramIdx++}`);
        params.push(request.fromTimestamp);
      }

      if (request.toTimestamp != null) {
        whereClauses.push(`p.timestamp < $${paramIdx++}`);
        params.push(request.toTimestamp);
      }

      // Filter by payment details
      if (
        request.paymentDetailsFilter &&
        request.paymentDetailsFilter.length > 0
      ) {
        const allPaymentDetailsClauses = [];
        for (const paymentDetailsFilter of request.paymentDetailsFilter) {
          const paymentDetailsClauses = [];

          // Base type check: ensure payment type matches the filter type
          if (paymentDetailsFilter.type === "spark") {
            paymentDetailsClauses.push("p.spark = true");
          } else if (paymentDetailsFilter.type === "token") {
            paymentDetailsClauses.push("p.spark IS NULL AND t.tx_hash IS NOT NULL");
          } else if (paymentDetailsFilter.type === "lightning") {
            paymentDetailsClauses.push("l.htlc_status IS NOT NULL");
          }

          // Filter by HTLC status (Spark or Lightning)
          const htlcAlias =
            paymentDetailsFilter.type === "spark"
              ? "s"
              : paymentDetailsFilter.type === "lightning"
                ? "l"
                : null;
          if (
            htlcAlias &&
            paymentDetailsFilter.htlcStatus !== undefined &&
            paymentDetailsFilter.htlcStatus.length > 0
          ) {
            const placeholders = paymentDetailsFilter.htlcStatus.map(
              () => `$${paramIdx++}`
            );
            if (htlcAlias === "l") {
              paymentDetailsClauses.push(
                `l.htlc_status IN (${placeholders.join(", ")})`
              );
            } else {
              paymentDetailsClauses.push(
                `s.htlc_details::jsonb->>'status' IN (${placeholders.join(", ")})`
              );
            }
            params.push(...paymentDetailsFilter.htlcStatus);
          }

          // Filter by conversion type + status
          if (
            (paymentDetailsFilter.type === "spark" ||
              paymentDetailsFilter.type === "token" ||
              paymentDetailsFilter.type === "lightning") &&
            paymentDetailsFilter.conversionFilter !== undefined
          ) {
            // Lightning carries the Boltz conversion; its `conversion_info.type`
            // is the authoritative discriminator, so no payment-type column check.
            const typeCheck =
              paymentDetailsFilter.type === "spark"
                ? "p.spark = true"
                : paymentDetailsFilter.type === "token"
                  ? "p.spark IS NULL"
                  : null;
            let statusClause;
            if (paymentDetailsFilter.conversionFilter === "ammRefundNeeded") {
              statusClause = "pm.conversion_info::jsonb->>'type' = 'amm' AND pm.conversion_info::jsonb->>'status' = 'refundNeeded'";
            } else if (paymentDetailsFilter.conversionFilter === "orchestraPending") {
              statusClause = "pm.conversion_info::jsonb->>'type' = 'orchestra' AND pm.conversion_info::jsonb->>'status' NOT IN ('completed', 'failed', 'refunded')";
            } else if (paymentDetailsFilter.conversionFilter === "boltzPending") {
              statusClause = "pm.conversion_info::jsonb->>'type' = 'boltz' AND pm.conversion_info::jsonb->>'status' NOT IN ('completed', 'failed', 'refunded')";
            }
            if (statusClause) {
              const prefix = typeCheck ? `${typeCheck} AND ` : "";
              paymentDetailsClauses.push(
                `${prefix}pm.conversion_info IS NOT NULL AND ${statusClause}`
              );
            }
          }

          // Filter by token transaction hash
          if (
            paymentDetailsFilter.type === "token" &&
            paymentDetailsFilter.txHash !== undefined
          ) {
            paymentDetailsClauses.push(`t.tx_hash = $${paramIdx++}`);
            params.push(paymentDetailsFilter.txHash);
          }

          // Filter by token transaction type
          if (
            paymentDetailsFilter.type === "token" &&
            paymentDetailsFilter.txType !== undefined
          ) {
            paymentDetailsClauses.push(`t.tx_type = $${paramIdx++}`);
            params.push(paymentDetailsFilter.txType);
          }

          if (paymentDetailsClauses.length > 0) {
            allPaymentDetailsClauses.push(
              `(${paymentDetailsClauses.join(" AND ")})`
            );
          }
        }

        if (allPaymentDetailsClauses.length > 0) {
          whereClauses.push(
            `(${allPaymentDetailsClauses.join(" OR ")})`
          );
        }
      }

      // Filter by asset
      if (request.assetFilter) {
        const assetFilter = request.assetFilter;
        if (assetFilter.type === "bitcoin") {
          whereClauses.push("t.metadata IS NULL");
        } else if (assetFilter.type === "token") {
          whereClauses.push("t.metadata IS NOT NULL");
          if (assetFilter.tokenIdentifier) {
            whereClauses.push(
              `t.metadata::jsonb->>'identifier' = $${paramIdx++}`
            );
            params.push(assetFilter.tokenIdentifier);
          }
        }
      }

      // Exclude child payments
      whereClauses.push("pm.parent_payment_id IS NULL");

      const whereSql =
        whereClauses.length > 0
          ? `WHERE ${whereClauses.join(" AND ")}`
          : "";

      const orderDirection = request.sortAscending ? "ASC" : "DESC";
      const query = `${SELECT_PAYMENT_SQL} ${whereSql} ORDER BY p.timestamp ${orderDirection} LIMIT $${paramIdx++} OFFSET $${paramIdx++}`;

      params.push(actualLimit, actualOffset);
      const result = await this.pool.query(query, params);
      return result.rows.map(this._rowToPayment.bind(this));
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to list payments (request: ${toJson(request)}): ${error.message}`,
        error
      );
    }
  }

  async applyPaymentUpdate(payment) {
    if (!payment) {
      throw new StorageError("Payment cannot be null or undefined");
    }

    try {
      return await this._withTransaction(async (client) => {
        const lockKey = this._paymentUpdateLockKey(payment.id);
        await client.query(
          "SELECT pg_advisory_xact_lock($1::bigint)",
          [lockKey]
        );

        const { rows } = await client.query(
          "SELECT status FROM brz_payments WHERE user_id = $1 AND id = $2 FOR UPDATE",
          [this.identity, payment.id]
        );
        const stored = rows.length > 0
          ? this._normalizePaymentStatus(rows[0].status)
          : null;
        const next = this._normalizePaymentStatus(payment.status);

        if (stored != null
            && this._isFinalPaymentStatus(stored)
            && stored !== next) {
          console.warn(
            `Skipping payment update (would replace terminal status): id=${payment.id} stored=${stored} new=${next}`
          );
          return false;
        }

        const sameStatus = stored === next;
        if (sameStatus) {
          console.debug(
            `Skipping redundant payment event: id=${payment.id} status=${next}`
          );
        }
        await this._runPaymentUpsert(client, payment);
        return !sameStatus;
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to apply payment update '${payment.id}': ${error.message}`,
        error
      );
    }
  }

  _paymentUpdateLockKey(paymentId) {
    return crypto
      .createHash("sha256")
      .update("brz_payment_update")
      .update(this.identity)
      .update(Buffer.from(paymentId))
      .digest()
      .readBigInt64BE(0)
      .toString();
  }

  async _runPaymentUpsert(client, payment) {
    const withdraw = payment.details?.type === "withdraw" ? payment.details : null;
    const spark = payment.details?.type === "spark" ? true : null;

    await client.query(
      `INSERT INTO brz_payments (user_id, id, payment_type, status, amount, fees, timestamp, method, withdraw_tx_id, withdraw_vout, withdraw_destination_address, spark)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       ON CONFLICT(user_id, id) DO UPDATE SET
         payment_type=EXCLUDED.payment_type,
         status=EXCLUDED.status,
         amount=EXCLUDED.amount,
         fees=EXCLUDED.fees,
         timestamp=EXCLUDED.timestamp,
         method=EXCLUDED.method,
         withdraw_tx_id=EXCLUDED.withdraw_tx_id,
         withdraw_vout=EXCLUDED.withdraw_vout,
         withdraw_destination_address=EXCLUDED.withdraw_destination_address,
         spark=EXCLUDED.spark`,
      [
        this.identity,
        payment.id,
        payment.paymentType,
        payment.status,
        payment.amount.toString(),
        payment.fees.toString(),
        payment.timestamp,
        payment.method ? toJson(payment.method) : null,
        withdraw?.txId ?? null,
        withdraw?.vout ?? null,
        withdraw?.destinationAddress ?? null,
        spark,
      ]
    );

    if (payment.details?.type === "deposit") {
      await client.query(
        `INSERT INTO brz_payment_details_deposit (user_id, payment_id, tx_id, vout)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT(user_id, payment_id) DO UPDATE SET
           tx_id=EXCLUDED.tx_id,
           vout=EXCLUDED.vout`,
        [this.identity, payment.id, payment.details.txId, payment.details.vout]
      );
    }

    if (
      payment.details?.type === "spark" &&
      (payment.details.invoiceDetails != null ||
        payment.details.htlcDetails != null)
    ) {
      await client.query(
        `INSERT INTO brz_payment_details_spark (user_id, payment_id, invoice_details, htlc_details)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT(user_id, payment_id) DO UPDATE SET
           invoice_details=COALESCE(EXCLUDED.invoice_details, brz_payment_details_spark.invoice_details),
           htlc_details=COALESCE(EXCLUDED.htlc_details, brz_payment_details_spark.htlc_details)`,
        [
          this.identity,
          payment.id,
          payment.details.invoiceDetails
            ? toJson(payment.details.invoiceDetails)
            : null,
          payment.details.htlcDetails
            ? toJson(payment.details.htlcDetails)
            : null,
        ]
      );
    }

    if (payment.details?.type === "lightning") {
      await client.query(
        `INSERT INTO brz_payment_details_lightning
          (user_id, payment_id, invoice, payment_hash, destination_pubkey, description, preimage, htlc_status, htlc_expiry_time)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
          ON CONFLICT(user_id, payment_id) DO UPDATE SET
            invoice=EXCLUDED.invoice,
            payment_hash=EXCLUDED.payment_hash,
            destination_pubkey=EXCLUDED.destination_pubkey,
            description=EXCLUDED.description,
            preimage=COALESCE(EXCLUDED.preimage, brz_payment_details_lightning.preimage),
            htlc_status=COALESCE(EXCLUDED.htlc_status, brz_payment_details_lightning.htlc_status),
            htlc_expiry_time=COALESCE(EXCLUDED.htlc_expiry_time, brz_payment_details_lightning.htlc_expiry_time)`,
        [
          this.identity,
          payment.id,
          payment.details.invoice,
          payment.details.htlcDetails.paymentHash,
          payment.details.destinationPubkey,
          payment.details.description,
          payment.details.htlcDetails?.preimage,
          payment.details.htlcDetails?.status ?? null,
          payment.details.htlcDetails?.expiryTime ?? 0,
        ]
      );
    }

    if (payment.details?.type === "token") {
      await client.query(
        `INSERT INTO brz_payment_details_token
          (user_id, payment_id, metadata, tx_hash, tx_type, invoice_details)
          VALUES ($1, $2, $3, $4, $5, $6)
          ON CONFLICT(user_id, payment_id) DO UPDATE SET
            metadata=EXCLUDED.metadata,
            tx_hash=EXCLUDED.tx_hash,
            tx_type=EXCLUDED.tx_type,
            invoice_details=COALESCE(EXCLUDED.invoice_details, brz_payment_details_token.invoice_details)`,
        [
          this.identity,
          payment.id,
          toJson(payment.details.metadata),
          payment.details.txHash,
          payment.details.txType,
          payment.details.invoiceDetails
            ? toJson(payment.details.invoiceDetails)
            : null,
        ]
      );
    }
  }

  _normalizePaymentStatus(status) {
    return typeof status === "string" ? status.toLowerCase() : status;
  }

  _isFinalPaymentStatus(status) {
    const normalized = this._normalizePaymentStatus(status);
    return normalized === "completed" || normalized === "failed";
  }

  async getPaymentById(id) {
    try {
      if (!id) {
        throw new StorageError("Payment ID cannot be null or undefined");
      }

      const result = await this.pool.query(
        `${SELECT_PAYMENT_SQL} WHERE p.user_id = $1 AND p.id = $2`,
        [this.identity, id]
      );

      if (result.rows.length === 0) {
        throw new StorageError(`Payment with id '${id}' not found`);
      }

      return this._rowToPayment(result.rows[0]);
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to get payment by id '${id || "unknown"}': ${error.message}`,
        error
      );
    }
  }

  async getPaymentByInvoice(invoice) {
    try {
      if (!invoice) {
        throw new StorageError("Invoice cannot be null or undefined");
      }

      const result = await this.pool.query(
        `${SELECT_PAYMENT_SQL} WHERE p.user_id = $1 AND l.invoice = $2`,
        [this.identity, invoice]
      );

      if (result.rows.length === 0) {
        return null;
      }

      return this._rowToPayment(result.rows[0]);
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to get payment by invoice '${invoice}': ${error.message}`,
        error
      );
    }
  }

  async getPaymentsByParentIds(parentPaymentIds) {
    try {
      if (!parentPaymentIds || parentPaymentIds.length === 0) {
        return {};
      }

      // Early exit if no related payments exist for this tenant
      const hasRelatedResult = await this.pool.query(
        "SELECT EXISTS(SELECT 1 FROM brz_payment_metadata WHERE user_id = $1 AND parent_payment_id IS NOT NULL LIMIT 1)",
        [this.identity]
      );
      if (!hasRelatedResult.rows[0].exists) {
        return {};
      }

      // $1 is reserved for user_id; parent ids start at $2.
      const placeholders = parentPaymentIds.map(
        (_, i) => `$${i + 2}`
      );
      const query = `${SELECT_PAYMENT_SQL} WHERE p.user_id = $1 AND pm.parent_payment_id IN (${placeholders.join(", ")}) ORDER BY p.timestamp ASC`;

      const queryResult = await this.pool.query(
        query,
        [this.identity, ...parentPaymentIds]
      );

      const result = {};
      for (const row of queryResult.rows) {
        const parentId = row.parent_payment_id;
        if (!result[parentId]) {
          result[parentId] = [];
        }
        result[parentId].push(this._rowToPayment(row));
      }

      return result;
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to get payments by parent ids: ${error.message}`,
        error
      );
    }
  }

  async insertPaymentMetadata(paymentId, metadata) {
    try {
      await this.pool.query(
        `INSERT INTO brz_payment_metadata (user_id, payment_id, parent_payment_id, lnurl_pay_info, lnurl_withdraw_info, lnurl_description, conversion_info, conversion_status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         ON CONFLICT(user_id, payment_id) DO UPDATE SET
           parent_payment_id = COALESCE(EXCLUDED.parent_payment_id, brz_payment_metadata.parent_payment_id),
           lnurl_pay_info = COALESCE(EXCLUDED.lnurl_pay_info, brz_payment_metadata.lnurl_pay_info),
           lnurl_withdraw_info = COALESCE(EXCLUDED.lnurl_withdraw_info, brz_payment_metadata.lnurl_withdraw_info),
           lnurl_description = COALESCE(EXCLUDED.lnurl_description, brz_payment_metadata.lnurl_description),
           conversion_info = COALESCE(EXCLUDED.conversion_info, brz_payment_metadata.conversion_info),
           conversion_status = COALESCE(EXCLUDED.conversion_status, brz_payment_metadata.conversion_status)`,
        [
          this.identity,
          paymentId,
          metadata.parentPaymentId,
          metadata.lnurlPayInfo
            ? toJson(metadata.lnurlPayInfo)
            : null,
          metadata.lnurlWithdrawInfo
            ? toJson(metadata.lnurlWithdrawInfo)
            : null,
          metadata.lnurlDescription,
          metadata.conversionInfo
            ? toJson(metadata.conversionInfo)
            : null,
          metadata.conversionStatus ?? null,
        ]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to set payment metadata for '${paymentId}': ${error.message}`,
        error
      );
    }
  }

  // ===== Deposit Operations =====

  async addDeposit(txid, vout, amountSats, isMature) {
    try {
      await this.pool.query(
        `INSERT INTO brz_unclaimed_deposits (user_id, txid, vout, amount_sats, is_mature)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT(user_id, txid, vout) DO UPDATE SET is_mature = EXCLUDED.is_mature, amount_sats = EXCLUDED.amount_sats`,
        [this.identity, txid, vout, amountSats, isMature]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to add deposit '${txid}:${vout}': ${error.message}`,
        error
      );
    }
  }

  async deleteDeposit(txid, vout) {
    try {
      await this.pool.query(
        "DELETE FROM brz_unclaimed_deposits WHERE user_id = $1 AND txid = $2 AND vout = $3",
        [this.identity, txid, vout]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to delete deposit '${txid}:${vout}': ${error.message}`,
        error
      );
    }
  }

  async listDeposits() {
    try {
      const result = await this.pool.query(
        "SELECT txid, vout, amount_sats, is_mature, claim_error, refund_tx, refund_tx_id, instant_claim_status, refund_state, max_claim_fee FROM brz_unclaimed_deposits WHERE user_id = $1",
        [this.identity]
      );

      return result.rows.map((row) => ({
        txid: row.txid,
        vout: row.vout,
        amountSats: row.amount_sats != null ? BigInt(row.amount_sats) : BigInt(0),
        isMature: row.is_mature ?? true,
        claimError: row.claim_error || null,
        refundTx: row.refund_tx,
        refundTxId: row.refund_tx_id,
        instantClaimStatus: row.instant_claim_status || null,
        refundState: row.refund_state || null,
        maxClaimFee: row.max_claim_fee || null,
      }));
    } catch (error) {
      throw new StorageError(
        `Failed to list deposits: ${error.message}`,
        error
      );
    }
  }

  async updateDeposit(txid, vout, payload) {
    try {
      if (payload.type === "claimError") {
        await this.pool.query(
          `UPDATE brz_unclaimed_deposits
           SET claim_error = $1
           WHERE user_id = $2 AND txid = $3 AND vout = $4`,
          [toJson(payload.error), this.identity, txid, vout]
        );
      } else if (payload.type === "refund") {
        await this.pool.query(
          `UPDATE brz_unclaimed_deposits
           SET refund_tx = $1, refund_tx_id = $2, refund_state = $3, claim_error = NULL
           WHERE user_id = $4 AND txid = $5 AND vout = $6`,
          [
            payload.refundTx,
            payload.refundTxid,
            toJson(payload.state),
            this.identity,
            txid,
            vout,
          ]
        );
      } else if (payload.type === "instantClaim") {
        await this.pool.query(
          `UPDATE brz_unclaimed_deposits
           SET instant_claim_status = $1
           WHERE user_id = $2 AND txid = $3 AND vout = $4`,
          [toJson(payload.status), this.identity, txid, vout]
        );
      } else if (payload.type === "refundBroadcastState") {
        await this.pool.query(
          `UPDATE brz_unclaimed_deposits
           SET refund_state = $1
           WHERE user_id = $2 AND txid = $3 AND vout = $4 AND refund_tx_id = $5`,
          [
            toJson(payload.state),
            this.identity,
            txid,
            vout,
            payload.refundTxid,
          ]
        );
      } else if (payload.type === "maxClaimFee") {
        await this.pool.query(
          `UPDATE brz_unclaimed_deposits
           SET max_claim_fee = $1
           WHERE user_id = $2 AND txid = $3 AND vout = $4`,
          [
            payload.maxFee ? toJson(payload.maxFee) : null,
            this.identity,
            txid,
            vout,
          ]
        );
      } else {
        throw new StorageError(`Unknown payload type: ${payload.type}`);
      }
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to update deposit '${txid}:${vout}': ${error.message}`,
        error
      );
    }
  }

  async listWatchedDepositAddresses() {
    try {
      const result = await this.pool.query(
        `SELECT address, issued_at, seen FROM brz_watched_deposit_addresses
           WHERE user_id = $1 ORDER BY issued_at DESC`,
        [this.identity]
      );
      return result.rows.map((row) => ({
        address: row.address,
        issuedAt: BigInt(row.issued_at),
        seen: row.seen ?? false,
      }));
    } catch (error) {
      throw new StorageError(
        `Failed to list watched deposit addresses: ${error.message}`,
        error
      );
    }
  }

  async updateWatchedDepositAddress(address, payload) {
    try {
      if (payload.type === "watch") {
        await this.pool.query(
          `INSERT INTO brz_watched_deposit_addresses (user_id, address, issued_at, seen)
             VALUES ($1, $2, $3, FALSE)
             ON CONFLICT(user_id, address) DO UPDATE SET issued_at = EXCLUDED.issued_at, seen = FALSE`,
          [this.identity, address, String(payload.issuedAt)]
        );
      } else if (payload.type === "seen") {
        await this.pool.query(
          `UPDATE brz_watched_deposit_addresses SET seen = TRUE
             WHERE user_id = $1 AND address = $2`,
          [this.identity, address]
        );
      } else if (payload.type === "unwatch") {
        await this.pool.query(
          `DELETE FROM brz_watched_deposit_addresses
             WHERE user_id = $1 AND address = $2 AND issued_at = $3`,
          [this.identity, address, String(payload.issuedAt)]
        );
      } else {
        throw new StorageError(`Unknown payload type: ${payload.type}`);
      }
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to update watched deposit address '${address}': ${error.message}`,
        error
      );
    }
  }

  async listLeafRecoveries() {
    try {
      const result = await this.pool.query(
        `SELECT l.leaf_id,
                l.chain_checked_at,
                o.txid AS output_txid,
                o.vout AS output_vout,
                o.amount_sats AS output_amount_sats,
                o.script_pubkey AS output_script_pubkey,
                ot.block_height AS output_block_height,
                s.txid AS spend_txid,
                st.block_height AS spend_block_height,
                w.txid AS sweep_txid,
                wt.block_height AS sweep_block_height,
                r.txid AS recovery_txid,
                r.transaction_hex AS recovery_transaction_hex,
                r.output_amount_sats AS recovery_output_amount_sats
           FROM brz_leaf_recoveries l
           LEFT JOIN brz_watchtower_exit_outputs o
             ON o.user_id = l.user_id AND o.leaf_id = l.leaf_id
           LEFT JOIN brz_chain_transactions ot
             ON ot.user_id = o.user_id AND ot.txid = o.txid
           LEFT JOIN brz_watchtower_exit_spends s
             ON s.user_id = l.user_id AND s.leaf_id = l.leaf_id
           LEFT JOIN brz_chain_transactions st
             ON st.user_id = s.user_id AND st.txid = s.txid
           LEFT JOIN brz_unilateral_exit_sweeps w
             ON w.user_id = l.user_id AND w.leaf_id = l.leaf_id
           LEFT JOIN brz_chain_transactions wt
             ON wt.user_id = w.user_id AND wt.txid = w.txid
           LEFT JOIN brz_watchtower_exit_recoveries r
             ON r.user_id = l.user_id AND r.leaf_id = l.leaf_id
           WHERE l.user_id = $1
           ORDER BY l.leaf_id, r.txid`,
        [this.identity]
      );
      return leafRecoveriesFromRows(result.rows);
    } catch (error) {
      throw new StorageError(
        `Failed to list leaf recoveries: ${error.message}`,
        error
      );
    }
  }

  async updateLeafRecovery(update) {
    try {
      const leafId = update.leafId;
      await this._withTransaction(async (client) => {
        const setChainTransaction = (txid, blockHeight) =>
          client.query(
            `INSERT INTO brz_chain_transactions (user_id, txid, block_height)
               VALUES ($1, $2, $3)
               ON CONFLICT(user_id, txid) DO UPDATE SET block_height = EXCLUDED.block_height`,
            [this.identity, txid, blockHeight]
          );

        // PostgreSQL locks the leaf's row, so writers of one leaf do not interleave.
        await client.query(
          `INSERT INTO brz_leaf_recoveries (user_id, leaf_id) VALUES ($1, $2)
             ON CONFLICT(user_id, leaf_id) DO UPDATE SET leaf_id = EXCLUDED.leaf_id`,
          [this.identity, leafId]
        );
        if (update.chainCheckedAt != null) {
          await client.query(
            `UPDATE brz_leaf_recoveries
               SET chain_checked_at = GREATEST(COALESCE(chain_checked_at, 0), $3)
               WHERE user_id = $1 AND leaf_id = $2`,
            [this.identity, leafId, String(update.chainCheckedAt)]
          );
        }
        if (update.watchtowerExitOutput != null) {
          const output = update.watchtowerExitOutput;
          for (const table of [
            "brz_watchtower_exit_recoveries",
            "brz_watchtower_exit_spends",
          ]) {
            await client.query(
              `DELETE FROM ${table}
                 WHERE user_id = $1 AND leaf_id = $2 AND EXISTS (
                   SELECT 1 FROM brz_watchtower_exit_outputs
                   WHERE user_id = $1 AND leaf_id = $2 AND (txid <> $3 OR vout <> $4))`,
              [this.identity, leafId, output.txid, output.vout]
            );
          }
          await setChainTransaction(output.txid, output.blockHeight);
          await client.query(
            `INSERT INTO brz_watchtower_exit_outputs
                 (user_id, leaf_id, txid, vout, amount_sats, script_pubkey)
               VALUES ($1, $2, $3, $4, $5, $6)
               ON CONFLICT(user_id, leaf_id) DO UPDATE SET
                 txid = EXCLUDED.txid,
                 vout = EXCLUDED.vout,
                 amount_sats = EXCLUDED.amount_sats,
                 script_pubkey = EXCLUDED.script_pubkey`,
            [
              this.identity,
              leafId,
              output.txid,
              output.vout,
              String(output.amountSats),
              output.scriptPubkey,
            ]
          );
        }
        if (update.watchtowerExitRecovery != null) {
          const recovery = update.watchtowerExitRecovery;
          await client.query(
            `INSERT INTO brz_watchtower_exit_recoveries
                 (user_id, leaf_id, txid, transaction_hex, output_amount_sats)
               VALUES ($1, $2, $3, $4, $5)
               ON CONFLICT(user_id, leaf_id, txid) DO NOTHING`,
            [
              this.identity,
              leafId,
              recovery.txid,
              recovery.transactionHex,
              String(recovery.outputAmountSats),
            ]
          );
        }
        for (const [table, chainTransaction] of [
          ["brz_watchtower_exit_spends", update.watchtowerExitSpend],
          ["brz_unilateral_exit_sweeps", update.unilateralExitSweep],
        ]) {
          if (chainTransaction == null) {
            continue;
          }
          await setChainTransaction(
            chainTransaction.txid,
            chainTransaction.blockHeight
          );
          await client.query(
            `INSERT INTO ${table} (user_id, leaf_id, txid) VALUES ($1, $2, $3)
               ON CONFLICT(user_id, leaf_id) DO UPDATE SET txid = EXCLUDED.txid`,
            [this.identity, leafId, chainTransaction.txid]
          );
        }
      });
    } catch (error) {
      throw new StorageError(
        `Failed to update leaf recovery '${update.leafId}': ${error.message}`,
        error
      );
    }
  }

  async setLnurlMetadata(metadata) {
    try {
      await this._withTransaction(async (client) => {
        for (const item of metadata) {
          await client.query(
            `INSERT INTO brz_lnurl_receive_metadata (user_id, payment_hash, nostr_zap_request, nostr_zap_receipt, sender_comment, lightning_address)
             VALUES ($1, $2, $3, $4, $5, $6)
             ON CONFLICT(user_id, payment_hash) DO UPDATE SET
               nostr_zap_request = EXCLUDED.nostr_zap_request,
               nostr_zap_receipt = EXCLUDED.nostr_zap_receipt,
               sender_comment = EXCLUDED.sender_comment,
               lightning_address = EXCLUDED.lightning_address`,
            [
              this.identity,
              item.paymentHash,
              item.nostrZapRequest || null,
              item.nostrZapReceipt || null,
              item.senderComment || null,
              item.lightningAddress || null,
            ]
          );
        }
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to add lnurl metadata: ${error.message}`,
        error
      );
    }
  }

  // ===== Private Helper Methods =====

  _rowToPayment(row) {
    let details = null;
    if (row.lightning_invoice) {
      details = {
        type: "lightning",
        invoice: row.lightning_invoice,
        destinationPubkey: row.lightning_destination_pubkey,
        description: row.lightning_description,
        htlcDetails: row.lightning_htlc_status
          ? {
              paymentHash: row.lightning_payment_hash,
              preimage: row.lightning_preimage || null,
              expiryTime:
                Number(row.lightning_htlc_expiry_time) ?? 0,
              status: row.lightning_htlc_status,
            }
          : (() => {
              throw new StorageError(
                `htlc_status is required for Lightning payment ${row.id}`
              );
            })(),
      };

      if (row.lnurl_pay_info) {
        details.lnurlPayInfo =
          typeof row.lnurl_pay_info === "string"
            ? JSON.parse(row.lnurl_pay_info)
            : row.lnurl_pay_info;
      }

      if (row.lnurl_withdraw_info) {
        details.lnurlWithdrawInfo =
          typeof row.lnurl_withdraw_info === "string"
            ? JSON.parse(row.lnurl_withdraw_info)
            : row.lnurl_withdraw_info;
      }

      if (row.lnurl_payment_hash) {
        details.lnurlReceiveMetadata = {
          nostrZapRequest: row.lnurl_nostr_zap_request || null,
          nostrZapReceipt: row.lnurl_nostr_zap_receipt || null,
          senderComment: row.lnurl_sender_comment || null,
          lightningAddress: row.lnurl_lightning_address || null,
        };
      }

      if (row.conversion_info) {
        details.conversionInfo =
          typeof row.conversion_info === "string"
            ? JSON.parse(row.conversion_info)
            : row.conversion_info;
      }
    } else if (row.withdraw_tx_id) {
      // A withdrawal stored before the SDK kept these values has no details
      // until the next sync rewrites it.
      if (row.withdraw_vout != null && row.withdraw_destination_address != null) {
        details = {
          type: "withdraw",
          txId: row.withdraw_tx_id,
          vout: Number(row.withdraw_vout),
          destinationAddress: row.withdraw_destination_address,
        };
      }
    } else if (row.deposit_tx_id) {
      details = {
        type: "deposit",
        txId: row.deposit_tx_id,
        vout: Number(row.deposit_vout),
      };
    } else if (row.spark) {
      details = {
        type: "spark",
        invoiceDetails: row.spark_invoice_details
          ? typeof row.spark_invoice_details === "string"
            ? JSON.parse(row.spark_invoice_details)
            : row.spark_invoice_details
          : null,
        htlcDetails: row.spark_htlc_details
          ? typeof row.spark_htlc_details === "string"
            ? JSON.parse(row.spark_htlc_details)
            : row.spark_htlc_details
          : null,
        conversionInfo: row.conversion_info
          ? typeof row.conversion_info === "string"
            ? JSON.parse(row.conversion_info)
            : row.conversion_info
          : null,
      };
    } else if (row.token_metadata) {
      details = {
        type: "token",
        metadata:
          typeof row.token_metadata === "string"
            ? JSON.parse(row.token_metadata)
            : row.token_metadata,
        txHash: row.token_tx_hash,
        txType: row.token_tx_type,
        invoiceDetails: row.token_invoice_details
          ? typeof row.token_invoice_details === "string"
            ? JSON.parse(row.token_invoice_details)
            : row.token_invoice_details
          : null,
        conversionInfo: row.conversion_info
          ? typeof row.conversion_info === "string"
            ? JSON.parse(row.conversion_info)
            : row.conversion_info
          : null,
      };
    }

    let method = null;
    if (row.method) {
      try {
        method =
          typeof row.method === "string"
            ? JSON.parse(row.method)
            : row.method;
      } catch (e) {
        throw new StorageError(
          `Failed to parse payment method JSON for payment ${row.id}: ${e.message}`,
          e
        );
      }
    }

    return {
      id: row.id,
      paymentType: row.payment_type,
      status: row.status,
      amount: BigInt(row.amount),
      fees: BigInt(row.fees),
      timestamp: Number(row.timestamp),
      method,
      details,
      conversionDetails: row.conversion_status
        ? { status: row.conversion_status, from: null, to: null }
        : null,
    };
  }

  // ===== Contact Operations =====

  async listContacts(request) {
    try {
      const offset = request.offset != null ? request.offset : 0;
      const limit = request.limit != null ? request.limit : 4294967295;

      const result = await this.pool.query(
        `SELECT id, name, payment_identifier, created_at, updated_at
         FROM brz_contacts
         WHERE user_id = $1
         ORDER BY name ASC
         LIMIT $2 OFFSET $3`,
        [this.identity, limit, offset]
      );

      return result.rows.map((row) => ({
        id: row.id,
        name: row.name,
        paymentIdentifier: row.payment_identifier,
        createdAt: Number(row.created_at),
        updatedAt: Number(row.updated_at),
      }));
    } catch (error) {
      throw new StorageError(
        `Failed to list contacts: ${error.message}`,
        error
      );
    }
  }

  async getContact(id) {
    try {
      const result = await this.pool.query(
        `SELECT id, name, payment_identifier, created_at, updated_at
         FROM brz_contacts
         WHERE user_id = $1 AND id = $2`,
        [this.identity, id]
      );

      if (result.rows.length === 0) {
        return null;
      }

      const row = result.rows[0];
      return {
        id: row.id,
        name: row.name,
        paymentIdentifier: row.payment_identifier,
        createdAt: Number(row.created_at),
        updatedAt: Number(row.updated_at),
      };
    } catch (error) {
      throw new StorageError(
        `Failed to get contact: ${error.message}`,
        error
      );
    }
  }

  async insertContact(contact) {
    try {
      await this.pool.query(
        `INSERT INTO brz_contacts (user_id, id, name, payment_identifier, created_at, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT(user_id, id) DO UPDATE SET
           name = EXCLUDED.name,
           payment_identifier = EXCLUDED.payment_identifier,
           updated_at = EXCLUDED.updated_at`,
        [
          this.identity,
          contact.id,
          contact.name,
          contact.paymentIdentifier,
          contact.createdAt,
          contact.updatedAt,
        ]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to insert contact: ${error.message}`,
        error
      );
    }
  }

  async deleteContact(id) {
    try {
      await this.pool.query(
        "DELETE FROM brz_contacts WHERE user_id = $1 AND id = $2",
        [this.identity, id]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to delete contact: ${error.message}`,
        error
      );
    }
  }

  // ===== Cross-Chain Swap Operations =====

  async setCrossChainSwap(swap) {
    try {
      await this.pool.query(
        `INSERT INTO brz_cross_chain_swaps
           (user_id, provider, id, is_terminal, updated_at, data, secrets)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         ON CONFLICT(user_id, provider, id) DO UPDATE SET
           is_terminal = EXCLUDED.is_terminal,
           updated_at = EXCLUDED.updated_at,
           data = EXCLUDED.data,
           secrets = EXCLUDED.secrets`,
        [
          this.identity,
          swap.provider,
          swap.id,
          swap.isTerminal,
          swap.updatedAt,
          swap.data,
          swap.secrets,
        ]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to set cross-chain swap: ${error.message}`,
        error
      );
    }
  }

  async getCrossChainSwap(provider, id) {
    try {
      const result = await this.pool.query(
        `SELECT provider, id, is_terminal, updated_at, data, secrets
         FROM brz_cross_chain_swaps
         WHERE user_id = $1 AND provider = $2 AND id = $3`,
        [this.identity, provider, id]
      );
      if (result.rows.length === 0) {
        return null;
      }
      return crossChainSwapFromRow(result.rows[0]);
    } catch (error) {
      throw new StorageError(
        `Failed to get cross-chain swap: ${error.message}`,
        error
      );
    }
  }

  async listActiveCrossChainSwaps(provider) {
    try {
      const result = await this.pool.query(
        `SELECT provider, id, is_terminal, updated_at, data, secrets
         FROM brz_cross_chain_swaps
         WHERE user_id = $1 AND provider = $2 AND is_terminal = FALSE`,
        [this.identity, provider]
      );
      return result.rows.map(crossChainSwapFromRow);
    } catch (error) {
      throw new StorageError(
        `Failed to list active cross-chain swaps: ${error.message}`,
        error
      );
    }
  }

  // ===== Sync Operations =====

  async syncAddOutgoingChange(record) {
    try {
      return await this._withTransaction(async (client) => {
        // Local queue revision is per-tenant — two tenants don't share a queue.
        const revisionResult = await client.query(
          "SELECT COALESCE(MAX(revision), 0) + 1 AS revision FROM brz_sync_outgoing WHERE user_id = $1",
          [this.identity]
        );
        const revision = BigInt(revisionResult.rows[0].revision);

        await client.query(
          `INSERT INTO brz_sync_outgoing (
            user_id,
            record_type,
            data_id,
            schema_version,
            commit_time,
            updated_fields_json,
            revision
          ) VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [
            this.identity,
            record.id.type,
            record.id.dataId,
            record.schemaVersion,
            Math.floor(Date.now() / 1000),
            toJson(record.updatedFields),
            revision.toString(),
          ]
        );

        return revision;
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to add outgoing change: ${error.message}`,
        error
      );
    }
  }

  async syncCompleteOutgoingSync(record, localRevision) {
    try {
      await this._withTransaction(async (client) => {
        const deleteResult = await client.query(
          "DELETE FROM brz_sync_outgoing WHERE user_id = $1 AND record_type = $2 AND data_id = $3 AND revision = $4",
          [
            this.identity,
            record.id.type,
            record.id.dataId,
            localRevision.toString(),
          ]
        );

        if (deleteResult.rowCount === 0) {
          const msg = `complete_outgoing_sync: DELETE from brz_sync_outgoing matched 0 rows (type=${record.id.type}, data_id=${record.id.dataId}, revision=${localRevision})`;
          if (this.logger && typeof this.logger.log === "function") {
            this.logger.log({ line: msg, level: "warn" });
          } else {
            console.warn(`[PostgresStorage] ${msg}`);
          }
        }

        await client.query(
          `INSERT INTO brz_sync_state (
            user_id,
            record_type,
            data_id,
            revision,
            schema_version,
            commit_time,
            data
          ) VALUES ($1, $2, $3, $4, $5, $6, $7)
          ON CONFLICT(user_id, record_type, data_id) DO UPDATE SET
            schema_version = EXCLUDED.schema_version,
            commit_time = EXCLUDED.commit_time,
            data = EXCLUDED.data,
            revision = EXCLUDED.revision`,
          [
            this.identity,
            record.id.type,
            record.id.dataId,
            record.revision.toString(),
            record.schemaVersion,
            Math.floor(Date.now() / 1000),
            toJson(record.data),
          ]
        );

        // Upsert this tenant's revision row; fresh tenants without a row get one.
        await client.query(
          `INSERT INTO brz_sync_revision (user_id, revision) VALUES ($1, $2)
           ON CONFLICT (user_id) DO UPDATE SET revision = GREATEST(brz_sync_revision.revision, EXCLUDED.revision)`,
          [this.identity, record.revision.toString()]
        );
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to complete outgoing sync: ${error.message}`,
        error
      );
    }
  }

  async syncGetPendingOutgoingChanges(limit) {
    try {
      const result = await this.pool.query(
        `SELECT
          o.record_type,
          o.data_id,
          o.schema_version,
          o.commit_time,
          o.updated_fields_json,
          o.revision,
          e.schema_version as existing_schema_version,
          e.commit_time as existing_commit_time,
          e.data as existing_data,
          e.revision as existing_revision
        FROM brz_sync_outgoing o
        LEFT JOIN brz_sync_state e ON
          o.record_type = e.record_type AND
          o.data_id = e.data_id AND
          o.user_id = e.user_id
        WHERE o.user_id = $1
        ORDER BY o.revision ASC
        LIMIT $2`,
        [this.identity, limit]
      );

      return result.rows.map((row) => {
        const change = {
          id: {
            type: row.record_type,
            dataId: row.data_id,
          },
          schemaVersion: row.schema_version,
          updatedFields:
            typeof row.updated_fields_json === "string"
              ? JSON.parse(row.updated_fields_json)
              : row.updated_fields_json,
          localRevision: BigInt(row.revision),
        };

        let parent = null;
        if (row.existing_data) {
          parent = {
            id: {
              type: row.record_type,
              dataId: row.data_id,
            },
            revision: BigInt(row.existing_revision),
            schemaVersion: row.existing_schema_version,
            data:
              typeof row.existing_data === "string"
                ? JSON.parse(row.existing_data)
                : row.existing_data,
          };
        }

        return { change, parent };
      });
    } catch (error) {
      throw new StorageError(
        `Failed to get pending outgoing changes: ${error.message}`,
        error
      );
    }
  }

  async syncGetLastRevision() {
    try {
      // A tenant that hasn't synced anything yet may have no row; treat as 0.
      const result = await this.pool.query(
        "SELECT revision FROM brz_sync_revision WHERE user_id = $1",
        [this.identity]
      );
      return result.rows.length > 0
        ? BigInt(result.rows[0].revision)
        : BigInt(0);
    } catch (error) {
      throw new StorageError(
        `Failed to get last revision: ${error.message}`,
        error
      );
    }
  }

  async syncInsertIncomingRecords(records) {
    try {
      if (!records || records.length === 0) {
        return;
      }

      await this._withTransaction(async (client) => {
        for (const record of records) {
          await client.query(
            `INSERT INTO brz_sync_incoming (
              user_id,
              record_type,
              data_id,
              schema_version,
              commit_time,
              data,
              revision
            ) VALUES ($1, $2, $3, $4, $5, $6, $7)
            ON CONFLICT(user_id, record_type, data_id, revision) DO UPDATE SET
              schema_version = EXCLUDED.schema_version,
              commit_time = EXCLUDED.commit_time,
              data = EXCLUDED.data`,
            [
              this.identity,
              record.id.type,
              record.id.dataId,
              record.schemaVersion,
              Math.floor(Date.now() / 1000),
              toJson(record.data),
              record.revision.toString(),
            ]
          );
        }
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to insert incoming records: ${error.message}`,
        error
      );
    }
  }

  async syncDeleteIncomingRecord(record) {
    try {
      await this.pool.query(
        `DELETE FROM brz_sync_incoming
         WHERE user_id = $1
         AND record_type = $2
         AND data_id = $3
         AND revision = $4`,
        [this.identity, record.id.type, record.id.dataId, record.revision.toString()]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to delete incoming record: ${error.message}`,
        error
      );
    }
  }

  async syncGetIncomingRecords(limit) {
    try {
      const result = await this.pool.query(
        `SELECT i.record_type,
                i.data_id,
                i.schema_version,
                i.data,
                i.revision,
                e.schema_version AS existing_schema_version,
                e.commit_time AS existing_commit_time,
                e.data AS existing_data,
                e.revision AS existing_revision
         FROM brz_sync_incoming i
         LEFT JOIN brz_sync_state e ON i.record_type = e.record_type AND i.data_id = e.data_id AND i.user_id = e.user_id
         WHERE i.user_id = $1
         ORDER BY i.revision ASC
         LIMIT $2`,
        [this.identity, limit]
      );

      return result.rows.map((row) => {
        const newState = {
          id: {
            type: row.record_type,
            dataId: row.data_id,
          },
          revision: BigInt(row.revision),
          schemaVersion: row.schema_version,
          data:
            typeof row.data === "string"
              ? JSON.parse(row.data)
              : row.data,
        };

        let oldState = null;
        if (row.existing_data) {
          oldState = {
            id: {
              type: row.record_type,
              dataId: row.data_id,
            },
            revision: BigInt(row.existing_revision),
            schemaVersion: row.existing_schema_version,
            data:
              typeof row.existing_data === "string"
                ? JSON.parse(row.existing_data)
                : row.existing_data,
          };
        }

        return { newState, oldState };
      });
    } catch (error) {
      throw new StorageError(
        `Failed to get incoming records: ${error.message}`,
        error
      );
    }
  }

  async syncGetLatestOutgoingChange() {
    try {
      const result = await this.pool.query(
        `SELECT
          o.record_type,
          o.data_id,
          o.schema_version,
          o.commit_time,
          o.updated_fields_json,
          o.revision,
          e.schema_version as existing_schema_version,
          e.commit_time as existing_commit_time,
          e.data as existing_data,
          e.revision as existing_revision
        FROM brz_sync_outgoing o
        LEFT JOIN brz_sync_state e ON
          o.record_type = e.record_type AND
          o.data_id = e.data_id AND
          o.user_id = e.user_id
        WHERE o.user_id = $1
        ORDER BY o.revision DESC
        LIMIT 1`,
        [this.identity]
      );

      if (result.rows.length === 0) {
        return null;
      }

      const row = result.rows[0];

      const change = {
        id: {
          type: row.record_type,
          dataId: row.data_id,
        },
        schemaVersion: row.schema_version,
        updatedFields:
          typeof row.updated_fields_json === "string"
            ? JSON.parse(row.updated_fields_json)
            : row.updated_fields_json,
        localRevision: BigInt(row.revision),
      };

      let parent = null;
      if (row.existing_data) {
        parent = {
          id: {
            type: row.record_type,
            dataId: row.data_id,
          },
          revision: BigInt(row.existing_revision),
          schemaVersion: row.existing_schema_version,
          data:
            typeof row.existing_data === "string"
              ? JSON.parse(row.existing_data)
              : row.existing_data,
        };
      }

      return { change, parent };
    } catch (error) {
      throw new StorageError(
        `Failed to get latest outgoing change: ${error.message}`,
        error
      );
    }
  }

  async syncUpdateRecordFromIncoming(record) {
    try {
      await this._withTransaction(async (client) => {
        await client.query(
          `INSERT INTO brz_sync_state (
            user_id,
            record_type,
            data_id,
            revision,
            schema_version,
            commit_time,
            data
          ) VALUES ($1, $2, $3, $4, $5, $6, $7)
          ON CONFLICT(user_id, record_type, data_id) DO UPDATE SET
            schema_version = EXCLUDED.schema_version,
            commit_time = EXCLUDED.commit_time,
            data = EXCLUDED.data,
            revision = EXCLUDED.revision`,
          [
            this.identity,
            record.id.type,
            record.id.dataId,
            record.revision.toString(),
            record.schemaVersion,
            Math.floor(Date.now() / 1000),
            toJson(record.data),
          ]
        );

        await client.query(
          `INSERT INTO brz_sync_revision (user_id, revision) VALUES ($1, $2)
           ON CONFLICT (user_id) DO UPDATE SET revision = GREATEST(brz_sync_revision.revision, EXCLUDED.revision)`,
          [this.identity, record.revision.toString()]
        );
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to update record from incoming: ${error.message}`,
        error
      );
    }
  }
}

/**
 * Maps a brz_cross_chain_swaps row to the camelCase StoredCrossChainSwap shape
 * the SDK expects.
 */
function crossChainSwapFromRow(row) {
  return {
    provider: row.provider,
    id: row.id,
    isTerminal: row.is_terminal,
    updatedAt: Number(row.updated_at),
    data: row.data,
    secrets: row.secrets,
  };
}

/**
 * A row holds a leaf recovery and one of its watchtower exit recoveries, so
 * a leaf recovery with several of them spans several rows.
 */
function leafRecoveriesFromRows(rows) {
  const leafRecoveries = [];
  for (const row of rows) {
    let leafRecovery = leafRecoveries[leafRecoveries.length - 1];
    if (leafRecovery?.leafId !== row.leaf_id) {
      leafRecovery = {
        leafId: row.leaf_id,
        chainCheckedAt:
          row.chain_checked_at != null ? BigInt(row.chain_checked_at) : null,
        watchtowerExitOutput:
          row.output_block_height != null
            ? {
                txid: row.output_txid,
                vout: Number(row.output_vout),
                amountSats: BigInt(row.output_amount_sats),
                scriptPubkey: row.output_script_pubkey,
                blockHeight: Number(row.output_block_height),
              }
            : null,
        watchtowerExitRecoveries: [],
        watchtowerExitSpend:
          row.spend_block_height != null
            ? {
                txid: row.spend_txid,
                blockHeight: Number(row.spend_block_height),
              }
            : null,
        unilateralExitSweep:
          row.sweep_block_height != null
            ? {
                txid: row.sweep_txid,
                blockHeight: Number(row.sweep_block_height),
              }
            : null,
      };
      leafRecoveries.push(leafRecovery);
    }
    if (row.recovery_txid != null) {
      leafRecovery.watchtowerExitRecoveries.push({
        txid: row.recovery_txid,
        transactionHex: row.recovery_transaction_hex,
        outputAmountSats: BigInt(row.recovery_output_amount_sats),
      });
    }
  }
  return leafRecoveries;
}

/**
 * Creates a PostgresStorageConfig with the given connection string and default pool settings.
 *
 * Default values (from pg.Pool):
 * - maxPoolSize: 10
 * - createTimeoutSecs: 0 (no timeout)
 * - recycleTimeoutSecs: 10 (10 seconds idle before disconnect)
 *
 * @param {string} connectionString - PostgreSQL connection string
 * @returns {object} PostgreSQL storage configuration
 */
function defaultPostgresStorageConfig(connectionString) {
  return {
    connectionString,
    maxPoolSize: 10,
    createTimeoutSecs: 0,
    recycleTimeoutSecs: 10,
    runMigration: true,
  };
}

/**
 * Create a PostgresStorage instance from a config object.
 * Use {@link defaultPostgresStorageConfig} to create a config with sensible defaults.
 *
 * @param {object} config - PostgreSQL configuration (from defaultPostgresStorageConfig)
 * @param {string} config.connectionString - PostgreSQL connection string
 * @param {number} config.maxPoolSize - Maximum number of connections in the pool
 * @param {number} config.createTimeoutSecs - Timeout in seconds for establishing a new connection
 * @param {number} config.recycleTimeoutSecs - Timeout in seconds before recycling an idle connection
 * @param {Buffer|Uint8Array} identity - 33-byte secp256k1 compressed pubkey
 *   uniquely identifying this tenant.
 * @param {object} [logger] - Optional logger
 * @returns {Promise<PostgresStorage>}
 */
async function createPostgresStorage(config, identity, logger = null) {
  const pool = createPostgresPool(config);
  return createPostgresStorageWithPool(
    pool,
    identity,
    logger,
    config.runMigration !== false
  );
}

/**
 * Translates the `sslmode` URI parameter into pg's `ssl` option.
 * The pinned `pg` maps `require` to verified TLS but warns that pg v9 reverts
 * it to libpq semantics (no verification); handling `sslmode` here keeps the
 * documented guarantees stable across driver versions. The parameter (and the
 * `ssl`/`sslcert`/`sslkey`/`sslrootcert` parameters folded into the option)
 * are stripped from the URI because a connection string's ssl settings
 * override the explicit option.
 *
 * Spellings mirror the Rust SDK where pg has an equivalent:
 * - absent or `disable`: no TLS
 * - `prefer` / `require` / `verify-full`: TLS with certificate chain and
 *   hostname verification (pg cannot fall back to plaintext, so `prefer`
 *   behaves like `require`)
 * - `verify-ca`: chain verification only, hostname not checked
 * - `no-verify`: TLS without certificate verification (explicit opt-in)
 *
 * An unrecognized value throws rather than silently changing the TLS level.
 * Pin a private CA with `sslrootcert=<path>` (required for `verify-ca`); for
 * the hostname-verified modes, adding the CA to Node's trust store
 * (e.g. NODE_EXTRA_CA_CERTS) also works, though it extends the store rather
 * than pinning.
 */
function extractSslMode(connectionString) {
  if (
    !connectionString.startsWith("postgres://") &&
    !connectionString.startsWith("postgresql://")
  ) {
    return { connectionString, ssl: undefined };
  }
  const queryIndex = connectionString.indexOf("?");
  if (queryIndex === -1) {
    return { connectionString, ssl: undefined };
  }
  const params = connectionString.slice(queryIndex + 1).split("&");
  if (!params.some((param) => param.startsWith("sslmode="))) {
    return { connectionString, ssl: undefined };
  }

  const base = connectionString.slice(0, queryIndex);
  const retained = [];
  const files = {};
  let sslMode;
  for (const param of params) {
    const eq = param.indexOf("=");
    const key = eq === -1 ? param : param.slice(0, eq);
    const value = eq === -1 ? "" : decodeURIComponent(param.slice(eq + 1));
    if (key === "sslmode") {
      sslMode = value;
    } else if (key === "sslcert" || key === "sslkey" || key === "sslrootcert") {
      files[key] = value;
    } else if (key === "ssl") {
      // consumed: sslmode governs TLS when present
    } else {
      retained.push(param);
    }
  }
  const rebuilt = retained.length ? `${base}?${retained.join("&")}` : base;
  return { connectionString: rebuilt, ssl: sslOptionForMode(sslMode, files) };
}

function sslOptionForMode(mode, files) {
  let ssl;
  switch (mode) {
    case "disable":
      return false;
    case "prefer":
    case "require":
    case "verify-full":
      ssl = { rejectUnauthorized: true };
      break;
    case "verify-ca":
      // Without a pinned CA, chain-only verification accepts a certificate
      // from any trusted CA for any host, which authenticates nothing.
      if (!files.sslrootcert) {
        throw new StorageError(
          "sslmode=verify-ca requires sslrootcert=<path>; supply the CA to " +
            "pin, or use sslmode=require / verify-full for " +
            "hostname-verified TLS"
        );
      }
      ssl = { rejectUnauthorized: true, checkServerIdentity: () => undefined };
      break;
    case "no-verify":
      ssl = { rejectUnauthorized: false };
      break;
    default:
      throw new StorageError(
        `Unrecognized sslmode value \`${mode}\`; expected one of: ` +
          "disable, prefer, require, verify-ca, verify-full, no-verify"
      );
  }
  const fs =
    files.sslcert || files.sslkey || files.sslrootcert ? require("fs") : null;
  if (files.sslcert) {
    ssl.cert = fs.readFileSync(files.sslcert).toString();
  }
  if (files.sslkey) {
    ssl.key = fs.readFileSync(files.sslkey).toString();
  }
  if (files.sslrootcert) {
    ssl.ca = fs.readFileSync(files.sslrootcert).toString();
  }
  return ssl;
}

/**
 * Create a pg.Pool from a config object.
 * The returned pool can be shared across multiple store implementations.
 *
 * @param {object} config - PostgreSQL configuration (from defaultPostgresStorageConfig)
 * @returns {pg.Pool}
 */
function createPostgresPool(config) {
  const { connectionString, ssl } = extractSslMode(config.connectionString);
  return new pg.Pool({
    connectionString,
    ...(ssl !== undefined && { ssl }),
    max: config.maxPoolSize,
    connectionTimeoutMillis: config.createTimeoutSecs * 1000,
    idleTimeoutMillis: config.recycleTimeoutSecs * 1000,
  });
}

/**
 * Create a PostgresStorage instance from an existing pg.Pool.
 *
 * @param {pg.Pool} pool - An existing connection pool
 * @param {Buffer|Uint8Array} identity - 33-byte tenant identity (secp256k1 pubkey).
 * @param {object} [logger] - Optional logger
 * @returns {Promise<PostgresStorage>}
 */
async function createPostgresStorageWithPool(
  pool,
  identity,
  logger = null,
  runMigration = true
) {
  const storage = new PostgresStorage(
    pool,
    identity,
    logger,
    runMigration
  );
  await storage.initialize();
  return storage;
}

module.exports = { PostgresStorage, createPostgresStorage, createPostgresPool, createPostgresStorageWithPool, defaultPostgresStorageConfig, StorageError };
