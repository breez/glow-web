/**
 * CommonJS implementation for Node.js PostgreSQL Tree Store
 */

let pg;
try {
  const mainModule = require.main;
  if (mainModule) {
    pg = mainModule.require("pg");
  } else {
    pg = require("pg");
  }
} catch (error) {
  try {
    pg = require("pg");
  } catch (fallbackError) {
    throw new Error(
      `pg not found. Please install it in your project: npm install pg@^8.18.0\n` +
        `Original error: ${error.message}\nFallback error: ${fallbackError.message}`
    );
  }
}

const { TreeStoreError } = require("./errors.cjs");
const { TreeStoreMigrationManager } = require("./migrations.cjs");

/**
 * Domain prefix mixed into the per-tenant advisory-lock key. Distinct prefixes
 * guarantee that locks from different stores (tree, token, …) never collide.
 */
const TREE_STORE_LOCK_PREFIX = "breez-spark-sdk:tree:";

/**
 * Timeout for reservations in seconds. Reservations older than this are stale.
 */
const RESERVATION_TIMEOUT_SECS = 300; // 5 minutes

/**
 * Threshold in milliseconds for cleaning up spent leaf markers.
 */
const SPENT_MARKER_CLEANUP_THRESHOLD_MS = 5 * 60 * 1000; // 5 minutes

/**
 * Leaves per INSERT when upserting a refreshed leaf set.
 *
 * A wallet can hold six figures of leaves, each serializing to a JSON blob
 * carrying up to five transactions. Building that as a single statement
 * materializes the whole set at once, which is the largest allocation in a
 * refresh and lands at its very end.
 */
const LEAF_UPSERT_CHUNK_SIZE = 1000;

/**
 * Slim projection: only (id, value) for leaves the selection might use.
 * Includes all leaves with value <= $2 (covers exact-match + the small-leaf
 * accumulators for the minimum-amount path) plus the single smallest leaf
 * with value > $2 (covers the minimum-amount fallback case where one larger
 * leaf is sufficient). $1 is the user id.
 */
const SLIM_LEAF_CANDIDATES_SQL = `
  SELECT id, value
  FROM brz_tree_leaves
  WHERE user_id = $1
    AND status = 'Available'
    AND is_missing_from_operators = FALSE
    AND reservation_id IS NULL
    AND (
      value <= $2
      OR id = (
        SELECT id FROM brz_tree_leaves
        WHERE user_id = $1
          AND status = 'Available'
          AND is_missing_from_operators = FALSE
          AND reservation_id IS NULL
          AND value > $2
        ORDER BY value
        LIMIT 1
      )
    )
`;

/**
 * Derive a stable per-tenant 64-bit advisory-lock key by hashing a domain
 * prefix together with the identity pubkey and folding the first 8 bytes of
 * the SHA-256 digest into a signed big-endian i64 — the type expected by
 * `pg_advisory_xact_lock(bigint)`. The 64-bit space keeps cross-tenant
 * collisions negligible (~1.2e-10 at 65k tenants).
 */
function _identityLockKey(prefix, identity) {
  const crypto = require("crypto");
  const hash = crypto.createHash("sha256");
  hash.update(prefix);
  hash.update(Buffer.from(identity));
  return hash.digest().readBigInt64BE(0);
}

/**
 * Pair a leaf with its ancestors (nearest first) by walking `parent_node_id`
 * through `nodes`. Returns null if the leaf itself is absent; stops at a gap or
 * cycle, returning a partial chain.
 * @param {Map<string, object>} nodes
 * @param {string} leafId
 * @returns {{leaf: object, ancestors: Array<object>}|null}
 */
function assembleExitChain(nodes, leafId) {
  const leaf = nodes.get(leafId);
  if (!leaf) return null;
  const ancestors = [];
  const visited = new Set([leafId]);
  let current = leaf.parent_node_id;
  while (current != null && !visited.has(current)) {
    visited.add(current);
    const node = nodes.get(current);
    if (!node) break;
    ancestors.push(node);
    current = node.parent_node_id;
  }
  return { leaf, ancestors };
}

class PostgresTreeStore {
  /**
   * @param {import('pg').Pool} pool
   * @param {Buffer|Uint8Array} identity - 33-byte secp256k1 compressed pubkey
   *   identifying the tenant. All reads and writes are scoped by this.
   * @param {object} [logger]
   */
  constructor(pool, identity, logger = null, runMigration = true) {
    if (!identity || identity.length !== 33) {
      throw new TreeStoreError(
        "tenant identity (33-byte secp256k1 pubkey) is required"
      );
    }
    this.pool = pool;
    this.identity = Buffer.from(identity);
    this.lockKey = _identityLockKey(TREE_STORE_LOCK_PREFIX, identity);
    this.logger = logger;
    this.runMigration = runMigration;
  }

  /**
   * Initialize the database (run migrations)
   */
  async initialize() {
    try {
      if (this.runMigration) {
        const migrationManager = new TreeStoreMigrationManager(this.logger);
        await migrationManager.migrate(this.pool, this.identity);
      }
      return this;
    } catch (error) {
      throw new TreeStoreError(
        `Failed to initialize PostgreSQL tree store: ${error.message}`,
        error
      );
    }
  }

  /**
   * Close the pool
   */
  async close() {
    if (this.pool) {
      await this.pool.end();
      this.pool = null;
    }
  }

  /**
   * Run a function inside a transaction with the advisory lock. Used by every
   * operation that mutates the leaf set or its reservations.
   * @param {function(import('pg').PoolClient): Promise<T>} fn
   * @returns {Promise<T>}
   * @template T
   */
  async _withWriteTransaction(fn) {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      // Per-tenant advisory lock: 64-bit key derived from a tree-store domain
      // prefix and the tenant identity, so different tenants don't serialize
      // on each other and tree/token locks never collide.
      await client.query("SELECT pg_advisory_xact_lock($1)", [this.lockKey]);
      const result = await fn(client);
      await client.query("COMMIT");
      return result;
    } catch (error) {
      await client.query("ROLLBACK").catch(() => {});
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Run a function inside a transaction without the advisory lock. Used by
   * `addLeaves` and by read-only queries (`trySelectLeaves`), where MVCC +
   * row-level locks suffice and the global lock would only add contention.
   * @param {function(import('pg').PoolClient): Promise<T>} fn
   * @returns {Promise<T>}
   * @template T
   */
  async _withTransaction(fn) {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const result = await fn(client);
      await client.query("COMMIT");
      return result;
    } catch (error) {
      await client.query("ROLLBACK").catch(() => {});
      throw error;
    } finally {
      client.release();
    }
  }

  // ===== TreeStore Methods =====

  /**
   * Add leaves to the store. Removes from spent leaves first, then upserts.
   * @param {Array} leaves - Array of TreeNode objects
   */
  async addLeaves(leaves) {
    try {
      if (!leaves || leaves.length === 0) {
        return;
      }

      const leafNodes = leaves;
      await this._withTransaction(async (client) => {
        // Remove these leaves from spent_leaves table
        const leafIds = leafNodes.map((l) => l.id);
        await this._batchRemoveSpentLeaves(client, leafIds);

        // Batch upsert all leaves
        await this._batchUpsertLeaves(client, leafNodes, false, null);
      });
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to add leaves: ${error.message}`,
        error
      );
    }
  }

  /**
   * Store the ancestor chain of each pedigree, leaving the leaf pool and any
   * spent marker untouched.
   * @param {Array} pedigrees - Array of LeafPedigree { leaf, ancestors }
   */
  async storeAncestors(pedigrees) {
    try {
      if (!pedigrees || pedigrees.length === 0) {
        return;
      }

      await this._withWriteTransaction(async (client) => {
        // A leaf can be spent between its chain being resolved and this write, and
        // a chain is only ever removed with its leaf. Writing one for a leaf that is
        // already gone would leave it behind for good.
        const stored = await client.query(
          "SELECT id FROM brz_tree_leaves WHERE user_id = $1 AND id = ANY($2)",
          [this.identity, pedigrees.map((p) => p.leaf.id)]
        );
        const storedLeafIds = new Set(stored.rows.map((row) => row.id));

        await this._batchUpsertAncestors(
          client,
          pedigrees.filter((p) => storedLeafIds.has(p.leaf.id))
        );
      });
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to store ancestors: ${error.message}`,
        error
      );
    }
  }

  /**
   * Ids of the stored leaves whose chain cannot back an exit: the leaf has a
   * parent, and no ancestor row of its own holds that parent.
   * @returns {Promise<Array<string>>}
   */
  async leavesMissingExitChains() {
    try {
      const result = await this.pool.query(
        // A stored chain runs from its leaf's parent to a root, so a leaf whose
        // chain holds the parent it has now is exitable. The join binds all three
        // primary key columns, making it one index probe per leaf. A leaf that is
        // itself a root needs no chain.
        `SELECT l.id
         FROM brz_tree_leaves l
         LEFT JOIN brz_tree_ancestors link
           ON link.user_id = l.user_id AND link.leaf_id = l.id
              AND link.id = l.parent_node_id
         WHERE l.user_id = $1
           AND l.parent_node_id IS NOT NULL
           AND link.leaf_id IS NULL`,
        [this.identity]
      );
      return result.rows.map((r) => r.id);
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to get leaves missing exit chains: ${error.message}`,
        error
      );
    }
  }

  /**
   * Reconstruct the exit chains for many leaves in one query, each as
   * { leaf, ancestors } with ancestors nearest first. A leaf absent from the store
   * is skipped; a chain that hits a gap comes back partial.
   * @param {Array<string>} leafIds
   * @returns {Promise<Array<{leaf: object, ancestors: Array<object>}>>}
   */
  async getExitChains(leafIds) {
    try {
      if (!leafIds || leafIds.length === 0) return [];
      // One query loads each requested leaf's own row plus its ancestor rows,
      // both tagged by the owning leaf id (a leaf's own row is tagged with its
      // own id). Reading them in two queries could pair a leaf with ancestors
      // from a different snapshot. Grouping by that tag keeps each leaf's node
      // set separate, so a node id stored under another leaf can never
      // cross-contaminate this one.
      const result_rows = await this.pool.query(
        `SELECT leaf_id, data FROM brz_tree_ancestors WHERE user_id = $1 AND leaf_id = ANY($2)
         UNION ALL
         SELECT id AS leaf_id, data FROM brz_tree_leaves WHERE user_id = $1 AND id = ANY($2)`,
        [this.identity, leafIds]
      );

      const nodesByLeaf = new Map();
      for (const r of result_rows.rows) {
        let nodes = nodesByLeaf.get(r.leaf_id);
        if (!nodes) {
          nodes = new Map();
          nodesByLeaf.set(r.leaf_id, nodes);
        }
        nodes.set(r.data.id, r.data);
      }

      const result = [];
      for (const id of leafIds) {
        const nodes = nodesByLeaf.get(id);
        if (!nodes) continue;
        const pedigree = assembleExitChain(nodes, id);
        if (pedigree) result.push(pedigree);
      }
      return result;
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(`Failed to get exit chains: ${error.message}`, error);
    }
  }

  /**
   * Get all leaves categorized by status.
   * @returns {Promise<Object>} Leaves object with available, notAvailable, etc.
   */
  /**
   * Returns the wallet's spendable balance (available + missing-from-operators
   * + swap-reserved). Aggregated server-side so we don't fetch every leaf.
   * @returns {Promise<bigint>}
   */
  async getAvailableBalance() {
    try {
      const result = await this.pool.query(
        `
        SELECT COALESCE(SUM(l.value), 0)::bigint AS balance
        FROM brz_tree_leaves l
        LEFT JOIN brz_tree_reservations r
          ON l.reservation_id = r.id AND l.user_id = r.user_id
        WHERE l.user_id = $1
          AND (
            (l.reservation_id IS NULL AND l.status = 'Available')
            OR r.purpose = 'Swap'
          )
      `,
        [this.identity]
      );
      return BigInt(result.rows[0].balance);
    } catch (error) {
      throw new TreeStoreError(
        `Failed to get available balance: ${error.message}`,
        error
      );
    }
  }

  async getVerifiedLeafKeys() {
    try {
      // Project just the two pubkeys out of the JSON, skipping each leaf's
      // `data` blob (up to five transactions). Every stored leaf passed the
      // ownership check on its way in, whatever its status, so all are
      // projected.
      const result = await this.pool.query(
        `
        SELECT l.id AS id,
               l.verifying_public_key AS verifying,
               l.signing_public_key AS keyshare
        FROM brz_tree_leaves l
        LEFT JOIN brz_tree_reservations r
          ON l.reservation_id = r.id AND l.user_id = r.user_id
        WHERE l.user_id = $1
      `,
        [this.identity]
      );
      return result.rows.map((row) => [row.id, row.verifying, row.keyshare]);
    } catch (error) {
      throw new TreeStoreError(
        `Failed to get verified leaf keys: ${error.message}`,
        error
      );
    }
  }

  async getLeaves() {
    try {
      const result = await this.pool.query(
        `
        SELECT l.id, l.status, l.is_missing_from_operators, l.data,
               l.reservation_id, r.purpose
        FROM brz_tree_leaves l
        LEFT JOIN brz_tree_reservations r
          ON l.reservation_id = r.id AND l.user_id = r.user_id
        WHERE l.user_id = $1
      `,
        [this.identity]
      );

      const available = [];
      const notAvailable = [];
      const availableMissingFromOperators = [];
      const reservedForPayment = [];
      const reservedForSwap = [];

      for (const row of result.rows) {
        const node = row.data;
        const spendable = node.status === "Available";

        if (row.purpose) {
          if (row.purpose === "Payment") {
            reservedForPayment.push(node);
          } else if (row.purpose === "Swap") {
            reservedForSwap.push(node);
          }
        } else if (!spendable) {
          notAvailable.push(node);
        } else if (row.is_missing_from_operators) {
          availableMissingFromOperators.push(node);
        } else {
          available.push(node);
        }
      }

      return {
        available,
        notAvailable,
        availableMissingFromOperators,
        reservedForPayment,
        reservedForSwap,
      };
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to get leaves: ${error.message}`,
        error
      );
    }
  }

  /**
   * Set leaves from a refresh operation.
   * @param {Array} leaves - Available leaves from operators
   * @param {Array} missingLeaves - Leaves missing from some operators
   * @param {number} refreshStartedAtMs - Epoch milliseconds when refresh started
   */
  async setLeaves(leaves, missingLeaves, refreshStartedAtMs) {
    try {
      await this._withWriteTransaction(async (client) => {
        const refreshTimestamp = new Date(refreshStartedAtMs);

        // Drop expired reservations BEFORE evaluating has_active_swap, otherwise a stale
        // Swap reservation (from a crashed client or a swap whose finalize/cancel never
        // ran) keeps has_active_swap true forever, which makes set_leaves early-return
        // and never reach the cleanup again. The reservation pins itself in place.
        await this._cleanupStaleReservations(client);

        // Check for active swap or swap completed during refresh
        const swapCheckResult = await client.query(
          `
          SELECT
            EXISTS(
              SELECT 1 FROM brz_tree_reservations
              WHERE user_id = $1 AND purpose = 'Swap'
            ) AS has_active_swap,
            COALESCE(
              (SELECT last_completed_at >= $2
               FROM brz_tree_swap_status WHERE user_id = $1),
              FALSE
            ) AS swap_completed_during_refresh
        `,
          [this.identity, refreshTimestamp]
        );

        const { has_active_swap, swap_completed_during_refresh } = swapCheckResult.rows[0];

        if (has_active_swap || swap_completed_during_refresh) {
          return;
        }

        // Clean up old spent markers
        await this._cleanupSpentMarkers(client, refreshTimestamp);

        const spentResult = await client.query(
          "SELECT leaf_id FROM brz_tree_spent_leaves WHERE user_id = $1 AND spent_at >= $2",
          [this.identity, refreshTimestamp]
        );
        const spentIds = new Set(spentResult.rows.map((r) => r.leaf_id));

        // Delete non-reserved leaves added before refresh started.
        // Includes leaves released earlier in this transaction by
        // _cleanupStaleReservations (which now NULLs reservation_id explicitly,
        // since the composite FK uses NO ACTION).
        const deleted = await client.query(
          "DELETE FROM brz_tree_leaves WHERE user_id = $1 AND reservation_id IS NULL AND added_at < $2 RETURNING id",
          [this.identity, refreshTimestamp]
        );

        // Upsert all leaves (filtering spent)
        await this._batchUpsertLeaves(client, leaves, false, spentIds);
        await this._batchUpsertLeaves(client, missingLeaves, true, spentIds);

        // A leaf reported again in this same refresh is re-inserted above, so its
        // ancestor rows must survive: only ids that do NOT reappear (truly gone,
        // e.g. spent) get their ancestor rows dropped alongside them.
        const survivingIds = new Set();
        for (const leaf of leaves.concat(missingLeaves || [])) {
          if (!spentIds.has(leaf.id)) survivingIds.add(leaf.id);
        }
        const goneIds = deleted.rows.map((r) => r.id).filter((id) => !survivingIds.has(id));
        if (goneIds.length > 0) {
          await client.query(
            "DELETE FROM brz_tree_ancestors WHERE user_id = $1 AND leaf_id = ANY($2)",
            [this.identity, goneIds]
          );
        }
      });
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to set leaves: ${error.message}`,
        error
      );
    }
  }

  /**
   * Cancel a reservation. All leaves currently attached to the reservation are
   * deleted from the store. The reservation row is dropped. The supplied
   * `leavesToKeep` are inserted into the available pool.
   *
   * Callers pass the original reservation leaves to preserve the legacy
   * "release everything back to the pool" behavior. Callers that have
   * verified leaf state with the operator pass only the leaves confirmed
   * safe to make available (e.g. dropping operator-locked leaves).
   *
   * @param {string} id - Reservation ID
   * @param {Array} leavesToKeep - Leaves to insert as available
   */
  async cancelReservation(id, leavesToKeep) {
    try {
      await this._withTransaction(async (client) => {
        // Return leavesToKeep to the pool even when the reservation is already
        // gone (e.g. released by stale cleanup): dropping them here would lose
        // the leaves until the next refresh. The deletes no-op in that case.
        // Only the leaves are re-inserted: a kept leaf's ancestor rows stay put
        // (they are not touched below); a dropped leaf's are removed with it.
        const keepIds = new Set((leavesToKeep || []).map((l) => l.id));
        const reservedResult = await client.query(
          "SELECT id FROM brz_tree_leaves WHERE user_id = $1 AND reservation_id = $2",
          [this.identity, id]
        );
        const droppedIds = reservedResult.rows
          .map((r) => r.id)
          .filter((rid) => !keepIds.has(rid));

        await client.query(
          "DELETE FROM brz_tree_leaves WHERE user_id = $1 AND reservation_id = $2",
          [this.identity, id]
        );

        await client.query(
          "DELETE FROM brz_tree_reservations WHERE user_id = $1 AND id = $2",
          [this.identity, id]
        );

        if (droppedIds.length > 0) {
          await client.query(
            "DELETE FROM brz_tree_ancestors WHERE user_id = $1 AND leaf_id = ANY($2)",
            [this.identity, droppedIds]
          );
        }

        if (leavesToKeep && leavesToKeep.length > 0) {
          await this._batchUpsertLeaves(client, leavesToKeep, false, null);
        }
      });
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to cancel reservation '${id}': ${error.message}`,
        error
      );
    }
  }

  /**
   * Finalize a reservation, marking leaves as spent.
   * @param {string} id - Reservation ID
   * @param {Array|null} newLeaves - Optional new leaves to add
   */
  async finalizeReservation(id, newLeaves) {
    try {
      // _withWriteTransaction acquires the advisory lock so this serializes
      // against `setLeaves`. Without it, a concurrent setLeaves could read
      // brz_tree_spent_leaves before our marker commits and re-insert the
      // just-spent leaf as Available.
      await this._withWriteTransaction(async (client) => {
        // Check if reservation exists and get purpose
        const res = await client.query(
          "SELECT id, purpose FROM brz_tree_reservations WHERE user_id = $1 AND id = $2",
          [this.identity, id]
        );

        let isSwap = false;
        let reservedLeafIds = [];
        if (res.rows.length > 0) {
          isSwap = res.rows[0].purpose === "Swap";
          const leafResult = await client.query(
            "SELECT id FROM brz_tree_leaves WHERE user_id = $1 AND reservation_id = $2",
            [this.identity, id]
          );
          reservedLeafIds = leafResult.rows.map((r) => r.id);
          await this._batchInsertSpentLeaves(client, reservedLeafIds);
          await client.query(
            "DELETE FROM brz_tree_leaves WHERE user_id = $1 AND reservation_id = $2",
            [this.identity, id]
          );
          await client.query(
            "DELETE FROM brz_tree_reservations WHERE user_id = $1 AND id = $2",
            [this.identity, id]
          );
          // The spent leaves own these ancestor rows; remove them in the same
          // transaction rather than leaving them to a separate reclaim pass.
          if (reservedLeafIds.length > 0) {
            await client.query(
              "DELETE FROM brz_tree_ancestors WHERE user_id = $1 AND leaf_id = ANY($2)",
              [this.identity, reservedLeafIds]
            );
          }
        }

        // Add new leaves if provided
        if (newLeaves && newLeaves.length > 0) {
          await this._batchUpsertLeaves(client, newLeaves, false, null);
        }

        // If swap with new leaves, update last_completed_at. UPSERT so a tenant
        // that joined after migration 3 (and thus has no row) gets one created.
        if (isSwap && newLeaves && newLeaves.length > 0) {
          await client.query(
            `INSERT INTO brz_tree_swap_status (user_id, last_completed_at)
             VALUES ($1, NOW())
             ON CONFLICT (user_id) DO UPDATE
               SET last_completed_at = EXCLUDED.last_completed_at`,
            [this.identity]
          );
        }
      });
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to finalize reservation '${id}': ${error.message}`,
        error
      );
    }
  }

  /**
   * Try to reserve leaves matching target amounts.
   * @param {Object|null} targetAmounts - Target amounts spec
   * @param {boolean} exactOnly - If true, only exact matches
   * @param {string} purpose - "Payment" or "Swap"
   * @returns {Promise<Object>} ReserveResult
   */
  async tryReserveLeaves(targetAmounts, exactOnly, purpose) {
    try {
      return await this._withWriteTransaction(async (client) => {
        const targetAmount = targetAmounts ? this._totalSats(targetAmounts) : 0;
        const maxTarget = this._maxTargetForPrefilter(targetAmounts);

        // True total available, computed server-side over ALL eligible leaves.
        // Required for the WaitForPending decision below — must NOT be derived
        // from the prefiltered set since the prefilter may exclude big leaves.
        const totalResult = await client.query(
          `
          SELECT COALESCE(SUM(value), 0)::bigint AS total
          FROM brz_tree_leaves
          WHERE user_id = $1
            AND status = 'Available'
            AND is_missing_from_operators = FALSE
            AND reservation_id IS NULL
        `,
          [this.identity]
        );
        const available = Number(totalResult.rows[0].total);

        const slimResult = await client.query(SLIM_LEAF_CANDIDATES_SQL, [
          this.identity,
          maxTarget,
        ]);

        const slimLeaves = slimResult.rows.map((r) => ({
          id: r.id,
          value: Number(r.value),
        }));

        // Calculate pending balance
        const pending = await this._calculatePendingBalance(client);

        // Try exact selection on slim leaves — selection only reads .id/.value
        const selected = this._selectLeavesByTargetAmounts(slimLeaves, targetAmounts);

        if (selected !== null) {
          if (selected.length === 0) {
            throw new TreeStoreError("NonReservableLeaves");
          }

          const fullLeaves = await this._fetchFullLeavesByIds(
            client,
            selected.map((l) => l.id)
          );
          const reservationId = this._generateId();
          await this._createReservation(client, reservationId, fullLeaves, purpose, 0);

          return {
            type: "success",
            reservation: {
              id: reservationId,
              leaves: fullLeaves,
            },
          };
        }

        if (!exactOnly) {
          // Try minimum amount selection on the slim set
          const minSelected = this._selectLeavesByMinimumAmount(slimLeaves, targetAmount);
          if (minSelected !== null) {
            const fullLeaves = await this._fetchFullLeavesByIds(
              client,
              minSelected.map((l) => l.id)
            );
            const reservedAmount = fullLeaves.reduce((sum, l) => sum + l.value, 0);
            const pendingChange = reservedAmount > targetAmount && targetAmount > 0
              ? reservedAmount - targetAmount
              : 0;

            const reservationId = this._generateId();
            await this._createReservation(client, reservationId, fullLeaves, purpose, pendingChange);

            return {
              type: "success",
              reservation: {
                id: reservationId,
                leaves: fullLeaves,
              },
            };
          }
        }

        // No suitable leaves found
        if (available + pending >= targetAmount) {
          return {
            type: "waitForPending",
            needed: targetAmount,
            available,
            pending,
          };
        }

        return { type: "insufficientFunds" };
      });
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to try reserve leaves: ${error.message}`,
        error
      );
    }
  }

  async trySelectLeaves(targetAmounts) {
    try {
      const targetAmount = targetAmounts ? this._totalSats(targetAmounts) : 0;
      const maxTarget = this._maxTargetForPrefilter(targetAmounts);

      return await this._withTransaction(async (client) => {
        const slimResult = await client.query(SLIM_LEAF_CANDIDATES_SQL, [
          this.identity,
          maxTarget,
        ]);

        const slimLeaves = slimResult.rows.map((r) => ({
          id: r.id,
          value: Number(r.value),
        }));

        const selected = this._selectLeavesByTargetAmounts(slimLeaves, targetAmounts);
        if (selected !== null && selected.length > 0) {
          const fullLeaves = await this._fetchFullLeavesByIds(
            client,
            selected.map((l) => l.id)
          );
          return { type: "exact", leaves: fullLeaves };
        }

        const minSelected = this._selectLeavesByMinimumAmount(slimLeaves, targetAmount);
        if (minSelected !== null) {
          const fullLeaves = await this._fetchFullLeavesByIds(
            client,
            minSelected.map((l) => l.id)
          );
          return { type: "swapNeeded", leaves: fullLeaves };
        }

        return { type: "insufficientFunds" };
      });
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to try select leaves: ${error.message}`,
        error
      );
    }
  }

  async tryReserveLeavesByIds(leafIds, purpose) {
    try {
      return await this._withWriteTransaction(async (client) => {
        if (!leafIds || leafIds.length === 0) {
          throw new TreeStoreError("NonReservableLeaves");
        }
        // Every requested leaf must be available and unreserved; otherwise
        // reserve nothing (the transaction rolls back).
        const availableResult = await client.query(
          `
          SELECT id FROM brz_tree_leaves
          WHERE user_id = $1
            AND id = ANY($2)
            AND status = 'Available'
            AND is_missing_from_operators = FALSE
            AND reservation_id IS NULL
        `,
          [this.identity, leafIds]
        );
        if (availableResult.rows.length !== leafIds.length) {
          throw new TreeStoreError("NonReservableLeaves");
        }
        const fullLeaves = await this._fetchFullLeavesByIds(client, leafIds);
        const reservationId = this._generateId();
        await this._createReservation(client, reservationId, fullLeaves, purpose, 0);
        return { id: reservationId, leaves: fullLeaves };
      });
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to try reserve leaves by ids: ${error.message}`,
        error
      );
    }
  }

  _maxTargetForPrefilter(targetAmounts) {
    if (!targetAmounts) return Number.MAX_SAFE_INTEGER;
    if (targetAmounts.type === "amountAndFee") {
      return targetAmounts.amountSats + (targetAmounts.feeSats || 0);
    }
    if (targetAmounts.type === "exactDenominations") {
      return targetAmounts.denominations.reduce((m, v) => m + v, 0);
    }
    return Number.MAX_SAFE_INTEGER;
  }

  /**
   * Pull the full `data` JSON for the leaves the selection algorithm picked.
   * Typically this is 1-3 rows even when the prefiltered set was thousands.
   */
  async _fetchFullLeavesByIds(client, ids) {
    if (!ids || ids.length === 0) return [];
    const result = await client.query(
      "SELECT id, data FROM brz_tree_leaves WHERE user_id = $2 AND id = ANY($1)",
      [ids, this.identity]
    );
    const byId = new Map(result.rows.map((r) => [r.id, r.data]));
    const ordered = ids
      .map((id) => {
        const data = byId.get(id);
        byId.delete(id);
        return data;
      })
      .filter((data) => data !== undefined);
    if (ordered.length !== ids.length) {
      throw new TreeStoreError(
        `Could not resolve full data for all selected leaves (wanted ${ids.length}, got ${ordered.length})`
      );
    }
    return ordered;
  }

  /**
   * Get current database time as epoch milliseconds.
   * @returns {Promise<number>}
   */
  async now() {
    try {
      const result = await this.pool.query("SELECT NOW()");
      return result.rows[0].now.getTime();
    } catch (error) {
      throw new TreeStoreError(
        `Failed to get current time: ${error.message}`,
        error
      );
    }
  }

  /**
   * Update a reservation after a swap.
   * @param {string} reservationId - Existing reservation ID
   * @param {Array} reservedLeaves - New reserved leaves
   * @param {Array} changeLeaves - Change leaves to add to available pool
   * @returns {Promise<Object>} Updated reservation
   */
  async updateReservation(reservationId, reservedLeaves, changeLeaves) {
    try {
      return await this._withTransaction(async (client) => {
        // Check if reservation exists
        const res = await client.query(
          "SELECT id FROM brz_tree_reservations WHERE user_id = $1 AND id = $2",
          [this.identity, reservationId]
        );

        if (res.rows.length === 0) {
          throw new TreeStoreError(`Reservation ${reservationId} not found`);
        }

        // Get old reserved leaf IDs and mark as spent
        const oldLeavesResult = await client.query(
          "SELECT id FROM brz_tree_leaves WHERE user_id = $1 AND reservation_id = $2",
          [this.identity, reservationId]
        );
        const oldLeafIds = oldLeavesResult.rows.map((r) => r.id);

        await this._batchInsertSpentLeaves(client, oldLeafIds);
        await client.query(
          "DELETE FROM brz_tree_leaves WHERE user_id = $1 AND reservation_id = $2",
          [this.identity, reservationId]
        );
        // The spent leaves own these ancestor rows; remove them now since there
        // is no later reclaim pass.
        if (oldLeafIds.length > 0) {
          await client.query(
            "DELETE FROM brz_tree_ancestors WHERE user_id = $1 AND leaf_id = ANY($2)",
            [this.identity, oldLeafIds]
          );
        }

        // Upsert change leaves to available pool
        await this._batchUpsertLeaves(client, changeLeaves, false, null);

        // Upsert reserved leaves
        await this._batchUpsertLeaves(client, reservedLeaves, false, null);

        // Set reservation_id on reserved leaves
        const reservedLeafIds = reservedLeaves.map((l) => l.id);
        await this._batchSetReservationId(client, reservationId, reservedLeafIds);

        // Clear pending change amount
        await client.query(
          "UPDATE brz_tree_reservations SET pending_change_amount = 0 WHERE user_id = $1 AND id = $2",
          [this.identity, reservationId]
        );

        // Return value must be plain TreeNodes: the Rust side deserializes
        // Vec<TreeNode>.
        return {
          id: reservationId,
          leaves: reservedLeaves,
        };
      });
    } catch (error) {
      if (error instanceof TreeStoreError) throw error;
      throw new TreeStoreError(
        `Failed to update reservation '${reservationId}': ${error.message}`,
        error
      );
    }
  }

  // ===== Private Helpers =====

  /**
   * Generate a unique reservation ID (UUIDv4).
   */
  _generateId() {
    // Use crypto.randomUUID if available, otherwise manual
    if (typeof crypto !== "undefined" && crypto.randomUUID) {
      return crypto.randomUUID();
    }
    // Fallback UUIDv4
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  /**
   * Calculate total sats from target amounts.
   */
  _totalSats(targetAmounts) {
    if (targetAmounts.type === "amountAndFee") {
      return targetAmounts.amountSats + (targetAmounts.feeSats || 0);
    }
    if (targetAmounts.type === "exactDenominations") {
      return targetAmounts.denominations.reduce((sum, d) => sum + d, 0);
    }
    return 0;
  }

  /**
   * Select leaves by target amounts. Returns null if no exact match found.
   */
  _selectLeavesByTargetAmounts(leaves, targetAmounts) {
    if (!targetAmounts) {
      // No target: return all leaves (may be empty)
      return [...leaves];
    }

    if (targetAmounts.type === "amountAndFee") {
      const amountLeaves = this._selectLeavesByExactAmount(leaves, targetAmounts.amountSats);
      if (amountLeaves === null) return null;

      if (targetAmounts.feeSats != null && targetAmounts.feeSats > 0) {
        const amountIds = new Set(amountLeaves.map((l) => l.id));
        const remaining = leaves.filter((l) => !amountIds.has(l.id));
        const feeLeaves = this._selectLeavesByExactAmount(remaining, targetAmounts.feeSats);
        if (feeLeaves === null) return null;
        return [...amountLeaves, ...feeLeaves];
      }

      return amountLeaves;
    }

    if (targetAmounts.type === "exactDenominations") {
      return this._selectLeavesByExactDenominations(leaves, targetAmounts.denominations);
    }

    return null;
  }

  /**
   * Select leaves that sum to exactly the target amount.
   */
  _selectLeavesByExactAmount(leaves, targetAmount) {
    if (targetAmount === 0) return null; // Invalid amount

    const totalAvailable = leaves.reduce((sum, l) => sum + l.value, 0);
    if (totalAvailable < targetAmount) return null; // Insufficient funds

    // Try single exact match
    const single = leaves.find((l) => l.value === targetAmount);
    if (single) return [single];

    // Try greedy multiple match
    const multipleResult = this._findExactMultipleMatch(leaves, targetAmount);
    return multipleResult;
  }

  /**
   * Select leaves that match exact denominations.
   */
  _selectLeavesByExactDenominations(leaves, denominations) {
    const remaining = [...leaves];
    const selected = [];

    for (const denomination of denominations) {
      const idx = remaining.findIndex((l) => l.value === denomination);
      if (idx === -1) return null; // Can't match this denomination
      selected.push(remaining[idx]);
      remaining.splice(idx, 1);
    }

    return selected;
  }

  /**
   * Select leaves summing to at least the target amount.
   */
  _selectLeavesByMinimumAmount(leaves, targetAmount) {
    if (targetAmount === 0) return null;

    const totalAvailable = leaves.reduce((sum, l) => sum + l.value, 0);
    if (totalAvailable < targetAmount) return null;

    const result = [];
    let sum = 0;
    for (const leaf of leaves) {
      sum += leaf.value;
      result.push(leaf);
      if (sum >= targetAmount) break;
    }

    return sum >= targetAmount ? result : null;
  }

  /**
   * Find exact multiple match using greedy algorithm.
   */
  _findExactMultipleMatch(leaves, targetAmount) {
    if (targetAmount === 0) return [];
    if (leaves.length === 0) return null;

    // Pass 1: Try greedy on all leaves
    const result = this._greedyExactMatch(leaves, targetAmount);
    if (result) return result;

    // Pass 2: Try with only power-of-two leaves
    const powerOfTwoLeaves = leaves.filter((l) => this._isPowerOfTwo(l.value));
    if (powerOfTwoLeaves.length === leaves.length) return null;

    return this._greedyExactMatch(powerOfTwoLeaves, targetAmount);
  }

  /**
   * Greedy exact match algorithm.
   */
  _greedyExactMatch(leaves, targetAmount) {
    const sorted = [...leaves].sort((a, b) => b.value - a.value);
    const result = [];
    let remaining = targetAmount;

    for (const leaf of sorted) {
      if (leaf.value > remaining) continue;
      remaining -= leaf.value;
      result.push(leaf);
      if (remaining === 0) return result;
    }

    return null;
  }

  /**
   * Check if value is a power of two.
   */
  _isPowerOfTwo(value) {
    return value > 0 && (value & (value - 1)) === 0;
  }

  /**
   * Calculate pending balance from in-flight swaps.
   */
  async _calculatePendingBalance(client) {
    const result = await client.query(
      "SELECT COALESCE(SUM(pending_change_amount), 0)::BIGINT AS pending FROM brz_tree_reservations WHERE user_id = $1",
      [this.identity]
    );
    return Number(result.rows[0].pending);
  }

  /**
   * Create a reservation with the given leaves.
   */
  async _createReservation(client, reservationId, leaves, purpose, pendingChange) {
    await client.query(
      "INSERT INTO brz_tree_reservations (user_id, id, purpose, pending_change_amount) VALUES ($1, $2, $3, $4)",
      [this.identity, reservationId, purpose, pendingChange]
    );

    const leafIds = leaves.map((l) => l.id);
    await this._batchSetReservationId(client, reservationId, leafIds);
  }

  /**
   * Batch upsert leaves into brz_tree_leaves table.
   */
  async _batchUpsertLeaves(client, leaves, isMissingFromOperators, skipIds) {
    if (!leaves || leaves.length === 0) return;

    const leafNodes = skipIds
      ? leaves.filter((l) => !skipIds.has(l.id))
      : leaves;

    if (leafNodes.length === 0) return;


    // All chunks run inside the caller's transaction, and NOW() is the
    // transaction timestamp, so every row still lands atomically with one
    // shared added_at.
    for (let i = 0; i < leafNodes.length; i += LEAF_UPSERT_CHUNK_SIZE) {
      const chunk = leafNodes.slice(i, i + LEAF_UPSERT_CHUNK_SIZE);
      const ids = chunk.map((l) => l.id);
      const statuses = chunk.map((l) => l.status);
      const missingFlags = chunk.map(() => isMissingFromOperators);
      const dataValues = chunk.map((l) => JSON.stringify(l));
      const values = chunk.map((l) => l.value);
      const parents = chunk.map((l) => l.parent_node_id ?? null);
      const verifyings = chunk.map((l) => l.verifying_public_key);
      const signings = chunk.map((l) => l.signing_keyshare.public_key);

      await client.query(
        `INSERT INTO brz_tree_leaves
             (user_id, id, status, is_missing_from_operators, data, added_at,
              value, parent_node_id, verifying_public_key, signing_public_key)
         SELECT $5, id, status, missing, data::jsonb, NOW(),
                value, parent_node_id, verifying, signing
         FROM UNNEST($1::text[], $2::text[], $3::bool[], $4::text[],
                     $6::bigint[], $7::text[], $8::text[], $9::text[])
             AS t(id, status, missing, data, value, parent_node_id, verifying, signing)
         ON CONFLICT (user_id, id) DO UPDATE SET
           status = EXCLUDED.status,
           is_missing_from_operators = EXCLUDED.is_missing_from_operators,
           data = EXCLUDED.data,
           added_at = NOW(),
           value = EXCLUDED.value,
           parent_node_id = EXCLUDED.parent_node_id,
           verifying_public_key = EXCLUDED.verifying_public_key,
           signing_public_key = EXCLUDED.signing_public_key`,
        [
          ids,
          statuses,
          missingFlags,
          dataValues,
          this.identity,
          values,
          parents,
          verifyings,
          signings,
        ]
      );
    }
  }

  /**
   * Replaces the ancestor rows of every pedigree wholesale (delete then
   * insert), in two statements however many leaves there are. A pedigree
   * carrying no ancestors is skipped: an empty list means the chain is unknown,
   * not that the leaf has none, so a stored chain must survive being re-added
   * without one.
   */
  async _batchUpsertAncestors(client, pedigrees) {
    const withAncestors = (pedigrees || []).filter(
      (p) => p.ancestors && p.ancestors.length > 0
    );
    if (withAncestors.length === 0) return;

    await client.query(
      "DELETE FROM brz_tree_ancestors WHERE user_id = $1 AND leaf_id = ANY($2)",
      [this.identity, withAncestors.map((p) => p.leaf.id)]
    );

    const leafIds = [];
    const ids = [];
    const parents = [];
    const statuses = [];
    const dataValues = [];
    const values = [];
    const verifyings = [];
    for (const pedigree of withAncestors) {
      for (const node of pedigree.ancestors) {
        leafIds.push(pedigree.leaf.id);
        ids.push(node.id);
        parents.push(node.parent_node_id ?? null);
        statuses.push(node.status);
        dataValues.push(JSON.stringify(node));
        values.push(node.value);
        verifyings.push(node.verifying_public_key);
      }
    }

    await client.query(
      `INSERT INTO brz_tree_ancestors
           (user_id, leaf_id, id, parent_node_id, status, data, value, verifying_public_key)
       SELECT $1, leaf_id, id, parent_node_id, status, data::jsonb, value, verifying
       FROM UNNEST($2::text[], $3::text[], $4::text[], $5::text[], $6::text[],
                   $7::bigint[], $8::text[])
           AS t(leaf_id, id, parent_node_id, status, data, value, verifying)`,
      [
        this.identity,
        leafIds,
        ids,
        parents,
        statuses,
        dataValues,
        values,
        verifyings,
      ]
    );
  }

  /**
   * Batch set reservation_id on leaves.
   */
  async _batchSetReservationId(client, reservationId, leafIds) {
    if (leafIds.length === 0) return;

    await client.query(
      "UPDATE brz_tree_leaves SET reservation_id = $1 WHERE user_id = $3 AND id = ANY($2)",
      [reservationId, leafIds, this.identity]
    );
  }

  /**
   * Batch insert spent leaf markers.
   */
  async _batchInsertSpentLeaves(client, leafIds) {
    if (leafIds.length === 0) return;

    await client.query(
      `INSERT INTO brz_tree_spent_leaves (user_id, leaf_id)
       SELECT $2, leaf_id FROM UNNEST($1::text[]) AS t(leaf_id)
       ON CONFLICT DO NOTHING`,
      [leafIds, this.identity]
    );
  }

  /**
   * Batch remove spent leaf markers.
   */
  async _batchRemoveSpentLeaves(client, leafIds) {
    if (leafIds.length === 0) return;

    await client.query(
      "DELETE FROM brz_tree_spent_leaves WHERE user_id = $2 AND leaf_id = ANY($1)",
      [leafIds, this.identity]
    );
  }

  /**
   * Clean up stale reservations. Releases the leaves by clearing their
   * reservation_id first, then deletes the parent reservations — the composite
   * FK uses NO ACTION (the default) since column-list SET NULL is PG15+ and a
   * whole-row SET NULL would null user_id (NOT NULL).
   */
  async _cleanupStaleReservations(client) {
    await client.query(
      `UPDATE brz_tree_leaves SET reservation_id = NULL
       WHERE user_id = $2
         AND reservation_id IN (
           SELECT id FROM brz_tree_reservations
           WHERE user_id = $2
             AND created_at < NOW() - make_interval(secs => $1)
         )`,
      [RESERVATION_TIMEOUT_SECS, this.identity]
    );
    await client.query(
      `DELETE FROM brz_tree_reservations
       WHERE user_id = $2
         AND created_at < NOW() - make_interval(secs => $1)`,
      [RESERVATION_TIMEOUT_SECS, this.identity]
    );
  }

  /**
   * Clean up old spent markers.
   */
  async _cleanupSpentMarkers(client, refreshTimestamp) {
    const thresholdMs = SPENT_MARKER_CLEANUP_THRESHOLD_MS;
    const cleanupCutoff = new Date(refreshTimestamp.getTime() - thresholdMs);

    await client.query(
      "DELETE FROM brz_tree_spent_leaves WHERE user_id = $2 AND spent_at < $1",
      [cleanupCutoff, this.identity]
    );
  }
}

/**
 * Translates the `sslmode` URI parameter into pg's `ssl` option.
 * The pinned `pg` maps `require` to verified TLS but warns that pg v9 reverts
 * it to libpq semantics (no verification); handling `sslmode` here keeps the
 * documented guarantees stable across driver versions. The parameter (and the
 * `ssl`/`sslcert`/`sslkey`/`sslrootcert` parameters folded into the option)
 * are stripped from the URI because a connection string's ssl settings
 * override the explicit option.
 *
 * Spellings mirror the Rust SDK where pg has an equivalent:
 * - absent or `disable`: no TLS
 * - `prefer` / `require` / `verify-full`: TLS with certificate chain and
 *   hostname verification (pg cannot fall back to plaintext, so `prefer`
 *   behaves like `require`)
 * - `verify-ca`: chain verification only, hostname not checked
 * - `no-verify`: TLS without certificate verification (explicit opt-in)
 *
 * An unrecognized value throws rather than silently changing the TLS level.
 * Pin a private CA with `sslrootcert=<path>` (required for `verify-ca`); for
 * the hostname-verified modes, adding the CA to Node's trust store
 * (e.g. NODE_EXTRA_CA_CERTS) also works, though it extends the store rather
 * than pinning.
 */
function extractSslMode(connectionString) {
  if (
    !connectionString.startsWith("postgres://") &&
    !connectionString.startsWith("postgresql://")
  ) {
    return { connectionString, ssl: undefined };
  }
  const queryIndex = connectionString.indexOf("?");
  if (queryIndex === -1) {
    return { connectionString, ssl: undefined };
  }
  const params = connectionString.slice(queryIndex + 1).split("&");
  if (!params.some((param) => param.startsWith("sslmode="))) {
    return { connectionString, ssl: undefined };
  }

  const base = connectionString.slice(0, queryIndex);
  const retained = [];
  const files = {};
  let sslMode;
  for (const param of params) {
    const eq = param.indexOf("=");
    const key = eq === -1 ? param : param.slice(0, eq);
    const value = eq === -1 ? "" : decodeURIComponent(param.slice(eq + 1));
    if (key === "sslmode") {
      sslMode = value;
    } else if (key === "sslcert" || key === "sslkey" || key === "sslrootcert") {
      files[key] = value;
    } else if (key === "ssl") {
      // consumed: sslmode governs TLS when present
    } else {
      retained.push(param);
    }
  }
  const rebuilt = retained.length ? `${base}?${retained.join("&")}` : base;
  return { connectionString: rebuilt, ssl: sslOptionForMode(sslMode, files) };
}

function sslOptionForMode(mode, files) {
  let ssl;
  switch (mode) {
    case "disable":
      return false;
    case "prefer":
    case "require":
    case "verify-full":
      ssl = { rejectUnauthorized: true };
      break;
    case "verify-ca":
      // Without a pinned CA, chain-only verification accepts a certificate
      // from any trusted CA for any host, which authenticates nothing.
      if (!files.sslrootcert) {
        throw new TreeStoreError(
          "sslmode=verify-ca requires sslrootcert=<path>; supply the CA to " +
            "pin, or use sslmode=require / verify-full for " +
            "hostname-verified TLS"
        );
      }
      ssl = { rejectUnauthorized: true, checkServerIdentity: () => undefined };
      break;
    case "no-verify":
      ssl = { rejectUnauthorized: false };
      break;
    default:
      throw new TreeStoreError(
        `Unrecognized sslmode value \`${mode}\`; expected one of: ` +
          "disable, prefer, require, verify-ca, verify-full, no-verify"
      );
  }
  const fs =
    files.sslcert || files.sslkey || files.sslrootcert ? require("fs") : null;
  if (files.sslcert) {
    ssl.cert = fs.readFileSync(files.sslcert).toString();
  }
  if (files.sslkey) {
    ssl.key = fs.readFileSync(files.sslkey).toString();
  }
  if (files.sslrootcert) {
    ssl.ca = fs.readFileSync(files.sslrootcert).toString();
  }
  return ssl;
}

/**
 * Create a PostgresTreeStore instance from a config object.
 *
 * @param {object} config - PostgreSQL configuration
 * @param {string} config.connectionString - PostgreSQL connection string
 * @param {number} config.maxPoolSize - Maximum number of connections in the pool
 * @param {number} config.createTimeoutSecs - Timeout in seconds for establishing a new connection
 * @param {number} config.recycleTimeoutSecs - Timeout in seconds before recycling an idle connection
 * @param {Buffer|Uint8Array} identity - 33-byte secp256k1 compressed pubkey scoping reads/writes
 * @param {object} [logger] - Optional logger
 * @returns {Promise<PostgresTreeStore>}
 */
async function createPostgresTreeStore(config, identity, logger = null) {
  const { connectionString, ssl } = extractSslMode(config.connectionString);
  const pool = new pg.Pool({
    connectionString,
    ...(ssl !== undefined && { ssl }),
    max: config.maxPoolSize,
    connectionTimeoutMillis: config.createTimeoutSecs * 1000,
    idleTimeoutMillis: config.recycleTimeoutSecs * 1000,
  });
  return createPostgresTreeStoreWithPool(
    pool,
    identity,
    logger,
    config.runMigration !== false
  );
}

/**
 * Create a PostgresTreeStore instance from an existing pg.Pool.
 *
 * @param {pg.Pool} pool - An existing connection pool
 * @param {Buffer|Uint8Array} identity - 33-byte secp256k1 compressed pubkey scoping reads/writes
 * @param {object} [logger] - Optional logger
 * @returns {Promise<PostgresTreeStore>}
 */
async function createPostgresTreeStoreWithPool(
  pool,
  identity,
  logger = null,
  runMigration = true
) {
  const store = new PostgresTreeStore(
    pool,
    identity,
    logger,
    runMigration
  );
  await store.initialize();
  return store;
}

module.exports = { PostgresTreeStore, createPostgresTreeStore, createPostgresTreeStoreWithPool, TreeStoreError };
