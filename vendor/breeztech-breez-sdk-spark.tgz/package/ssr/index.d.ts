export * from "../web/breez_sdk_spark_wasm.js";
export default function init(wasmInput?: any): Promise<void>;
