// SSR-safe entry point for Breez SDK
// Safe to import during server-side rendering: no WASM, no browser APIs, no Node.js APIs.
// Call init() on the client before using any SDK functions.

let _module = null;
let _initPromise = null;

function _notInitialized(name) {
  throw new Error(
    `@breeztech/breez-sdk-spark: "${name}" called before init(). ` +
    `Call "await init()" on the client before using SDK functions.`
  );
}

export default async function init(wasmInput) {
  if (_module) return;
  if (_initPromise) return _initPromise;
  _initPromise = (async () => {
    const mod = await import('../web/index.js');
    await mod.default(wasmInput);
    _module = mod;
  })();
  return _initPromise;
}

export function connect(...args) {
  if (!_module) _notInitialized('connect');
  return _module.connect(...args);
}

export function connectWithSigner(...args) {
  if (!_module) _notInitialized('connectWithSigner');
  return _module.connectWithSigner(...args);
}

export function connectWithSigningOnlySigner(...args) {
  if (!_module) _notInitialized('connectWithSigningOnlySigner');
  return _module.connectWithSigningOnlySigner(...args);
}

export function createTurnkeySigner(...args) {
  if (!_module) _notInitialized('createTurnkeySigner');
  return _module.createTurnkeySigner(...args);
}

export function createTurnkeySigningOnlySigner(...args) {
  if (!_module) _notInitialized('createTurnkeySigningOnlySigner');
  return _module.createTurnkeySigningOnlySigner(...args);
}

export function defaultConfig(...args) {
  if (!_module) _notInitialized('defaultConfig');
  return _module.defaultConfig(...args);
}

export function defaultExternalSigners(...args) {
  if (!_module) _notInitialized('defaultExternalSigners');
  return _module.defaultExternalSigners(...args);
}

export function defaultMysqlStorageConfig(...args) {
  if (!_module) _notInitialized('defaultMysqlStorageConfig');
  return _module.defaultMysqlStorageConfig(...args);
}

export function defaultPostgresStorageConfig(...args) {
  if (!_module) _notInitialized('defaultPostgresStorageConfig');
  return _module.defaultPostgresStorageConfig(...args);
}

export function defaultServerConfig(...args) {
  if (!_module) _notInitialized('defaultServerConfig');
  return _module.defaultServerConfig(...args);
}

export function defaultSessionStore(...args) {
  if (!_module) _notInitialized('defaultSessionStore');
  return _module.defaultSessionStore(...args);
}

export function defaultStorage(...args) {
  if (!_module) _notInitialized('defaultStorage');
  return _module.defaultStorage(...args);
}

export function getSparkStatus(...args) {
  if (!_module) _notInitialized('getSparkStatus');
  return _module.getSparkStatus(...args);
}

export function initLogging(...args) {
  if (!_module) _notInitialized('initLogging');
  return _module.initLogging(...args);
}

export function mysqlStorage(...args) {
  if (!_module) _notInitialized('mysqlStorage');
  return _module.mysqlStorage(...args);
}

export function newRestChainService(...args) {
  if (!_module) _notInitialized('newRestChainService');
  return _module.newRestChainService(...args);
}

export function newSharedSdkContext(...args) {
  if (!_module) _notInitialized('newSharedSdkContext');
  return _module.newSharedSdkContext(...args);
}

export function postgresStorage(...args) {
  if (!_module) _notInitialized('postgresStorage');
  return _module.postgresStorage(...args);
}

export function start(...args) {
  if (!_module) _notInitialized('start');
  return _module.start(...args);
}

export function task_worker_entry_point(...args) {
  if (!_module) _notInitialized('task_worker_entry_point');
  return _module.task_worker_entry_point(...args);
}

export function initSync(...args) {
  if (!_module) _notInitialized('initSync');
  return _module.initSync(...args);
}

export class BitcoinChainServiceHandle {
  constructor(...args) {
    if (!_module) _notInitialized('new BitcoinChainServiceHandle');
    return new _module.BitcoinChainServiceHandle(...args);
  }
}

export class BreezSdk {
  constructor(...args) {
    if (!_module) _notInitialized('new BreezSdk');
    return new _module.BreezSdk(...args);
  }
}

export class DefaultSessionStore {
  constructor(...args) {
    if (!_module) _notInitialized('new DefaultSessionStore');
    return new _module.DefaultSessionStore(...args);
  }
}

export class ExternalBreezSignerHandle {
  constructor(...args) {
    if (!_module) _notInitialized('new ExternalBreezSignerHandle');
    return new _module.ExternalBreezSignerHandle(...args);
  }
}

export class ExternalSigners {
  constructor(...args) {
    if (!_module) _notInitialized('new ExternalSigners');
    return new _module.ExternalSigners(...args);
  }
}

export class ExternalSigningSignerHandle {
  constructor(...args) {
    if (!_module) _notInitialized('new ExternalSigningSignerHandle');
    return new _module.ExternalSigningSignerHandle(...args);
  }
}

export class ExternalSparkSignerHandle {
  constructor(...args) {
    if (!_module) _notInitialized('new ExternalSparkSignerHandle');
    return new _module.ExternalSparkSignerHandle(...args);
  }
}

export class IntoUnderlyingByteSource {
  constructor(...args) {
    if (!_module) _notInitialized('new IntoUnderlyingByteSource');
    return new _module.IntoUnderlyingByteSource(...args);
  }
}

export class IntoUnderlyingSink {
  constructor(...args) {
    if (!_module) _notInitialized('new IntoUnderlyingSink');
    return new _module.IntoUnderlyingSink(...args);
  }
}

export class IntoUnderlyingSource {
  constructor(...args) {
    if (!_module) _notInitialized('new IntoUnderlyingSource');
    return new _module.IntoUnderlyingSource(...args);
  }
}

export class PasskeyClient {
  constructor(...args) {
    if (!_module) _notInitialized('new PasskeyClient');
    return new _module.PasskeyClient(...args);
  }
}

export class PasskeyLabels {
  constructor(...args) {
    if (!_module) _notInitialized('new PasskeyLabels');
    return new _module.PasskeyLabels(...args);
  }
}

export class SdkBuilder {
  constructor(...args) {
    if (!_module) _notInitialized('new SdkBuilder');
    return new _module.SdkBuilder(...args);
  }
}

export class SigningOnlyExternalSigners {
  constructor(...args) {
    if (!_module) _notInitialized('new SigningOnlyExternalSigners');
    return new _module.SigningOnlyExternalSigners(...args);
  }
}

export class TokenIssuer {
  constructor(...args) {
    if (!_module) _notInitialized('new TokenIssuer');
    return new _module.TokenIssuer(...args);
  }
}

export class WasmSdkContext {
  constructor(...args) {
    if (!_module) _notInitialized('new WasmSdkContext');
    return new _module.WasmSdkContext(...args);
  }
}

export class WasmStorageConfig {
  constructor(...args) {
    if (!_module) _notInitialized('new WasmStorageConfig');
    return new _module.WasmStorageConfig(...args);
  }
}

