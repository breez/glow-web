/* tslint:disable */
/* eslint-disable */
/**
 * The `ReadableStreamType` enum.
 *
 * *This API requires the following crate features to be activated: `ReadableStreamType`*
 */

type ReadableStreamType = "bytes";

/** Serialized tree node. Key fields used by store implementations: id, status, value. */
interface TreeNode {
    id: string;
    tree_id: string;
    value: number;
    status: string;
    [key: string]: unknown;
}

interface Leaves {
    available: TreeNode[];
    notAvailable: TreeNode[];
    availableMissingFromOperators: TreeNode[];
    reservedForPayment: TreeNode[];
    reservedForSwap: TreeNode[];
}

interface LeavesReservation {
    id: string;
    leaves: TreeNode[];
}

type TargetAmounts =
| { type: 'amountAndFee'; amountSats: number; feeSats: number | null }
| { type: 'exactDenominations'; denominations: number[] };

type ReserveResult =
| { type: 'success'; reservation: LeavesReservation }
| { type: 'insufficientFunds' }
| { type: 'waitForPending'; needed: number; available: number; pending: number };

type LeafSelection =
| { type: 'exact'; leaves: TreeNode[] }
| { type: 'swapNeeded'; leaves: TreeNode[] }
| { type: 'insufficientFunds' };

export interface TreeStore {
    addLeaves: (leaves: TreeNode[]) => Promise<void>;
    getLeaves: () => Promise<Leaves>;
    getAvailableBalance: () => Promise<bigint>;
    setLeaves: (leaves: TreeNode[], missingLeaves: TreeNode[], refreshStartedAtMs: number) => Promise<void>;
    cancelReservation: (id: string, leavesToKeep: TreeNode[]) => Promise<void>;
    finalizeReservation: (id: string, newLeaves: TreeNode[] | null) => Promise<void>;
    tryReserveLeaves: (targetAmounts: TargetAmounts | null, exactOnly: boolean, purpose: string) => Promise<ReserveResult>;
    now: () => Promise<number>;
    updateReservation: (reservationId: string, reservedLeaves: TreeNode[], changeLeaves: TreeNode[]) => Promise<LeavesReservation>;
    tryReserveLeavesByIds: (leafIds: string[], purpose: string) => Promise<LeavesReservation>;
    trySelectLeaves: (targetAmounts: TargetAmounts | null) => Promise<LeafSelection>;
}


interface WasmTokenMetadata {
    identifier: string;
    issuerPublicKey: string;
    name: string;
    ticker: string;
    decimals: number;
    maxSupply: string;
    isFreezable: boolean;
    creationEntityPublicKey: string | null;
}

interface WasmTokenOutput {
    id: string;
    ownerPublicKey: string;
    revocationCommitment: string;
    withdrawBondSats: number;
    withdrawRelativeBlockLocktime: number;
    tokenPublicKey: string | null;
    tokenIdentifier: string;
    tokenAmount: string;
}

interface WasmTokenOutputWithPrevOut {
    output: WasmTokenOutput;
    prevTxHash: string;
    prevTxVout: number;
}

interface WasmTokenOutputs {
    metadata: WasmTokenMetadata;
    outputs: WasmTokenOutputWithPrevOut[];
}

interface WasmTokenOutputsPerStatus {
    metadata: WasmTokenMetadata;
    available: WasmTokenOutputWithPrevOut[];
    reservedForPayment: WasmTokenOutputWithPrevOut[];
    reservedForSwap: WasmTokenOutputWithPrevOut[];
}

interface WasmTokenOutputsReservation {
    id: string;
    tokenOutputs: WasmTokenOutputs;
}

interface WasmTokenBalance {
    metadata: WasmTokenMetadata;
    balance: string;
}

type WasmGetTokenOutputsFilter =
| { type: 'identifier'; identifier: string }
| { type: 'issuerPublicKey'; issuerPublicKey: string };

type WasmReservationTarget =
| { type: 'minTotalValue'; value: string }
| { type: 'maxOutputCount'; value: number };

export interface TokenStore {
    setTokensOutputs: (tokenOutputs: WasmTokenOutputs[], refreshStartedAtMs: number) => Promise<void>;
    listTokensOutputs: () => Promise<WasmTokenOutputsPerStatus[]>;
    getTokenBalances: () => Promise<WasmTokenBalance[]>;
    getTokenOutputs: (filter: WasmGetTokenOutputsFilter) => Promise<WasmTokenOutputsPerStatus>;
    updateTokenOutputs: (outputsToRemove: [string, number][], outputsToAdd: WasmTokenOutputs | null) => Promise<void>;
    reserveTokenOutputs: (
    tokenIdentifier: string,
    target: WasmReservationTarget,
    purpose: string,
    preferredOutputs: WasmTokenOutputWithPrevOut[] | null,
    selectionStrategy: string | null
    ) => Promise<WasmTokenOutputsReservation>;
    selectTokenOutputs: (
    tokenIdentifier: string,
    target: WasmReservationTarget,
    preferredOutputs: WasmTokenOutputWithPrevOut[] | null,
    selectionStrategy: string | null
    ) => Promise<WasmTokenOutputs>;
    reserveTokenOutputsByOutpoints: (
    tokenIdentifier: string,
    outpoints: { prevTxHash: string; prevTxVout: number }[],
    purpose: string
    ) => Promise<WasmTokenOutputsReservation>;
    cancelReservation: (id: string) => Promise<void>;
    finalizeReservation: (id: string) => Promise<void>;
    now: () => Promise<number>;
}

/**
 * A passkey credential from `register` or `signIn`. `credentialId` is
 * always set. The attestation fields (`userId`, `aaguid`,
 * `backupEligible`) are populated on registration and null on sign-in
 * (an assertion carries no attestation). AAGUID is unverified: a
 * display hint only, never a trust signal.
 */
export interface PasskeyCredential {
    credentialId: Uint8Array;
    userId?: Uint8Array;
    aaguid?: Uint8Array;
    backupEligible?: boolean;
}

/**
 * A wallet derived from a passkey.
 */
export interface Wallet {
    /**
     * The derived seed.
     */
    seed: Seed;
    /**
     * The label used for derivation.
     */
    label: string;
}

/**
 * Configuration for MySQL storage connection pool. Targets MySQL 8.0+.
 */
export interface MysqlStorageConfig {
    /**
     * MySQL connection URL (e.g. `mysql://user:pass@host:3306/dbname`).
     */
    connectionString: string;
    /**
     * Maximum number of connections in the pool.
     */
    maxPoolSize: number;
    /**
     * Timeout in seconds for establishing a new connection (0 = no timeout).
     */
    createTimeoutSecs: number;
    /**
     * Timeout in seconds before recycling an idle connection.
     */
    recycleTimeoutSecs: number;
    /**
     * Whether the SDK should run schema migrations on startup. Set to
     * `false` when the embedding service owns and migrates the database
     * schema. Defaults to `true`.
     */
    runMigration?: boolean;
    /**
     * Whether migrations should create database-enforced foreign keys.
     *
     * Use `Disabled` for environments that manage relationships in
     * application code and require schema changes without foreign-key
     * constraints.
     */
    foreignKeyMode?: MysqlForeignKeyMode;
}

/**
 * Configuration for PostgreSQL storage connection pool.
 */
export interface PostgresStorageConfig {
    /**
     * PostgreSQL connection string (URI format).
     */
    connectionString: string;
    /**
     * Maximum number of connections in the pool.
     */
    maxPoolSize: number;
    /**
     * Timeout in seconds for establishing a new connection (0 = no timeout).
     */
    createTimeoutSecs: number;
    /**
     * Timeout in seconds before recycling an idle connection.
     */
    recycleTimeoutSecs: number;
    /**
     * Whether the SDK should run schema migrations on startup. Set to
     * `false` when the embedding service owns and migrates the database
     * schema. Defaults to `true`.
     */
    runMigration?: boolean;
}

/**
 * Configuration for `PasskeyClient`.
 */
export interface PasskeyConfig {
    /**
     * Wallet label for `register` / `signIn` when no label is given.
     * Unset falls back to the internal default `\"Default\"`.
     */
    defaultLabel?: string;
    /**
     * Relying Party and user identity for the built-in provider on the
     * zero-config path.
     */
    providerOptions?: PasskeyProviderOptions;
}

/**
 * Controls whether MySQL migrations create database-enforced foreign keys.
 */
export type MysqlForeignKeyMode = "Enforced" | "Disabled";

/**
 * Interface for PRF (Pseudo-Random Function) operations backing seedless
 * wallet restore.
 *
 * Implemented by the built-in `PasskeyProvider` (browser passkey via the
 * WebAuthn PRF extension); also implementable directly for custom
 * deterministic sources (YubiKey HMAC challenge, FIDO2 hmac-secret, on-disk
 * key material, hardware HSMs).
 */
export interface PrfProvider {
    /**
     * Derive 32-byte PRF outputs for one or more salts, in input order.
     * Implementations with bulk capability (WebAuthn dual-salt via
     * `prf.eval.first` + `prf.eval.second`) pack two salts per ceremony
     * where supported; others loop the single-salt path. `options` carries
     * per-call ceremony shapers that built-in providers forward to the OS
     * call and custom providers may ignore.
     *
     * @param salts - Salt strings in caller order
     * @param options - Optional per-call overrides
     * @returns Promise of the 32-byte outputs in input order plus the
     *   credential ID observed in the same assertion (`null` when the
     *   provider surfaces none, e.g. sources without an OS picker)
     */
    deriveSeeds(salts: string[], options?: DeriveSeedOptions): Promise<DeriveSeedsResult>;

    /**
     * Optional explicit registration. Platform passkey providers (browser
     * WebAuthn, iOS / Android) implement this to drive the OS create
     * ceremony and return credential metadata (`credentialId`, `userId`,
     * optional `aaguid` / `backupEligible`) callers need for
     * `excludeCredentials` bookkeeping and server-side correlation. Custom
     * providers without a creation step can omit it.
     *
     * `excludeCredentials` lists already-registered IDs; a match raises
     * `PasskeyAlreadyExistsError`.
     *
     * @throws `PasskeyAlreadyExistsError` when an entry in
     *   `excludeCredentials` matches a credential already on the device.
     */
    createPasskey?(excludeCredentials: Uint8Array[]): Promise<PasskeyCredential>;

    /**
     * Whether this provider can produce PRF outputs on the current
     * device. Hosts gate UX on the result.
     */
    isSupported(): Promise<boolean>;
}

/**
 * Per-call options passed as the second argument of
 * {@link PrfProvider.deriveSeeds}.
 */
export interface DeriveSeedOptions {
    /**
     * Credential IDs the assertion is restricted to, for reauthenticating
     * a known user without an account picker. Empty or unset lets the
     * provider's default apply.
     */
    allowCredentials?: Uint8Array[];
    /**
     * Fast-fail when no local credential is available. On the web this maps
     * to WebAuthn `mediation: 'immediate'`: `true` opts in where the browser
     * advertises support, `false` uses the standard picker. Unset uses the
     * provider default.
     */
    preferImmediatelyAvailableCredentials?: boolean;
}

/**
 * Returned by {@link PrfProvider.deriveSeeds}: the derived 32-byte outputs
 * in input order plus the credential ID observed in the same assertion.
 * `credentialId` is `null` when the provider does not surface one (custom
 * deterministic sources without an OS picker).
 */
export interface DeriveSeedsResult {
    seeds: Uint8Array[];
    credentialId?: Uint8Array | null;
}

/**
 * One-shot capability + configuration probe returned by
 * `PasskeyClient.checkAvailability`. Collapses `isSupported` +
 * `checkDomainAssociation` into one tagged value hosts branch on.
 */
export type PasskeyAvailability = { type: "available" } | { type: "prfUnsupported" } | { type: "notAssociated"; source: string; reason: string } | { type: "skipped"; reason: string };

/**
 * Relying Party and user identity for the built-in provider on the
 * zero-config path (ignored when you inject your own provider).
 */
export interface PasskeyProviderOptions {
    /**
     * Relying Party ID. Unset uses the Breez shared RP.
     */
    rpId?: string;
    /**
     * Relying Party name. Unset uses the SDK default (`\"Breez\"`).
     */
    rpName?: string;
    /**
     * `user.name`: the account identifier the picker shows beneath the
     * display name (e.g. `john@doe.com`). Unset uses `rpName`.
     */
    userName?: string;
    /**
     * `user.displayName`: the human-friendly name shown most
     * prominently (e.g. `John Doe`). Unset uses `userName`.
     */
    userDisplayName?: string;
}

/**
 * Request shape for `PasskeyClient.register`.
 */
export interface RegisterRequest {
    label?: string;
    excludeCredentials?: Uint8Array[];
}

/**
 * Request shape for `PasskeyClient.signIn`.
 */
export interface SignInRequest {
    label?: string;
    allowCredentials?: Uint8Array[];
    preferImmediatelyAvailableCredentials?: boolean;
}

/**
 * Response shape for `PasskeyClient.register`.
 */
export interface RegisterResponse {
    wallet: Wallet;
    credential?: PasskeyCredential;
}

/**
 * Response shape for `PasskeyClient.signIn`.
 */
export interface SignInResponse {
    wallet: Wallet;
    labels: string[];
    credential?: PasskeyCredential;
}

/**
 * Settings for `newSharedSdkContext`. `network` is required; all other
 * fields are optional.
 */
export interface WasmSdkContextConfig {
    /**
     * Network the shared resources target. Used to gate the partner JWT
     * header provider — only constructed on Mainnet.
     */
    network: Network;
    /**
     * Breez API key. When set together with `network == Mainnet`, the
     * context constructs a shared partner JWT header provider that all
     * SDKs built from this context will attach to their SO requests.
     */
    apiKey?: string;
    /**
     * Number of gRPC connections per Spark operator. `None` (or `Some(1)`)
     * keeps a single connection per operator (right for most deployments);
     * `Some(n)` opens `n` channels per operator and balances requests.
     */
    connectionsPerOperator?: number;
    /**
     * PostgreSQL backend configuration. When set, SDKs constructed with
     * this context store their data in PostgreSQL via the shared pool.
     */
    postgresConfig?: PostgresStorageConfig;
    /**
     * MySQL backend configuration. When set, SDKs constructed with this
     * context store their data in MySQL via the shared pool.
     */
    mysqlConfig?: MysqlStorageConfig;
}

export interface AddContactRequest {
    name: string;
    paymentIdentifier: string;
}

export interface AesSuccessActionData {
    description: string;
    ciphertext: string;
    iv: string;
}

export interface AesSuccessActionDataDecrypted {
    description: string;
    plaintext: string;
}

export interface AuthorizeTransferRequest {
    transfereePubkey: string;
}

export interface Bip21Details {
    amountSat?: number;
    assetId?: string;
    uri: string;
    extras: Bip21Extra[];
    label?: string;
    message?: string;
    paymentMethods: InputType[];
}

export interface Bip21Extra {
    key: string;
    value: string;
}

export interface BitcoinAddressDetails {
    address: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface BitcoinChainService {
    getAddressUtxos(address: string): Promise<Utxo[]>;
    getTransactionStatus(txid: string): Promise<TxStatus>;
    getTransactionHex(txid: string): Promise<string>;
    broadcastTransaction(tx: string): Promise<void>;
    recommendedFees(): Promise<RecommendedFees>;
}

export interface Bolt11Invoice {
    bolt11: string;
    source: PaymentRequestSource;
}

export interface Bolt11InvoiceDetails {
    amountMsat?: number;
    description?: string;
    descriptionHash?: string;
    expiry: number;
    invoice: Bolt11Invoice;
    minFinalCltvExpiryDelta: number;
    network: BitcoinNetwork;
    payeePubkey: string;
    paymentHash: string;
    paymentSecret: string;
    routingHints: Bolt11RouteHint[];
    timestamp: number;
}

export interface Bolt11RouteHint {
    hops: Bolt11RouteHintHop[];
}

export interface Bolt11RouteHintHop {
    srcNodeId: string;
    shortChannelId: string;
    feesBaseMsat: number;
    feesProportionalMillionths: number;
    cltvExpiryDelta: number;
    htlcMinimumMsat?: number;
    htlcMaximumMsat?: number;
}

export interface Bolt12Invoice {
    invoice: string;
    source: PaymentRequestSource;
}

export interface Bolt12InvoiceDetails {
    amountMsat: number;
    invoice: Bolt12Invoice;
}

export interface Bolt12InvoiceRequestDetails {}

export interface Bolt12Offer {
    offer: string;
    source: PaymentRequestSource;
}

export interface Bolt12OfferBlindedPath {
    blindedHops: string[];
}

export interface Bolt12OfferDetails {
    absoluteExpiry?: number;
    chains: string[];
    description?: string;
    issuer?: string;
    minAmount?: Amount;
    offer: Bolt12Offer;
    paths: Bolt12OfferBlindedPath[];
    signingPubkey?: string;
}

export interface BuildUnsignedLnurlPayPackageRequest {
    prepareResponse: PrepareLnurlPayResponse;
}

export interface BuildUnsignedTransferPackageRequest {
    prepareResponse: PrepareSendPaymentResponse;
    options?: BuildTransferPackageOptions;
}

export interface BurnIssuerTokenRequest {
    amount: bigint;
}

export interface BuyBitcoinResponse {
    url: string;
}

export interface CheckLightningAddressRequest {
    username: string;
}

export interface CheckMessageRequest {
    message: string;
    pubkey: string;
    signature: string;
}

export interface CheckMessageResponse {
    isValid: boolean;
}

export interface ClaimDepositRequest {
    txid: string;
    vout: number;
    maxFee?: MaxFee;
}

export interface ClaimDepositResponse {
    payment: Payment;
}

export interface ClaimHtlcPaymentRequest {
    preimage: string;
}

export interface ClaimHtlcPaymentResponse {
    payment: Payment;
}

export interface ClaimTransferRequest {
    authorization: TransferAuthorization;
    description?: string;
}

export interface Config {
    apiKey?: string;
    network: Network;
    syncIntervalSecs: number;
    maxDepositClaimFee?: MaxFee;
    lnurlDomain?: string;
    preferSparkOverLightning: boolean;
    externalInputParsers?: ExternalInputParser[];
    useDefaultExternalInputParsers: boolean;
    realTimeSyncServerUrl?: string;
    privateEnabledDefault: boolean;
    leafOptimizationConfig: LeafOptimizationConfig;
    tokenOptimizationConfig: TokenOptimizationConfig;
    stableBalanceConfig?: StableBalanceConfig;
    /**
     * Maximum number of concurrent transfer claims.
     *
     * Controls how many pending Spark transfers can be claimed in parallel.
     * Default is 4. Increase for server environments with high incoming
     * payment volume to improve throughput.
     */
    maxConcurrentClaims: number;
    sparkConfig?: SparkConfig;
    backgroundTasksEnabled: boolean;
    crossChainConfig?: CrossChainConfig;
}

export interface ConnectRequest {
    config: Config;
    seed: Seed;
    storageDir: string;
}

export interface Contact {
    id: string;
    name: string;
    paymentIdentifier: string;
    createdAt: number;
    updatedAt: number;
}

export interface Conversion {
    provider: ConversionProvider;
    status: ConversionStatus;
    from: ConversionSide;
    to: ConversionSide;
    amountAdjustment?: AmountAdjustmentReason;
}

export interface ConversionAsset {
    ticker: string;
    identifier?: string;
    decimals: number;
}

export interface ConversionDetails {
    status: ConversionStatus;
    conversions?: Conversion[];
}

export interface ConversionEstimate {
    options: ConversionOptions;
    amountIn: bigint;
    amountOut: bigint;
    fee: bigint;
    amountAdjustment?: AmountAdjustmentReason;
}

export interface ConversionOptions {
    conversionType: ConversionType;
    maxSlippageBps?: number;
    completionTimeoutSecs?: number;
}

export interface ConversionSide {
    chain: ConversionChain;
    asset: ConversionAsset;
    amount: string;
    fee: string;
}

export interface CreateIssuerTokenRequest {
    name: string;
    ticker: string;
    decimals: number;
    isFreezable: boolean;
    maxSupply: bigint;
}

export interface Credentials {
    username: string;
    password: string;
}

export interface CrossChainAddressDetails {
    address: string;
    addressFamily: CrossChainAddressFamily;
    contractAddress?: string;
    chainId?: number;
    amount?: bigint;
}

export interface CrossChainConfig {
    defaultSlippageBps?: number;
    defaultTargetOverpayBps?: number;
}

export interface CrossChainRoutePair {
    provider: CrossChainProvider;
    chain: string;
    chainId?: string;
    asset: string;
    contractAddress?: string;
    decimals: number;
    exactOutEligible: boolean;
    supportedSources: SourceAsset[];
}

export interface CurrencyInfo {
    name: string;
    fractionSize: number;
    spacing?: number;
    symbol?: Symbol;
    uniqSymbol?: Symbol;
    localizedName: LocalizedName[];
    localeOverrides: LocaleOverrides[];
}

export interface DepositInfo {
    txid: string;
    vout: number;
    amountSats: number;
    isMature: boolean;
    refundTx?: string;
    refundTxId?: string;
    claimError?: DepositClaimError;
}

export interface EcdsaSignatureBytes {
    bytes: number[];
}

export interface EventListener {
    onEvent: (e: SdkEvent) => void;
}

export interface ExternalBreezSigner {
    derivePublicKey(path: string): Promise<PublicKeyBytes>;
    signEcdsa(message: MessageBytes, path: string): Promise<EcdsaSignatureBytes>;
    signEcdsaRecoverable(message: MessageBytes, path: string): Promise<RecoverableEcdsaSignatureBytes>;
    encryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    decryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    signHashSchnorr(hash: Uint8Array, path: string): Promise<SchnorrSignatureBytes>;
    hmacSha256(message: Uint8Array, path: string): Promise<HashedMessageBytes>;
}

export interface ExternalClaimLeafInput {
    nodeId: ExternalTreeNodeId;
    senderSignature: number[];
    leafKeyCiphertext: number[];
}

export interface ExternalFrostCommitments {
    hidingCommitment: number[];
    bindingCommitment: number[];
    noncesCiphertext: number[];
}

export interface ExternalFrostJob {
    derivation: ExternalFrostDerivation;
    sighash: number[];
    verifyingKey: number[];
    operatorCommitments: IdentifierCommitmentPair[];
    adaptorPublicKey?: number[];
}

export interface ExternalFrostShareResult {
    commitment: ExternalFrostCommitments;
    signatureShare: ExternalFrostSignatureShare;
}

export interface ExternalFrostSignature {
    bytes: number[];
}

export interface ExternalFrostSignatureShare {
    bytes: number[];
}

export interface ExternalIdentifier {
    bytes: number[];
}

export interface ExternalInputParser {
    providerId: string;
    inputRegex: string;
    parserUrl: string;
}

export interface ExternalNewLeafKey {
    nodeId: ExternalTreeNodeId;
    newSigningPublicKey: number[];
}

export interface ExternalOperatorPackage {
    operatorIdentifier: ExternalIdentifier;
    encryptedPackage: number[];
}

export interface ExternalOperatorRecipient {
    id: number;
    identifier: ExternalIdentifier;
    publicKey: number[];
}

export interface ExternalPrepareClaimRequest {
    transferId: string;
    senderIdentityPublicKey: number[];
    leaves: ExternalClaimLeafInput[];
    operatorRecipients: ExternalOperatorRecipient[];
    threshold: number;
}

export interface ExternalPrepareLightningReceiveRequest {
    operatorRecipients: ExternalOperatorRecipient[];
    threshold: number;
}

export interface ExternalPrepareStaticDepositClaimRequest {
    index: number;
    userStatement: number[];
}

export interface ExternalPrepareStaticDepositRequest {
    index: number;
    sspPublicKey: number[];
    frostJobs: ExternalFrostJob[];
}

export interface ExternalPrepareTokenTransactionRequest {
    kind: ExternalTokenTransactionKind;
    digest: number[];
}

export interface ExternalPrepareTransferRequest {
    transferId: string;
    receiverPublicKey: number[];
    leaves: ExternalTransferLeafInput[];
    operatorRecipients: ExternalOperatorRecipient[];
    threshold: number;
}

export interface ExternalPreparedClaim {
    operatorPackages: ExternalOperatorPackage[];
}

export interface ExternalPreparedLightningReceive {
    paymentHash: number[];
    operatorPreimagePackages: ExternalOperatorPackage[];
}

export interface ExternalPreparedStaticDeposit {
    exportedSecret: number[];
    frostShares: ExternalFrostShareResult[];
}

export interface ExternalPreparedStaticDepositClaim {
    depositSecretKey: SecretBytes;
    userSignature: EcdsaSignatureBytes;
}

export interface ExternalPreparedTokenTransaction {
    signature: SchnorrSignatureBytes;
}

export interface ExternalPreparedTransfer {
    operatorPackages: ExternalOperatorPackage[];
    newLeafKeys: ExternalNewLeafKey[];
    transferUserSignature: EcdsaSignatureBytes;
}

export interface ExternalSignSparkInvoiceRequest {
    kind: ExternalSparkInvoiceKind;
    invoiceHash: number[];
}

export interface ExternalSignStaticDepositRefundRequest {
    index: number;
    sighash: number[];
    verifyingKey: number[];
    nonceCommitment: ExternalFrostCommitments;
    statechainCommitments: IdentifierCommitmentPair[];
    statechainSignatures: IdentifierSignaturePair[];
    statechainPublicKeys: IdentifierPublicKeyPair[];
}

export interface ExternalSignedSparkInvoice {
    signature: SchnorrSignatureBytes;
}

export interface ExternalSigningCommitments {
    hiding: number[];
    binding: number[];
}

export interface ExternalSigningSigner {
    derivePublicKey(path: string): Promise<PublicKeyBytes>;
    signEcdsa(message: MessageBytes, path: string): Promise<EcdsaSignatureBytes>;
    signEcdsaRecoverable(message: MessageBytes, path: string): Promise<RecoverableEcdsaSignatureBytes>;
    signHashSchnorr(hash: Uint8Array, path: string): Promise<SchnorrSignatureBytes>;
}

export interface ExternalSparkSigner {
    getIdentityPublicKey(): Promise<PublicKeyBytes>;
    getPublicKeyForLeaf(leafId: ExternalTreeNodeId): Promise<PublicKeyBytes>;
    getStaticDepositPublicKey(index: number): Promise<PublicKeyBytes>;
    signAuthenticationChallenge(challenge: Uint8Array): Promise<EcdsaSignatureBytes>;
    signMessage(message: Uint8Array): Promise<EcdsaSignatureBytes>;
    signFrost(jobs: ExternalFrostJob[]): Promise<ExternalFrostShareResult[]>;
    prepareTransfer(request: ExternalPrepareTransferRequest): Promise<ExternalPreparedTransfer>;
    prepareClaim(request: ExternalPrepareClaimRequest): Promise<ExternalPreparedClaim>;
    prepareLightningReceive(request: ExternalPrepareLightningReceiveRequest): Promise<ExternalPreparedLightningReceive>;
    prepareStaticDeposit(request: ExternalPrepareStaticDepositRequest): Promise<ExternalPreparedStaticDeposit>;
    startStaticDepositRefund(request: ExternalStartStaticDepositRefundRequest): Promise<ExternalStartedStaticDepositRefund>;
    signStaticDepositRefund(request: ExternalSignStaticDepositRefundRequest): Promise<ExternalFrostSignature>;
    signSparkInvoice(request: ExternalSignSparkInvoiceRequest): Promise<ExternalSignedSparkInvoice>;
    prepareTokenTransaction(request: ExternalPrepareTokenTransactionRequest): Promise<ExternalPreparedTokenTransaction>;
    prepareStaticDepositClaim(request: ExternalPrepareStaticDepositClaimRequest): Promise<ExternalPreparedStaticDepositClaim>;
}

export interface ExternalStartStaticDepositRefundRequest {
    index: number;
    userStatement: number[];
}

export interface ExternalStartedStaticDepositRefund {
    signingPublicKey: number[];
    nonceCommitment: ExternalFrostCommitments;
    userSignature: EcdsaSignatureBytes;
}

export interface ExternalTransferLeafInput {
    nodeId: ExternalTreeNodeId;
    newLeafId: ExternalTreeNodeId;
}

export interface ExternalTreeNodeId {
    id: string;
}

export interface FetchConversionLimitsRequest {
    conversionType: ConversionType;
    tokenIdentifier?: string;
}

export interface FetchConversionLimitsResponse {
    minFromAmount?: bigint;
    minToAmount?: bigint;
}

export interface FiatCurrency {
    id: string;
    info: CurrencyInfo;
}

export interface FiatService {
    fetchFiatCurrencies(): Promise<FiatCurrency[]>;
    fetchFiatRates(): Promise<Rate[]>;
}

export interface FreezeIssuerTokenRequest {
    address: string;
}

export interface FreezeIssuerTokenResponse {
    impactedOutputIds: string[];
    impactedTokenAmount: bigint;
}

export interface GetInfoRequest {
    ensureSynced?: boolean;
}

export interface GetInfoResponse {
    identityPubkey: string;
    balanceSats: number;
    tokenBalances: Map<string, TokenBalance>;
}

export interface GetPaymentRequest {
    paymentId: string;
}

export interface GetPaymentResponse {
    payment: Payment;
}

export interface GetTokensMetadataRequest {
    tokenIdentifiers: string[];
}

export interface GetTokensMetadataResponse {
    tokensMetadata: TokenMetadata[];
}

export interface HashedMessageBytes {
    bytes: number[];
}

export interface IdentifierCommitmentPair {
    identifier: ExternalIdentifier;
    commitment: ExternalSigningCommitments;
}

export interface IdentifierPublicKeyPair {
    identifier: ExternalIdentifier;
    publicKey: number[];
}

export interface IdentifierSignaturePair {
    identifier: ExternalIdentifier;
    signature: ExternalFrostSignatureShare;
}

export interface IncomingChange {
    newState: Record;
    oldState?: Record;
}

export interface LeafOptimizationConfig {
    autoEnabled: boolean;
    multiplicity: number;
}

export interface LightningAddressDetails {
    address: string;
    payRequest: LnurlPayRequestDetails;
}

export interface LightningAddressInfo {
    description: string;
    lightningAddress: string;
    lnurl: LnurlInfo;
    username: string;
}

export interface ListContactsRequest {
    offset?: number;
    limit?: number;
}

export interface ListFiatCurrenciesResponse {
    currencies: FiatCurrency[];
}

export interface ListFiatRatesResponse {
    rates: Rate[];
}

export interface ListPaymentsRequest {
    typeFilter?: PaymentType[];
    statusFilter?: PaymentStatus[];
    assetFilter?: AssetFilter;
    paymentDetailsFilter?: PaymentDetailsFilter[];
    fromTimestamp?: number;
    toTimestamp?: number;
    offset?: number;
    limit?: number;
    sortAscending?: boolean;
}

export interface ListPaymentsResponse {
    payments: Payment[];
}

export interface ListUnclaimedDepositsRequest {}

export interface ListUnclaimedDepositsResponse {
    deposits: DepositInfo[];
}

export interface LnurlAuthRequestDetails {
    k1: string;
    action?: string;
    domain: string;
    url: string;
}

export interface LnurlErrorDetails {
    reason: string;
}

export interface LnurlInfo {
    url: string;
    bech32: string;
}

export interface LnurlPayContext {
    payRequest: LnurlPayRequestDetails;
    comment?: string;
    successAction?: SuccessAction;
}

export interface LnurlPayInfo {
    lnAddress?: string;
    comment?: string;
    domain?: string;
    metadata?: string;
    processedSuccessAction?: SuccessActionProcessed;
    rawSuccessAction?: SuccessAction;
}

export interface LnurlPayRequest {
    prepareResponse: PrepareLnurlPayResponse;
    idempotencyKey?: string;
}

export interface LnurlPayRequestDetails {
    callback: string;
    minSendable: number;
    maxSendable: number;
    metadataStr: string;
    commentAllowed: number;
    domain: string;
    url: string;
    address?: string;
    allowsNostr?: boolean;
    nostrPubkey?: string;
}

export interface LnurlPayResponse {
    payment: Payment;
    successAction?: SuccessActionProcessed;
}

export interface LnurlReceiveMetadata {
    nostrZapRequest?: string;
    nostrZapReceipt?: string;
    senderComment?: string;
}

export interface LnurlWithdrawInfo {
    withdrawUrl: string;
}

export interface LnurlWithdrawRequest {
    amountSats: number;
    withdrawRequest: LnurlWithdrawRequestDetails;
    completionTimeoutSecs?: number;
}

export interface LnurlWithdrawRequestDetails {
    callback: string;
    k1: string;
    defaultDescription: string;
    minWithdrawable: number;
    maxWithdrawable: number;
}

export interface LnurlWithdrawResponse {
    paymentRequest: string;
    payment?: Payment;
}

export interface LocaleOverrides {
    locale: string;
    spacing?: number;
    symbol: Symbol;
}

export interface LocalizedName {
    locale: string;
    name: string;
}

export interface LogEntry {
    line: string;
    level: string;
}

export interface Logger {
    log: (l: LogEntry) => void;
}

export interface MessageBytes {
    bytes: number[];
}

export interface MessageSuccessActionData {
    message: string;
}

export interface MintIssuerTokenRequest {
    amount: bigint;
}

export interface OptimizeLeavesRequest {
    mode: OptimizationMode;
}

export interface OptimizeLeavesResponse {
    outcome: OptimizationOutcome;
}

export interface OutgoingChange {
    change: RecordChange;
    parent?: Record;
}

export interface Payment {
    id: string;
    paymentType: PaymentType;
    status: PaymentStatus;
    amount: bigint;
    fees: bigint;
    timestamp: number;
    method: PaymentMethod;
    details?: PaymentDetails;
    conversionDetails?: ConversionDetails;
}

export interface PaymentIdUpdate {
    provisionalPaymentId: string;
    finalPaymentId: string;
}

export interface PaymentMetadata {
    parentPaymentId?: string;
    lnurlPayInfo?: LnurlPayInfo;
    lnurlWithdrawInfo?: LnurlWithdrawInfo;
    lnurlDescription?: string;
    conversionInfo?: ConversionInfo;
    conversionStatus?: ConversionStatus;
}

export interface PaymentObserver {
    beforeSend: (payments: ProvisionalPayment[]) => Promise<void>;
    afterSend: (updates: PaymentIdUpdate[]) => Promise<void>;
}

export interface PaymentRequestSource {
    bip21Uri?: string;
    bip353Address?: string;
}

export interface PrepareLnurlPayRequest {
    amount: bigint;
    comment?: string;
    payRequest: LnurlPayRequestDetails;
    validateSuccessActionUrl?: boolean;
    tokenIdentifier?: string;
    conversionOptions?: ConversionOptions;
    feePolicy?: FeePolicy;
}

export interface PrepareLnurlPayResponse {
    amountSats: number;
    comment?: string;
    payRequest: LnurlPayRequestDetails;
    feeSats: number;
    invoiceDetails: Bolt11InvoiceDetails;
    successAction?: SuccessAction;
    conversionEstimate?: ConversionEstimate;
    feePolicy: FeePolicy;
}

export interface PrepareSendPaymentRequest {
    paymentRequest: PaymentRequest;
    amount?: bigint;
    tokenIdentifier?: string;
    conversionOptions?: ConversionOptions;
    feePolicy?: FeePolicy;
}

export interface PrepareSendPaymentResponse {
    paymentMethod: SendPaymentMethod;
    amount: bigint;
    tokenIdentifier?: string;
    conversionEstimate?: ConversionEstimate;
    feePolicy: FeePolicy;
}

export interface ProvisionalPayment {
    paymentId: string;
    amount: bigint;
    details: ProvisionalPaymentDetails;
}

export interface PublicKeyBytes {
    bytes: number[];
}

export interface PublishSignedLnurlPayPackageRequest {
    signedPackage: SignedTransferPackage;
}

export interface PublishSignedTransferPackageRequest {
    signedPackage: SignedTransferPackage;
}

export interface Rate {
    coin: string;
    value: number;
}

export interface ReceivePaymentRequest {
    paymentMethod: ReceivePaymentMethod;
}

export interface ReceivePaymentResponse {
    paymentRequest: string;
    fee: bigint;
}

export interface RecommendedFees {
    fastestFee: number;
    halfHourFee: number;
    hourFee: number;
    economyFee: number;
    minimumFee: number;
}

export interface Record {
    id: RecordId;
    revision: number;
    schemaVersion: string;
    data: Map<string, string>;
}

export interface RecordChange {
    id: RecordId;
    schemaVersion: string;
    updatedFields: Map<string, string>;
    localRevision: number;
}

export interface RecordId {
    type: string;
    dataId: string;
}

export interface RecoverableEcdsaSignatureBytes {
    bytes: number[];
}

export interface RefundDepositRequest {
    txid: string;
    vout: number;
    destinationAddress: string;
    fee: Fee;
}

export interface RefundDepositResponse {
    txId: string;
    txHex: string;
}

export interface RegisterLightningAddressRequest {
    username: string;
    description?: string;
}

export interface RegisterWebhookRequest {
    url: string;
    secret: string;
    eventTypes: WebhookEventType[];
}

export interface RegisterWebhookResponse {
    webhookId: string;
}

export interface RestClient {
    getRequest(url: string, headers?: Record<string, string>): Promise<RestResponse>;
    postRequest(url: string, headers?: Record<string, string>, body?: string): Promise<RestResponse>;
    deleteRequest(url: string, headers?: Record<string, string>, body?: string): Promise<RestResponse>;
}

export interface RestResponse {
    status: number;
    body: string;
}

export interface SchnorrSignatureBytes {
    bytes: number[];
}

export interface SecretBytes {
    bytes: number[];
}

export interface SendOnchainFeeQuote {
    id: string;
    expiresAt: number;
    speedFast: SendOnchainSpeedFeeQuote;
    speedMedium: SendOnchainSpeedFeeQuote;
    speedSlow: SendOnchainSpeedFeeQuote;
}

export interface SendOnchainSpeedFeeQuote {
    userFeeSat: number;
    l1BroadcastFeeSat: number;
}

export interface SendPaymentRequest {
    prepareResponse: PrepareSendPaymentResponse;
    options?: SendPaymentOptions;
    idempotencyKey?: string;
}

export interface SendPaymentResponse {
    payment: Payment;
}

export interface Session {
    token: string;
    expiration: number;
}

export interface SessionStore {
    getSession: (serviceIdentityKey: string) => Promise<Session>;
    setSession: (serviceIdentityKey: string, session: Session) => Promise<void>;
}

export interface SetLnurlMetadataItem {
    paymentHash: string;
    senderComment?: string;
    nostrZapRequest?: string;
    nostrZapReceipt?: string;
}

export interface SignMessageRequest {
    message: string;
    compact: boolean;
}

export interface SignMessageResponse {
    pubkey: string;
    signature: string;
}

export interface SignedTransferPackage {
    unsigned: UnsignedTransferPackage;
    signature: TransferSignature;
}

export interface SilentPaymentAddressDetails {
    address: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface SparkAddressDetails {
    address: string;
    identityPublicKey: string;
    network: BitcoinNetwork;
    source: PaymentRequestSource;
}

export interface SparkConfig {
    coordinatorIdentifier: string;
    threshold: number;
    signingOperators: SparkSigningOperator[];
    sspConfig: SparkSspConfig;
    expectedWithdrawBondSats: number;
    expectedWithdrawRelativeBlockLocktime: number;
    maxTokenTransactionInputs?: number;
}

export interface SparkHtlcDetails {
    paymentHash: string;
    preimage?: string;
    expiryTime: number;
    status: SparkHtlcStatus;
}

export interface SparkHtlcOptions {
    paymentHash: string;
    expiryDurationSecs: number;
}

export interface SparkInvoiceDetails {
    invoice: string;
    identityPublicKey: string;
    network: BitcoinNetwork;
    amount?: string;
    tokenIdentifier?: string;
    expiryTime?: number;
    description?: string;
    senderPublicKey?: string;
}

export interface SparkInvoicePaymentDetails {
    description?: string;
    invoice: string;
}

export interface SparkSigningOperator {
    id: number;
    identifier: string;
    address: string;
    identityPublicKey: string;
    caCertPem?: string;
}

export interface SparkSspConfig {
    baseUrl: string;
    identityPublicKey: string;
    schemaEndpoint?: string;
}

export interface SparkStatus {
    status: ServiceStatus;
    lastUpdated: number;
}

export interface StableBalanceConfig {
    tokens: StableBalanceToken[];
    defaultActiveLabel?: string;
    thresholdSats?: number;
    maxSlippageBps?: number;
}

export interface StableBalanceToken {
    label: string;
    tokenIdentifier: string;
}

export interface Storage {
    getCachedItem: (key: string) => Promise<string | null>;
    setCachedItem: (key: string, value: string) => Promise<void>;
    deleteCachedItem: (key: string) => Promise<void>;
    listPayments: (request: StorageListPaymentsRequest) => Promise<Payment[]>;
    /**
     * Insert or update a payment, applying a terminal-status guard.
     *
     * Returns `true` when the caller should emit a payment event (the row was
     * newly inserted, or its status transitioned). Returns `false` for
     * redundant same-status updates and for rejected updates that would
     * replace an already-terminal status.
     */
    applyPaymentUpdate: (payment: Payment) => Promise<boolean>;
    insertPaymentMetadata: (paymentId: string, metadata: PaymentMetadata) => Promise<void>;
    getPaymentById: (id: string) => Promise<Payment>;
    getPaymentByInvoice: (invoice: string) => Promise<Payment>;
    addDeposit: (txid: string, vout: number, amount_sats: number, isMature: boolean) => Promise<void>;
    deleteDeposit: (txid: string, vout: number) => Promise<void>;
    listDeposits: () => Promise<DepositInfo[]>;
    updateDeposit: (txid: string, vout: number, payload: UpdateDepositPayload) => Promise<void>;
    setLnurlMetadata: (metadata: SetLnurlMetadataItem[]) => Promise<void>;
    getPaymentsByParentIds: (parentPaymentIds: string[]) => Promise<{ [parentId: string]: RelatedPayment[] }>;
    listContacts: (request: ListContactsRequest) => Promise<Contact[]>;
    getContact: (id: string) => Promise<Contact>;
    insertContact: (contact: Contact) => Promise<void>;
    deleteContact: (id: string) => Promise<void>;
    setCrossChainSwap: (swap: StoredCrossChainSwap) => Promise<void>;
    getCrossChainSwap: (provider: string, id: string) => Promise<StoredCrossChainSwap | null>;
    listActiveCrossChainSwaps: (provider: string) => Promise<StoredCrossChainSwap[]>;
    syncAddOutgoingChange: (record: UnversionedRecordChange) => Promise<number>;
    syncCompleteOutgoingSync: (record: Record) => Promise<void>;
    syncGetPendingOutgoingChanges: (limit: number) => Promise<OutgoingChange[]>;
    syncGetLastRevision: () => Promise<number>;
    syncInsertIncomingRecords: (records: Record[]) => Promise<void>;
    syncDeleteIncomingRecord: (record: Record) => Promise<void>;
    syncGetIncomingRecords: (limit: number) => Promise<IncomingChange[]>;
    syncGetLatestOutgoingChange: () => Promise<OutgoingChange | null>;
    syncUpdateRecordFromIncoming: (record: Record) => Promise<void>;
}

export interface StorageListPaymentsRequest {
    typeFilter?: PaymentType[];
    statusFilter?: PaymentStatus[];
    assetFilter?: AssetFilter;
    paymentDetailsFilter?: StoragePaymentDetailsFilter[];
    fromTimestamp?: number;
    toTimestamp?: number;
    offset?: number;
    limit?: number;
    sortAscending?: boolean;
}

export interface StoredCrossChainSwap {
    provider: string;
    id: string;
    isTerminal: boolean;
    updatedAt: number;
    data: string;
    secrets: string;
}

export interface Symbol {
    grapheme?: string;
    template?: string;
    rtl?: boolean;
    position?: number;
}

export interface SyncWalletRequest {}

export interface SyncWalletResponse {}

export interface TokenBalance {
    balance: bigint;
    tokenMetadata: TokenMetadata;
}

export interface TokenMetadata {
    identifier: string;
    issuerPublicKey: string;
    name: string;
    ticker: string;
    decimals: number;
    maxSupply: string;
    isFreezable: boolean;
}

export interface TokenOptimizationConfig {
    autoEnabled: boolean;
    targetOutputCount: number;
    minOutputsThreshold: number;
}

export interface TransferAuthorization {
    username: string;
    pubkey: string;
    signature: string;
}

export interface TurnkeyConfig {
    baseUrl?: string;
    organizationId: string;
    apiPublicKey: string;
    apiPrivateKey: string;
    walletId: string;
    network: Network;
    accountNumber?: number;
    retry?: TurnkeyRetryConfig;
}

export interface TurnkeyRetryConfig {
    initialDelayMs: number;
    multiplier: number;
    maxDelayMs: number;
    maxRetries: number;
    requestTimeoutMs: number;
}

export interface TxStatus {
    confirmed: boolean;
    blockHeight?: number;
    blockTime?: number;
}

export interface UnfreezeIssuerTokenRequest {
    address: string;
}

export interface UnfreezeIssuerTokenResponse {
    impactedOutputIds: string[];
    impactedTokenAmount: bigint;
}

export interface UnregisterWebhookRequest {
    webhookId: string;
}

export interface UnversionedRecordChange {
    id: RecordId;
    schemaVersion: string;
    updatedFields: Map<string, string>;
}

export interface UpdateContactRequest {
    id: string;
    name: string;
    paymentIdentifier: string;
}

export interface UpdateUserSettingsRequest {
    sparkPrivateModeEnabled?: boolean;
    stableBalanceActiveLabel?: StableBalanceActiveLabel;
}

export interface UrlSuccessActionData {
    description: string;
    url: string;
    matchesCallbackDomain: boolean;
}

export interface UserSettings {
    sparkPrivateModeEnabled: boolean;
    stableBalanceActiveLabel?: string;
}

export interface Utxo {
    txid: string;
    vout: number;
    value: number;
    status: TxStatus;
}

export interface Webhook {
    id: string;
    url: string;
    eventTypes: WebhookEventType[];
}

export type AesSuccessActionDataResult = { type: "decrypted"; data: AesSuccessActionDataDecrypted } | { type: "errorStatus"; reason: string };

export type Amount = { type: "bitcoin"; amountMsat: number } | { type: "currency"; iso4217Code: string; fractionalAmount: number };

export type AmountAdjustmentReason = "flooredToMinLimit" | "increasedToAvoidDust";

export type AssetFilter = { type: "bitcoin" } | { type: "token"; tokenIdentifier?: string };

export type AutoOptimizationEvent = { type: "started"; totalRounds: number } | { type: "roundCompleted"; currentRound: number; totalRounds: number } | { type: "completed" } | { type: "cancelled" } | { type: "failed"; error: string } | { type: "skipped" };

export type BitcoinNetwork = "bitcoin" | "testnet3" | "testnet4" | "signet" | "regtest";

export type BuildTransferPackageOptions = { type: "bitcoinAddress"; confirmationSpeed: OnchainConfirmationSpeed } | { type: "bolt11Invoice"; preferSpark: boolean; completionTimeoutSecs?: number };

export type BuyBitcoinRequest = { type: "moonpay"; lockedAmountSat?: number; redirectUrl?: string } | { type: "cashApp"; amountSats: number };

export type ChainApiType = "esplora" | "mempoolSpace";

export type ConversionChain = { type: "spark" } | { type: "lightning" } | { type: "external"; name: string; chainId?: string };

export type ConversionFilter = "ammRefundNeeded" | "orchestraPending" | "boltzPending";

export type ConversionInfo = { type: "amm"; poolId: string; conversionId: string; status: ConversionStatus; fee?: string; purpose?: ConversionPurpose; amountAdjustment?: AmountAdjustmentReason } | { type: "orchestra"; chain: string; chainId?: string; asset?: string; assetContract?: string; recipientAddress: string; assetAmountIn?: string; estimatedOut: string; deliveredAmount?: string; status: ConversionStatus; feeAmount?: string; serviceFeeAmount?: string; serviceFeeAsset?: string; assetDecimals: number; orderId: string; quoteId: string; readToken?: string } | { type: "boltz"; chain: string; chainId?: string; asset?: string; assetContract?: string; recipientAddress: string; assetAmountIn?: string; estimatedOut: string; deliveredAmount?: string; status: ConversionStatus; feeAmount?: string; serviceFeeAmount?: string; serviceFeeAsset?: string; assetDecimals: number; swapId: string; invoice: string; invoiceAmountSats: number; bridgeRef?: string; maxSlippageBps: number; quoteDegraded?: boolean };

export type ConversionProvider = "amm" | "orchestra" | "boltz";

export type ConversionPurpose = { type: "ongoingPayment"; paymentRequest: string } | { type: "selfTransfer" } | { type: "autoConversion" };

export type ConversionStatus = "pending" | "completed" | "failed" | "refundNeeded" | "refunded";

export type ConversionType = { type: "fromBitcoin" } | { type: "toBitcoin"; fromTokenIdentifier: string };

export type CrossChainAddressFamily = "evm" | "solana" | "tron";

export type CrossChainFeeMode = "feesExcluded" | "feesIncluded";

export type CrossChainProvider = "orchestra" | "boltz";

export type CrossChainProviderContext = { type: "orchestra"; quoteId: string; depositAddress: string; depositAmount?: string } | { type: "boltz"; swapId: string; invoice: string; invoiceAmountSats?: number; maxSlippageBps: number };

export type CrossChainRouteFilter = { type: "send"; addressDetails: CrossChainAddressDetails } | { type: "receive"; contractAddress?: string };

export type DepositClaimError = { type: "maxDepositClaimFeeExceeded"; tx: string; vout: number; maxFee?: Fee; requiredFeeSats: number; requiredFeeRateSatPerVbyte: number } | { type: "missingUtxo"; tx: string; vout: number } | { type: "generic"; message: string };

export type ExternalFrostDerivation = { type: "signingLeaf"; leafId: ExternalTreeNodeId } | { type: "staticDeposit"; index: number } | { type: "htlcPreimage" } | { type: "identity" };

export type ExternalSparkInvoiceKind = "sats" | "tokens";

export type ExternalTokenTransactionKind = "freeze" | "partial" | "final";

export type Fee = { type: "fixed"; amount: number } | { type: "rate"; satPerVbyte: number };

export type FeePolicy = "feesExcluded" | "feesIncluded";

export type InputType = ({ type: "bitcoinAddress" } & BitcoinAddressDetails) | ({ type: "bolt11Invoice" } & Bolt11InvoiceDetails) | ({ type: "bolt12Invoice" } & Bolt12InvoiceDetails) | ({ type: "bolt12Offer" } & Bolt12OfferDetails) | ({ type: "lightningAddress" } & LightningAddressDetails) | ({ type: "lnurlPay" } & LnurlPayRequestDetails) | ({ type: "silentPaymentAddress" } & SilentPaymentAddressDetails) | ({ type: "lnurlAuth" } & LnurlAuthRequestDetails) | ({ type: "url" } & string) | ({ type: "bip21" } & Bip21Details) | ({ type: "bolt12InvoiceRequest" } & Bolt12InvoiceRequestDetails) | ({ type: "lnurlWithdraw" } & LnurlWithdrawRequestDetails) | ({ type: "sparkAddress" } & SparkAddressDetails) | ({ type: "sparkInvoice" } & SparkInvoiceDetails) | ({ type: "crossChainAddress" } & CrossChainAddressDetails);

export type LnurlCallbackStatus = { type: "ok" } | { type: "errorStatus"; errorDetails: LnurlErrorDetails };

export type MaxFee = { type: "fixed"; amount: number } | { type: "rate"; satPerVbyte: number } | { type: "networkRecommended"; leewaySatPerVbyte: number };

export type Network = "mainnet" | "regtest";

export type OnchainConfirmationSpeed = "fast" | "medium" | "slow";

export type OptimizationMode = "full" | "singleRound";

export type OptimizationOutcome = { type: "completed"; roundsExecuted: number } | { type: "inProgress" };

export type PaymentDetails = { type: "spark"; invoiceDetails?: SparkInvoicePaymentDetails; htlcDetails?: SparkHtlcDetails; conversionInfo?: ConversionInfo } | { type: "token"; metadata: TokenMetadata; txHash: string; txType: TokenTransactionType; invoiceDetails?: SparkInvoicePaymentDetails; conversionInfo?: ConversionInfo } | { type: "lightning"; description?: string; invoice: string; destinationPubkey: string; htlcDetails: SparkHtlcDetails; lnurlPayInfo?: LnurlPayInfo; lnurlWithdrawInfo?: LnurlWithdrawInfo; lnurlReceiveMetadata?: LnurlReceiveMetadata; conversionInfo?: ConversionInfo } | { type: "withdraw"; txId: string } | { type: "deposit"; txId: string; vout: number };

export type PaymentDetailsFilter = { type: "spark"; htlcStatus?: SparkHtlcStatus[]; conversionRefundNeeded?: boolean } | { type: "token"; conversionRefundNeeded?: boolean; txHash?: string; txType?: TokenTransactionType } | { type: "lightning"; htlcStatus?: SparkHtlcStatus[] };

export type PaymentMethod = "lightning" | "spark" | "token" | "deposit" | "withdraw" | "unknown";

export type PaymentRequest = { type: "input"; input: string } | { type: "crossChain"; address: string; route: CrossChainRoutePair; maxSlippageBps?: number; targetOverpayBps?: number };

export type PaymentStatus = "completed" | "pending" | "failed";

export type PaymentType = "send" | "receive";

export type ProvisionalPaymentDetails = { type: "bitcoin"; withdrawalAddress: string } | { type: "lightning"; invoice: string } | { type: "spark"; payRequest: string } | { type: "token"; tokenId: string; payRequest: string };

export type PublishSignedLnurlPayResponse = { type: "swapCompleted" } | { type: "paymentSent"; response: LnurlPayResponse };

export type PublishSignedTransferPackageResponse = { type: "swapCompleted" } | { type: "paymentSent"; payment: Payment };

export type ReceivePaymentMethod = { type: "sparkAddress" } | { type: "sparkInvoice"; amount?: string; tokenIdentifier?: string; expiryTime?: number; description?: string; senderPublicKey?: string } | { type: "bitcoinAddress"; newAddress?: boolean } | { type: "bolt11Invoice"; description: string; amountSats?: number; expirySecs?: number; paymentHash?: string };

export type SdkEvent = { type: "synced" } | { type: "unclaimedDeposits"; unclaimedDeposits: DepositInfo[] } | { type: "claimedDeposits"; claimedDeposits: DepositInfo[] } | { type: "paymentSucceeded"; payment: Payment } | { type: "paymentPending"; payment: Payment } | { type: "paymentFailed"; payment: Payment } | { type: "autoOptimization"; optimizationEvent: AutoOptimizationEvent } | { type: "lightningAddressChanged"; lightningAddress?: LightningAddressInfo } | { type: "newDeposits"; newDeposits: DepositInfo[] };

export type Seed = { type: "mnemonic"; mnemonic: string; passphrase?: string } | ({ type: "entropy" } & number[]);

export type SendPaymentMethod = { type: "bitcoinAddress"; address: BitcoinAddressDetails; feeQuote: SendOnchainFeeQuote } | { type: "bolt11Invoice"; invoiceDetails: Bolt11InvoiceDetails; sparkTransferFeeSats?: number; lightningFeeSats: number } | { type: "sparkAddress"; address: string; fee: string; tokenIdentifier?: string } | { type: "sparkInvoice"; sparkInvoiceDetails: SparkInvoiceDetails; fee: string; tokenIdentifier?: string } | { type: "crossChainAddress"; route: CrossChainRoutePair; recipientAddress: string; amountIn: string; assetAmountIn: string; estimatedOut: string; feeAmount: string; serviceFeeAmount: string; serviceFeeAsset?: string; sourceTransferFeeSats: number; feeMode: CrossChainFeeMode; expiresAt: string; providerContext: CrossChainProviderContext };

export type SendPaymentOptions = { type: "bitcoinAddress"; confirmationSpeed: OnchainConfirmationSpeed } | { type: "bolt11Invoice"; preferSpark: boolean; completionTimeoutSecs?: number } | { type: "sparkAddress"; htlcOptions?: SparkHtlcOptions };

export type ServiceStatus = "operational" | "degraded" | "partial" | "unknown" | "major";

export type SessionStoreError = { type: "notFound" } | ({ type: "generic" } & string);

export type SourceAsset = { type: "bitcoin" } | { type: "token"; tokenIdentifier: string };

export type SparkHtlcStatus = "waitingForPreimage" | "preimageShared" | "returned";

export type StableBalanceActiveLabel = { type: "set"; label: string } | { type: "unset" };

export type StoragePaymentDetailsFilter = { type: "spark"; htlcStatus?: SparkHtlcStatus[]; conversionFilter?: ConversionFilter } | { type: "token"; conversionFilter?: ConversionFilter; txHash?: string; txType?: TokenTransactionType } | { type: "lightning"; htlcStatus?: SparkHtlcStatus[]; conversionFilter?: ConversionFilter };

export type SuccessAction = { type: "aes"; data: AesSuccessActionData } | { type: "message"; data: MessageSuccessActionData } | { type: "url"; data: UrlSuccessActionData };

export type SuccessActionProcessed = { type: "aes"; result: AesSuccessActionDataResult } | { type: "message"; data: MessageSuccessActionData } | { type: "url"; data: UrlSuccessActionData };

export type TokenTransactionType = "transfer" | "mint" | "burn";

export type TransferSignature = { type: "transfer"; signed: ExternalPreparedTransfer } | { type: "token"; signed: ExternalPreparedTokenTransaction };

export type TransferTarget = { type: "spark"; address: string; sparkInvoice?: string } | { type: "lightning"; bolt11: string; lnurlPay?: LnurlPayContext; feePolicy: FeePolicy; completionTimeoutSecs?: number } | { type: "coopExit"; address: string; feeQuote: SendOnchainFeeQuote; confirmationSpeed: OnchainConfirmationSpeed };

export type UnsignedTransferPackage = { type: "swap"; prepareTransfer: ExternalPrepareTransferRequest; targetAmounts: number[]; amountSat: number; feeSat: number } | { type: "transfer"; prepareTransfer: ExternalPrepareTransferRequest; amountSat: number; feeSat: number; target: TransferTarget } | { type: "token"; prepareTokenTransaction: ExternalPrepareTokenTransactionRequest; tokenContext: number[]; tokenIdentifier: string; amount: string; fee: string; isSwap: boolean };

export type UpdateDepositPayload = { type: "claimError"; error: DepositClaimError } | { type: "refund"; refundTxid: string; refundTx: string };

export type WebhookEventType = { type: "lightningReceiveFinished" } | { type: "lightningSendFinished" } | { type: "coopExitFinished" } | { type: "staticDepositFinished" } | ({ type: "unknown" } & string);


/**
 * Rust-built implementation of the JS `BitcoinChainService` interface.
 *
 * Returned by factories like [`new_rest_chain_service`]; users see it as a
 * `BitcoinChainService` and pass it to `withChainService`. Pass the same
 * instance to multiple `SdkBuilder`s to share a single underlying HTTP
 * client (and its connection pool) across SDK instances.
 */
export class BitcoinChainServiceHandle {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    broadcastTransaction(tx: string): Promise<void>;
    getAddressUtxos(address: string): Promise<any>;
    getTransactionHex(txid: string): Promise<any>;
    getTransactionStatus(txid: string): Promise<any>;
    recommendedFees(): Promise<any>;
}

export class BreezSdk {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    addContact(request: AddContactRequest): Promise<Contact>;
    addEventListener(listener: EventListener): Promise<string>;
    authorizeLightningAddressTransfer(request: AuthorizeTransferRequest): Promise<TransferAuthorization>;
    buildUnsignedLnurlPayPackage(request: BuildUnsignedLnurlPayPackageRequest): Promise<UnsignedTransferPackage>;
    buildUnsignedTransferPackage(request: BuildUnsignedTransferPackageRequest): Promise<UnsignedTransferPackage>;
    buyBitcoin(request: BuyBitcoinRequest): Promise<BuyBitcoinResponse>;
    checkLightningAddressAvailable(request: CheckLightningAddressRequest): Promise<boolean>;
    checkMessage(request: CheckMessageRequest): Promise<CheckMessageResponse>;
    claimDeposit(request: ClaimDepositRequest): Promise<ClaimDepositResponse>;
    claimHtlcPayment(request: ClaimHtlcPaymentRequest): Promise<ClaimHtlcPaymentResponse>;
    claimLightningAddressTransfer(request: ClaimTransferRequest): Promise<LightningAddressInfo>;
    deleteContact(id: string): Promise<void>;
    deleteLightningAddress(): Promise<void>;
    disconnect(): Promise<void>;
    fetchConversionLimits(request: FetchConversionLimitsRequest): Promise<FetchConversionLimitsResponse>;
    getCrossChainRoutes(filter: CrossChainRouteFilter): Promise<CrossChainRoutePair[]>;
    getInfo(request: GetInfoRequest): Promise<GetInfoResponse>;
    getLightningAddress(): Promise<LightningAddressInfo | undefined>;
    getPayment(request: GetPaymentRequest): Promise<GetPaymentResponse>;
    getTokenIssuer(): TokenIssuer;
    getTokensMetadata(request: GetTokensMetadataRequest): Promise<GetTokensMetadataResponse>;
    getUserSettings(): Promise<UserSettings>;
    listContacts(request: ListContactsRequest): Promise<Contact[]>;
    listFiatCurrencies(): Promise<ListFiatCurrenciesResponse>;
    listFiatRates(): Promise<ListFiatRatesResponse>;
    listPayments(request: ListPaymentsRequest): Promise<ListPaymentsResponse>;
    listUnclaimedDeposits(request: ListUnclaimedDepositsRequest): Promise<ListUnclaimedDepositsResponse>;
    listWebhooks(): Promise<Webhook[]>;
    lnurlAuth(request_data: LnurlAuthRequestDetails): Promise<LnurlCallbackStatus>;
    lnurlPay(request: LnurlPayRequest): Promise<LnurlPayResponse>;
    lnurlWithdraw(request: LnurlWithdrawRequest): Promise<LnurlWithdrawResponse>;
    optimizeLeaves(request: OptimizeLeavesRequest): Promise<OptimizeLeavesResponse>;
    parse(input: string): Promise<InputType>;
    prepareLnurlPay(request: PrepareLnurlPayRequest): Promise<PrepareLnurlPayResponse>;
    prepareSendPayment(request: PrepareSendPaymentRequest): Promise<PrepareSendPaymentResponse>;
    publishSignedLnurlPayPackage(request: PublishSignedLnurlPayPackageRequest): Promise<PublishSignedLnurlPayResponse>;
    publishSignedTransferPackage(request: PublishSignedTransferPackageRequest): Promise<PublishSignedTransferPackageResponse>;
    receivePayment(request: ReceivePaymentRequest): Promise<ReceivePaymentResponse>;
    recommendedFees(): Promise<RecommendedFees>;
    refundDeposit(request: RefundDepositRequest): Promise<RefundDepositResponse>;
    refundPendingConversions(): Promise<void>;
    registerLightningAddress(request: RegisterLightningAddressRequest): Promise<LightningAddressInfo>;
    registerWebhook(request: RegisterWebhookRequest): Promise<RegisterWebhookResponse>;
    removeEventListener(id: string): Promise<boolean>;
    sendPayment(request: SendPaymentRequest): Promise<SendPaymentResponse>;
    signMessage(request: SignMessageRequest): Promise<SignMessageResponse>;
    syncWallet(request: SyncWalletRequest): Promise<SyncWalletResponse>;
    unregisterWebhook(request: UnregisterWebhookRequest): Promise<void>;
    updateContact(request: UpdateContactRequest): Promise<Contact>;
    updateUserSettings(request: UpdateUserSettingsRequest): Promise<void>;
}

/**
 * A Rust-backed [`ExternalBreezSigner`] surfaced to JS as a signer object that
 * can be passed to `connectWithSigner` or `SdkBuilder.newWithSigner`. Produced
 * by `defaultExternalSigners` (seed) and `createTurnkeySigner` (Turnkey).
 *
 * [`ExternalBreezSigner`]: breez_sdk_spark::signer::ExternalBreezSigner
 */
export class ExternalBreezSignerHandle {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    decryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    derivePublicKey(path: string): Promise<PublicKeyBytes>;
    encryptEcies(message: Uint8Array, path: string): Promise<Uint8Array>;
    hmacSha256(message: Uint8Array, path: string): Promise<HashedMessageBytes>;
    signEcdsa(message: MessageBytes, path: string): Promise<EcdsaSignatureBytes>;
    signEcdsaRecoverable(message: MessageBytes, path: string): Promise<RecoverableEcdsaSignatureBytes>;
    signHashSchnorr(hash: Uint8Array, path: string): Promise<SchnorrSignatureBytes>;
}

/**
 * The two external signers for the SDK's signer-based connect. Returned by
 * `defaultExternalSigners` (seed) and `createTurnkeySigner` (Turnkey); pass
 * both halves to `connectWithSigner` or `SdkBuilder.newWithSigner`.
 */
export class ExternalSigners {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * External signer for non-Spark SDK signing (LNURL-auth, sync, message
     * signing, ECIES).
     */
    readonly breezSigner: ExternalBreezSignerHandle;
    /**
     * External high-level Spark signer for the Spark wallet flows.
     */
    readonly sparkSigner: ExternalSparkSignerHandle;
}

/**
 * A Rust-backed [`ExternalSigningSigner`] surfaced to JS as a signer object
 * that can be passed to `connectWithSigningOnlySigner` or
 * `SdkBuilder.newWithSigningOnlySigner`. Produced by
 * `createTurnkeySigningOnlySigner`.
 *
 * [`ExternalSigningSigner`]: breez_sdk_spark::signer::ExternalSigningSigner
 */
export class ExternalSigningSignerHandle {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    derivePublicKey(path: string): Promise<PublicKeyBytes>;
    signEcdsa(message: MessageBytes, path: string): Promise<EcdsaSignatureBytes>;
    signEcdsaRecoverable(message: MessageBytes, path: string): Promise<RecoverableEcdsaSignatureBytes>;
    signHashSchnorr(hash: Uint8Array, path: string): Promise<SchnorrSignatureBytes>;
}

/**
 * A Rust-backed [`ExternalSparkSigner`] surfaced to JS as a signer object that
 * can be passed to `connectWithSigner` or `SdkBuilder.newWithSigner`. Produced
 * by `defaultExternalSigners` (seed) and `createTurnkeySigner` (Turnkey).
 *
 * [`ExternalSparkSigner`]: breez_sdk_spark::signer::ExternalSparkSigner
 */
export class ExternalSparkSignerHandle {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    getIdentityPublicKey(): Promise<PublicKeyBytes>;
    getPublicKeyForLeaf(leaf_id: ExternalTreeNodeId): Promise<PublicKeyBytes>;
    getStaticDepositPublicKey(index: number): Promise<PublicKeyBytes>;
    prepareClaim(request: ExternalPrepareClaimRequest): Promise<ExternalPreparedClaim>;
    prepareLightningReceive(request: ExternalPrepareLightningReceiveRequest): Promise<ExternalPreparedLightningReceive>;
    prepareStaticDeposit(request: ExternalPrepareStaticDepositRequest): Promise<ExternalPreparedStaticDeposit>;
    prepareStaticDepositClaim(request: ExternalPrepareStaticDepositClaimRequest): Promise<ExternalPreparedStaticDepositClaim>;
    prepareTokenTransaction(request: ExternalPrepareTokenTransactionRequest): Promise<ExternalPreparedTokenTransaction>;
    prepareTransfer(request: ExternalPrepareTransferRequest): Promise<ExternalPreparedTransfer>;
    signAuthenticationChallenge(challenge: Uint8Array): Promise<EcdsaSignatureBytes>;
    signFrost(jobs: ExternalFrostJob[]): Promise<ExternalFrostShareResult[]>;
    signMessage(message: Uint8Array): Promise<EcdsaSignatureBytes>;
    signSparkInvoice(request: ExternalSignSparkInvoiceRequest): Promise<ExternalSignedSparkInvoice>;
    signStaticDepositRefund(request: ExternalSignStaticDepositRefundRequest): Promise<ExternalFrostSignature>;
    startStaticDepositRefund(request: ExternalStartStaticDepositRefundRequest): Promise<ExternalStartedStaticDepositRefund>;
}

export class IntoUnderlyingByteSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableByteStreamController): Promise<any>;
    start(controller: ReadableByteStreamController): void;
    readonly autoAllocateChunkSize: number;
    readonly type: ReadableStreamType;
}

export class IntoUnderlyingSink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    abort(reason: any): Promise<any>;
    close(): Promise<any>;
    write(chunk: any): Promise<any>;
}

export class IntoUnderlyingSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableStreamDefaultController): Promise<any>;
}

/**
 * High-level orchestrator that collapses register / sign-in flows
 * into single calls. See the matching Rust types for full semantics;
 * the JS surface is a thin wasm-bindgen wrapper.
 */
export class PasskeyClient {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * One-shot capability probe (PRF support + domain association)
     * hosts can gate UX on.
     */
    checkAvailability(): Promise<PasskeyAvailability>;
    /**
     * Label sub-object. List / publish labels for this passkey's identity.
     */
    labels(): PasskeyLabels;
    /**
     * Create a `PasskeyClient` backed by the supplied `PrfProvider` and
     * the default Nostr-backed label store. `breezApiKey` enables
     * authenticated (NIP-42) relay access for label storage; omit for
     * public relays only.
     */
    constructor(prf_provider: PrfProvider, breez_api_key?: string | null, config?: PasskeyConfig | null);
    /**
     * First-time setup. Drives the platform's create-passkey ceremony
     * then derives the wallet seed in the same PRF assertion ceremony
     * where the platform supports it.
     */
    register(request: RegisterRequest): Promise<RegisterResponse>;
    /**
     * Returning-user sign-in. With `label` set, uses the fast path
     * (one ceremony, no Nostr round-trip). With `label` omitted,
     * derives the default-label wallet and discovers the user's
     * label set in the same ceremony.
     */
    signIn(request: SignInRequest): Promise<SignInResponse>;
}

/**
 * Label sub-object surfaced from `PasskeyClient.labels()`.
 */
export class PasskeyLabels {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * List labels published for this passkey's identity.
     */
    list(): Promise<string[]>;
    /**
     * Idempotently publish `label` for this passkey's identity.
     */
    store(label: string): Promise<void>;
}

export class SdkBuilder {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    build(): Promise<BreezSdk>;
    static new(config: Config, seed: Seed): SdkBuilder;
    static newWithSigner(config: Config, breez_signer: ExternalBreezSigner, spark_signer: ExternalSparkSigner): SdkBuilder;
    /**
     * Creates a new `SdkBuilder` with a signing-only external signer, for a
     * signer that can't perform the SDK's local ECIES/HMAC operations. The SDK
     * keeps session tokens in plaintext and disables the features that rely on
     * ECIES/HMAC.
     */
    static newWithSigningOnlySigner(config: Config, breez_signer: ExternalSigningSigner, spark_signer: ExternalSparkSigner): SdkBuilder;
    withAccountNumber(account_number: number): SdkBuilder;
    withChainService(chain_service: BitcoinChainService): SdkBuilder;
    withDefaultStorage(storage_dir: string): Promise<SdkBuilder>;
    withFiatService(fiat_service: FiatService): SdkBuilder;
    withLnurlClient(lnurl_client: RestClient): SdkBuilder;
    /**
     * **Deprecated.** Use `withStorageBackend(mysqlStorage(config))`.
     */
    withMysqlBackend(config: MysqlStorageConfig): SdkBuilder;
    withPaymentObserver(payment_observer: PaymentObserver): SdkBuilder;
    /**
     * **Deprecated.** Use `withStorageBackend(postgresStorage(config))`.
     */
    withPostgresBackend(config: PostgresStorageConfig): SdkBuilder;
    withRestChainService(url: string, api_type: ChainApiType, credentials?: Credentials | null): SdkBuilder;
    /**
     * Threads a shared [`WasmSdkContext`] into the builder.
     *
     * Construct the context once via `newSharedSdkContext` and pass the same
     * handle to every `SdkBuilder` whose SDKs should share its resources
     * (operator gRPC channels, SSP HTTP client, database pool).
     */
    withSharedContext(context: WasmSdkContext): SdkBuilder;
    withStorage(storage: Storage): SdkBuilder;
    /**
     * Sets one of the SDK's built-in storage backends.
     *
     * Construct the [`WasmStorageConfig`] via `defaultStorage`,
     * `postgresStorage` or `mysqlStorage`.
     */
    withStorageBackend(config: WasmStorageConfig): SdkBuilder;
}

/**
 * The signing-only external signers for the SDK's signer-based connect.
 * Returned by `createTurnkeySigningOnlySigner`; pass both halves to
 * `connectWithSigningOnlySigner` or `SdkBuilder.newWithSigningOnlySigner`.
 */
export class SigningOnlyExternalSigners {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Signing-only external signer for non-Spark SDK signing.
     */
    readonly breezSigner: ExternalSigningSignerHandle;
    /**
     * External high-level Spark signer for the Spark wallet flows.
     */
    readonly sparkSigner: ExternalSparkSignerHandle;
}

export class TokenIssuer {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    burnIssuerToken(request: BurnIssuerTokenRequest): Promise<Payment>;
    createIssuerToken(request: CreateIssuerTokenRequest): Promise<TokenMetadata>;
    freezeIssuerToken(request: FreezeIssuerTokenRequest): Promise<FreezeIssuerTokenResponse>;
    getIssuerTokenBalance(): Promise<TokenBalance>;
    getIssuerTokenMetadata(): Promise<TokenMetadata>;
    mintIssuerToken(request: MintIssuerTokenRequest): Promise<Payment>;
    unfreezeIssuerToken(request: UnfreezeIssuerTokenRequest): Promise<UnfreezeIssuerTokenResponse>;
}

/**
 * Process-shared resources backing one or more `BreezSdk` instances on WASM.
 *
 * Construct once via `newSharedSdkContext` and pass the handle to every
 * `SdkBuilder` whose SDKs should share its operator gRPC channels, SSP HTTP
 * client, and (optionally) database connection pool.
 */
export class WasmSdkContext {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}

/**
 * Selects one of the SDK's built-in storage backends.
 *
 * Construct it via `defaultStorage`, `postgresStorage` or `mysqlStorage` and
 * pass it to `SdkBuilder.withStorageBackend`.
 */
export class WasmStorageConfig {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}

export function connect(request: ConnectRequest): Promise<BreezSdk>;

export function connectWithSigner(config: Config, breez_signer: ExternalBreezSigner, spark_signer: ExternalSparkSigner, storage_dir: string): Promise<BreezSdk>;

/**
 * Connects using a signing-only external signer, for a signer that can't
 * perform the SDK's local ECIES/HMAC operations. The SDK keeps session tokens
 * in plaintext and disables the features that rely on ECIES/HMAC.
 */
export function connectWithSigningOnlySigner(config: Config, breez_signer: ExternalSigningSigner, spark_signer: ExternalSparkSigner, storage_dir: string): Promise<BreezSdk>;

/**
 * Builds the Turnkey-backed signers from `config`, then pass
 * `signers.breezSigner` and `signers.sparkSigner` to `connectWithSigner`,
 * exactly as with any other external signer.
 */
export function createTurnkeySigner(config: TurnkeyConfig): Promise<ExternalSigners>;

/**
 * Builds the signing-only Turnkey-backed signers from `config` (for a wallet
 * under a deny-export policy), then pass `signers.breezSigner` and
 * `signers.sparkSigner` to `connectWithSigningOnlySigner`. The Breez half
 * performs signing only and never exports a key.
 */
export function createTurnkeySigningOnlySigner(config: TurnkeyConfig): Promise<SigningOnlyExternalSigners>;

export function defaultConfig(network: Network): Config;

/**
 * Creates the default external signers from a mnemonic phrase.
 *
 * Key derivation matches the seed-based connect path: an SDK built either
 * way from the same mnemonic is the same wallet.
 */
export function defaultExternalSigners(mnemonic: string, passphrase: string | null | undefined, network: Network, account_number?: number | null): ExternalSigners;

/**
 * Creates a default MySQL storage configuration with sensible defaults.
 *
 * Default values:
 * - `maxPoolSize`: 10
 * - `createTimeoutSecs`: 0 (no timeout)
 * - `recycleTimeoutSecs`: 10
 * - `foreignKeyMode`: `Enforced`
 */
export function defaultMysqlStorageConfig(connection_string: string): MysqlStorageConfig;

/**
 * Creates a default PostgreSQL storage configuration with sensible defaults.
 *
 * Default values (from pg.Pool):
 * - `maxPoolSize`: 10
 * - `createTimeoutSecs`: 0 (no timeout)
 * - `recycleTimeoutSecs`: 10 (10 seconds idle before disconnect)
 */
export function defaultPostgresStorageConfig(connection_string: string): PostgresStorageConfig;

export function defaultServerConfig(network: Network): Config;

/**
 * File-based storage rooted at `storageDir` — IndexedDB in the browser,
 * SQLite under Node.js.
 */
export function defaultStorage(storage_dir: string): WasmStorageConfig;

export function getSparkStatus(): Promise<SparkStatus>;

export function initLogging(logger: Logger, filter?: string | null): Promise<void>;

/**
 * `MySQL`-backed storage built from `config`.
 */
export function mysqlStorage(config: MysqlStorageConfig): WasmStorageConfig;

/**
 * Constructs a shareable REST-based Bitcoin chain service.
 *
 * Pass the returned chain service to multiple `SdkBuilder`s via
 * `withChainService` to reuse one HTTP client across SDK instances. All
 * SDKs sharing the chain service must use the same `network`.
 *
 * For one-off, non-shared use, prefer `withRestChainService`.
 */
export function newRestChainService(url: string, network: Network, api_type: ChainApiType, credentials?: Credentials | null): Promise<BitcoinChainService>;

/**
 * Constructs a [`WasmSdkContext`] from a `WasmSdkContextConfig`.
 */
export function newSharedSdkContext(config: WasmSdkContextConfig): Promise<WasmSdkContext>;

/**
 * `PostgreSQL`-backed storage built from `config`.
 */
export function postgresStorage(config: PostgresStorageConfig): WasmStorageConfig;

/**
 * Runs automatically when the wasm module is instantiated. Installs the
 * panic hook so Rust panics surface as readable `console.error` output
 * (with the panic message + `file.rs:line`) instead of a bare
 * `RuntimeError: unreachable`.
 */
export function start(): void;

/**
 * Entry point invoked by JavaScript in a worker.
 */
export function task_worker_entry_point(ptr: number): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_bitcoinchainservicehandle_free: (a: number, b: number) => void;
    readonly __wbg_breezsdk_free: (a: number, b: number) => void;
    readonly __wbg_externalsigners_free: (a: number, b: number) => void;
    readonly __wbg_passkeyclient_free: (a: number, b: number) => void;
    readonly __wbg_passkeylabels_free: (a: number, b: number) => void;
    readonly __wbg_sdkbuilder_free: (a: number, b: number) => void;
    readonly __wbg_tokenissuer_free: (a: number, b: number) => void;
    readonly __wbg_wasmsdkcontext_free: (a: number, b: number) => void;
    readonly __wbg_wasmstorageconfig_free: (a: number, b: number) => void;
    readonly bitcoinchainservicehandle_broadcastTransaction: (a: number, b: number, c: number) => any;
    readonly bitcoinchainservicehandle_getAddressUtxos: (a: number, b: number, c: number) => any;
    readonly bitcoinchainservicehandle_getTransactionHex: (a: number, b: number, c: number) => any;
    readonly bitcoinchainservicehandle_getTransactionStatus: (a: number, b: number, c: number) => any;
    readonly bitcoinchainservicehandle_recommendedFees: (a: number) => any;
    readonly breezsdk_addContact: (a: number, b: any) => any;
    readonly breezsdk_addEventListener: (a: number, b: any) => any;
    readonly breezsdk_authorizeLightningAddressTransfer: (a: number, b: any) => any;
    readonly breezsdk_buildUnsignedLnurlPayPackage: (a: number, b: any) => any;
    readonly breezsdk_buildUnsignedTransferPackage: (a: number, b: any) => any;
    readonly breezsdk_buyBitcoin: (a: number, b: any) => any;
    readonly breezsdk_checkLightningAddressAvailable: (a: number, b: any) => any;
    readonly breezsdk_checkMessage: (a: number, b: any) => any;
    readonly breezsdk_claimDeposit: (a: number, b: any) => any;
    readonly breezsdk_claimHtlcPayment: (a: number, b: any) => any;
    readonly breezsdk_claimLightningAddressTransfer: (a: number, b: any) => any;
    readonly breezsdk_deleteContact: (a: number, b: number, c: number) => any;
    readonly breezsdk_deleteLightningAddress: (a: number) => any;
    readonly breezsdk_disconnect: (a: number) => any;
    readonly breezsdk_fetchConversionLimits: (a: number, b: any) => any;
    readonly breezsdk_getCrossChainRoutes: (a: number, b: any) => any;
    readonly breezsdk_getInfo: (a: number, b: any) => any;
    readonly breezsdk_getLightningAddress: (a: number) => any;
    readonly breezsdk_getPayment: (a: number, b: any) => any;
    readonly breezsdk_getTokenIssuer: (a: number) => number;
    readonly breezsdk_getTokensMetadata: (a: number, b: any) => any;
    readonly breezsdk_getUserSettings: (a: number) => any;
    readonly breezsdk_listContacts: (a: number, b: any) => any;
    readonly breezsdk_listFiatCurrencies: (a: number) => any;
    readonly breezsdk_listFiatRates: (a: number) => any;
    readonly breezsdk_listPayments: (a: number, b: any) => any;
    readonly breezsdk_listUnclaimedDeposits: (a: number, b: any) => any;
    readonly breezsdk_listWebhooks: (a: number) => any;
    readonly breezsdk_lnurlAuth: (a: number, b: any) => any;
    readonly breezsdk_lnurlPay: (a: number, b: any) => any;
    readonly breezsdk_lnurlWithdraw: (a: number, b: any) => any;
    readonly breezsdk_optimizeLeaves: (a: number, b: any) => any;
    readonly breezsdk_parse: (a: number, b: number, c: number) => any;
    readonly breezsdk_prepareLnurlPay: (a: number, b: any) => any;
    readonly breezsdk_prepareSendPayment: (a: number, b: any) => any;
    readonly breezsdk_publishSignedLnurlPayPackage: (a: number, b: any) => any;
    readonly breezsdk_publishSignedTransferPackage: (a: number, b: any) => any;
    readonly breezsdk_receivePayment: (a: number, b: any) => any;
    readonly breezsdk_recommendedFees: (a: number) => any;
    readonly breezsdk_refundDeposit: (a: number, b: any) => any;
    readonly breezsdk_refundPendingConversions: (a: number) => any;
    readonly breezsdk_registerLightningAddress: (a: number, b: any) => any;
    readonly breezsdk_registerWebhook: (a: number, b: any) => any;
    readonly breezsdk_removeEventListener: (a: number, b: number, c: number) => any;
    readonly breezsdk_sendPayment: (a: number, b: any) => any;
    readonly breezsdk_signMessage: (a: number, b: any) => any;
    readonly breezsdk_syncWallet: (a: number, b: any) => any;
    readonly breezsdk_unregisterWebhook: (a: number, b: any) => any;
    readonly breezsdk_updateContact: (a: number, b: any) => any;
    readonly breezsdk_updateUserSettings: (a: number, b: any) => any;
    readonly connect: (a: any) => any;
    readonly connectWithSigner: (a: any, b: any, c: any, d: number, e: number) => any;
    readonly connectWithSigningOnlySigner: (a: any, b: any, c: any, d: number, e: number) => any;
    readonly createTurnkeySigner: (a: any) => any;
    readonly createTurnkeySigningOnlySigner: (a: any) => any;
    readonly defaultConfig: (a: any) => any;
    readonly defaultExternalSigners: (a: number, b: number, c: number, d: number, e: any, f: number) => [number, number, number];
    readonly defaultMysqlStorageConfig: (a: number, b: number) => any;
    readonly defaultPostgresStorageConfig: (a: number, b: number) => any;
    readonly defaultServerConfig: (a: any) => any;
    readonly defaultStorage: (a: number, b: number) => number;
    readonly externalbreezsignerhandle_decryptEcies: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly externalbreezsignerhandle_derivePublicKey: (a: number, b: number, c: number) => any;
    readonly externalbreezsignerhandle_encryptEcies: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly externalbreezsignerhandle_hmacSha256: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly externalbreezsignerhandle_signEcdsa: (a: number, b: any, c: number, d: number) => any;
    readonly externalbreezsignerhandle_signEcdsaRecoverable: (a: number, b: any, c: number, d: number) => any;
    readonly externalbreezsignerhandle_signHashSchnorr: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly externalsigners_breezSigner: (a: number) => number;
    readonly externalsigners_sparkSigner: (a: number) => number;
    readonly externalsigningsignerhandle_derivePublicKey: (a: number, b: number, c: number) => any;
    readonly externalsigningsignerhandle_signEcdsa: (a: number, b: any, c: number, d: number) => any;
    readonly externalsigningsignerhandle_signEcdsaRecoverable: (a: number, b: any, c: number, d: number) => any;
    readonly externalsigningsignerhandle_signHashSchnorr: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly externalsparksignerhandle_getIdentityPublicKey: (a: number) => any;
    readonly externalsparksignerhandle_getPublicKeyForLeaf: (a: number, b: any) => any;
    readonly externalsparksignerhandle_getStaticDepositPublicKey: (a: number, b: number) => any;
    readonly externalsparksignerhandle_prepareClaim: (a: number, b: any) => any;
    readonly externalsparksignerhandle_prepareLightningReceive: (a: number, b: any) => any;
    readonly externalsparksignerhandle_prepareStaticDeposit: (a: number, b: any) => any;
    readonly externalsparksignerhandle_prepareStaticDepositClaim: (a: number, b: any) => any;
    readonly externalsparksignerhandle_prepareTokenTransaction: (a: number, b: any) => any;
    readonly externalsparksignerhandle_prepareTransfer: (a: number, b: any) => any;
    readonly externalsparksignerhandle_signAuthenticationChallenge: (a: number, b: number, c: number) => any;
    readonly externalsparksignerhandle_signFrost: (a: number, b: number, c: number) => any;
    readonly externalsparksignerhandle_signMessage: (a: number, b: number, c: number) => any;
    readonly externalsparksignerhandle_signSparkInvoice: (a: number, b: any) => any;
    readonly externalsparksignerhandle_signStaticDepositRefund: (a: number, b: any) => any;
    readonly externalsparksignerhandle_startStaticDepositRefund: (a: number, b: any) => any;
    readonly getSparkStatus: () => any;
    readonly initLogging: (a: any, b: number, c: number) => any;
    readonly mysqlStorage: (a: any) => number;
    readonly newRestChainService: (a: number, b: number, c: any, d: any, e: number) => any;
    readonly newSharedSdkContext: (a: any) => any;
    readonly passkeyclient_checkAvailability: (a: number) => any;
    readonly passkeyclient_labels: (a: number) => number;
    readonly passkeyclient_new: (a: any, b: number, c: number, d: number) => number;
    readonly passkeyclient_register: (a: number, b: any) => any;
    readonly passkeyclient_signIn: (a: number, b: any) => any;
    readonly passkeylabels_list: (a: number) => any;
    readonly passkeylabels_store: (a: number, b: number, c: number) => any;
    readonly postgresStorage: (a: any) => number;
    readonly sdkbuilder_build: (a: number) => any;
    readonly sdkbuilder_new: (a: any, b: any) => number;
    readonly sdkbuilder_newWithSigner: (a: any, b: any, c: any) => number;
    readonly sdkbuilder_newWithSigningOnlySigner: (a: any, b: any, c: any) => number;
    readonly sdkbuilder_withAccountNumber: (a: number, b: number) => number;
    readonly sdkbuilder_withChainService: (a: number, b: any) => number;
    readonly sdkbuilder_withDefaultStorage: (a: number, b: number, c: number) => any;
    readonly sdkbuilder_withFiatService: (a: number, b: any) => number;
    readonly sdkbuilder_withLnurlClient: (a: number, b: any) => number;
    readonly sdkbuilder_withMysqlBackend: (a: number, b: any) => [number, number, number];
    readonly sdkbuilder_withPaymentObserver: (a: number, b: any) => number;
    readonly sdkbuilder_withPostgresBackend: (a: number, b: any) => [number, number, number];
    readonly sdkbuilder_withRestChainService: (a: number, b: number, c: number, d: any, e: number) => number;
    readonly sdkbuilder_withSharedContext: (a: number, b: number) => number;
    readonly sdkbuilder_withStorage: (a: number, b: any) => number;
    readonly sdkbuilder_withStorageBackend: (a: number, b: number) => number;
    readonly start: () => void;
    readonly tokenissuer_burnIssuerToken: (a: number, b: any) => any;
    readonly tokenissuer_createIssuerToken: (a: number, b: any) => any;
    readonly tokenissuer_freezeIssuerToken: (a: number, b: any) => any;
    readonly tokenissuer_getIssuerTokenBalance: (a: number) => any;
    readonly tokenissuer_getIssuerTokenMetadata: (a: number) => any;
    readonly tokenissuer_mintIssuerToken: (a: number, b: any) => any;
    readonly tokenissuer_unfreezeIssuerToken: (a: number, b: any) => any;
    readonly rustsecp256k1_v0_10_0_context_create: (a: number) => number;
    readonly rustsecp256k1_v0_10_0_context_destroy: (a: number) => void;
    readonly rustsecp256k1_v0_10_0_default_error_callback_fn: (a: number, b: number) => void;
    readonly rustsecp256k1_v0_10_0_default_illegal_callback_fn: (a: number, b: number) => void;
    readonly task_worker_entry_point: (a: number) => [number, number];
    readonly __wbg_intounderlyingbytesource_free: (a: number, b: number) => void;
    readonly __wbg_intounderlyingsink_free: (a: number, b: number) => void;
    readonly __wbg_intounderlyingsource_free: (a: number, b: number) => void;
    readonly intounderlyingbytesource_autoAllocateChunkSize: (a: number) => number;
    readonly intounderlyingbytesource_cancel: (a: number) => void;
    readonly intounderlyingbytesource_pull: (a: number, b: any) => any;
    readonly intounderlyingbytesource_start: (a: number, b: any) => void;
    readonly intounderlyingbytesource_type: (a: number) => number;
    readonly intounderlyingsink_abort: (a: number, b: any) => any;
    readonly intounderlyingsink_close: (a: number) => any;
    readonly intounderlyingsink_write: (a: number, b: any) => any;
    readonly intounderlyingsource_cancel: (a: number) => void;
    readonly intounderlyingsource_pull: (a: number, b: any) => any;
    readonly __wbg_externalbreezsignerhandle_free: (a: number, b: number) => void;
    readonly __wbg_externalsigningsignerhandle_free: (a: number, b: number) => void;
    readonly __wbg_externalsparksignerhandle_free: (a: number, b: number) => void;
    readonly __wbg_signingonlyexternalsigners_free: (a: number, b: number) => void;
    readonly signingonlyexternalsigners_breezSigner: (a: number) => number;
    readonly signingonlyexternalsigners_sparkSigner: (a: number) => number;
    readonly wasm_bindgen__convert__closures_____invoke__h4e4b2e34606b7656: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h4e4b2e34606b7656_6: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h4e4b2e34606b7656_7: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h4e4b2e34606b7656_8: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h4e4b2e34606b7656_9: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__ha20d6a9f28ab571f: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h2f7210f25881b486: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h2f7210f25881b486_2: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h2f7210f25881b486_3: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h2f7210f25881b486_4: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h2f7210f25881b486_5: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h6d76206c33714423: (a: number, b: number) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h11f9cefb00a9a8f1: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
